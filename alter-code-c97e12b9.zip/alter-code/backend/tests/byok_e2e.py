"""BYOK end-to-end: routing, no Universal-Key fallback, encryption, multi-turn chat, multilingual voice/text capture.
Run: BASE=https://<host> python tests/byok_e2e.py   (needs GEMINI_TEST_API_KEY in backend/.env)
Uses demo@alter.app (a normal user). Removes the key again at the end."""
import json
import os
import sys
import time
import uuid
from datetime import datetime, timezone

import requests
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
BASE = os.environ["BASE"].rstrip("/") + "/api"
KEY = os.environ["GEMINI_TEST_API_KEY"]
db = MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]
ok_all = True


def check(name, cond, extra=""):
    global ok_all
    ok_all &= bool(cond)
    print(("PASS " if cond else "FAIL ") + name, str(extra)[:300])


def login(e, p):
    return {"Authorization": "Bearer " + requests.post(f"{BASE}/auth/login", json={"email": e, "password": p}).json()["token"]}


PAUSE = float(os.environ.get("PAUSE", "13"))  # free-tier Gemini keys allow only a few requests per minute


def chat(h, msg, conv=None):
    time.sleep(PAUSE)
    r = requests.post(f"{BASE}/chat", json={"message": msg, "conversation_id": conv, "client_id": uuid.uuid4().hex[:16]}, headers=h, timeout=150)
    if r.headers.get("content-type", "").startswith("application/json"):
        return r.status_code, r.json(), None
    ev = [json.loads(l[6:]) for l in r.text.splitlines() if l.startswith("data: ")]
    conv_id = next((e["conversation"]["id"] for e in ev if e["type"] == "meta"), None)
    err = next((e for e in ev if e["type"] == "error"), None)
    text = "".join(e.get("content", "") for e in ev if e["type"] == "delta")
    return r.status_code, {"text": text, "error": err, "actions": next((e["actions"] for e in ev if e["type"] == "actions"), [])}, conv_id


demo, admin = login("demo@alter.app", "<REDACTED_PASSWORD>"), login("admin@example.com", "<REDACTED_PASSWORD>")
uid = db.users.find_one({"email": "demo@alter.app"})["_id"].__str__()
requests.delete(f"{BASE}/ai/key", headers=demo)
db.ai_key_attempts.delete_many({"user_id": uid})
db.usage_counters.delete_many({"_id": {"$regex": f"^u:{uid}\\|"}})  # fresh daily allowance for the test user
t0 = datetime.now(timezone.utc).isoformat()

# 1) no key -> AI off, nothing charged
st = requests.get(f"{BASE}/ai/key", headers=demo).json()
check("no key: route none", st["route"] == "none" and not st["configured"], st)
c, body, _ = chat(demo, "hello")
check("no key: chat 402 byok_required", c == 402 and body.get("code") == "byok_required", body)
r = requests.post(f"{BASE}/capture", json={"text": "buy milk"}, headers=demo).json()
check("no key: capture saves plain task, ai false", r["ai"] is False and r["results"][0]["type"] == "create_task", r)
for x in r["results"]:
    requests.delete(f"{BASE}/tasks/{x['data']['id']}", headers=demo)

# 2) invalid key rejected, not stored
r = requests.put(f"{BASE}/ai/key", json={"api_key": "AIzaSyBADBADBADBADBADBADBADBADBADBAD12"}, headers=demo)
check("invalid key -> 401 byok_invalid", r.status_code == 401 and r.json()["code"] == "byok_invalid", r.text)
check("invalid key not stored", db.ai_credentials.find_one({"user_id": uid}) is None)
r = requests.put(f"{BASE}/ai/key", json={"api_key": "not a key!"}, headers=demo)
check("malformed key -> 400/422", r.status_code in (400, 422), r.status_code)

# 3) valid key saved encrypted + masked
r = requests.put(f"{BASE}/ai/key", json={"api_key": KEY}, headers=demo)
check("valid key saved", r.status_code == 200 and r.json()["status"] == "valid" and r.json()["route"] == "byok", r.text)
check("response never contains the key", KEY not in r.text and KEY not in requests.get(f"{BASE}/ai/key", headers=demo).text)
doc = db.ai_credentials.find_one({"user_id": uid})
check("stored encrypted (no plaintext in Mongo)", doc and KEY not in json.dumps(doc, default=str) and doc["enc"].startswith("gAAAA"))
check("masked shown", r.status_code == 200 and r.json()["masked"].endswith(KEY[-4:]) and len(r.json()["masked"]) < 12)

# 4) chat + multi-turn follow-up via BYOK
tag = uuid.uuid4().hex[:5]
c, body, conv = chat(demo, f"Remember that my cat is called Falcon{tag}.")
check("byok chat 1", c == 200 and not body["error"] and body["text"], body)
c, body, conv2 = chat(demo, "And what's its name again?", conv)
check("byok multi-turn follow-up recalls", c == 200 and f"Falcon{tag}".lower() in body["text"].lower(), body["text"])
c, body, _ = chat(demo, "What is the capital of France?", conv)
check("guardrail still blocks general knowledge on byok", c == 200 and "paris" not in body["text"].lower(), body["text"])
c, body, _ = chat(demo, "Mera kal ka kya plan hai? Hindi mein batao.", conv)
check("hinglish question answered in hindi/hinglish", c == 200 and body["text"] and not body["error"], body["text"])

# 5) text capture with BYOK
time.sleep(PAUSE)
r = requests.post(f"{BASE}/capture", json={"text": "kal 2 litre doodh aur bread lana hai", "client_id": "byoktest" + tag}, headers=demo, timeout=90).json()
check("byok capture hinglish groceries+task", r["ai"] and any(x["type"] == "add_grocery" for x in r["results"]), r)
r2 = requests.post(f"{BASE}/capture", json={"text": "kal 2 litre doodh aur bread lana hai", "client_id": "byoktest" + tag}, headers=demo, timeout=90).json()
check("capture retry idempotent (same response, nothing new)", r == r2)

# 6) voice: English, Hindi, mixed via Gemini audio on the user's key
for lang in ("en", "hi", "mix"):
    path = f"/tmp/voice/{lang}.mp3"
    if not os.path.exists(path):
        print("SKIP voice", lang)
        continue
    time.sleep(PAUSE * 2)
    with open(path, "rb") as f:
        r = requests.post(f"{BASE}/voice", files={"audio": (f"v.mp3", f, "audio/mpeg")}, headers={**demo, "X-Idempotency-Key": f"voice{lang}{tag}"}, timeout=150)
    j = r.json()
    check(f"voice {lang}: transcribed + organised", r.status_code == 200 and j.get("transcript") and j.get("results"),
          {"transcript": j.get("transcript"), "results": [(x["type"], x["data"].get("title") or x["data"].get("content"), x["data"].get("due_date"), x["data"].get("due_time")) for x in j.get("results", [])]})

# 7) billing: every call for this user since t0 went through byok, never universal
routes = {d["route"] for d in db.ai_billing.find({"user_id": uid, "at": {"$gte": t0}})}
check("all demo AI calls billed to BYOK, zero universal", routes == {"byok"}, routes)

# 8) stored key goes bad -> clear error, NO fallback to universal
from cryptography.fernet import Fernet  # noqa: E402
bad = Fernet(os.environ["BYOK_ENCRYPTION_KEY"].encode()).encrypt(b"AIzaSyBADBADBADBADBADBADBADBADBADBAD12").decode()
db.ai_credentials.update_one({"user_id": uid}, {"$set": {"enc": bad, "status": "valid"}})
t1 = datetime.now(timezone.utc).isoformat()
c, body, _ = chat(demo, "hello again")
check("revoked key: chat error byok_invalid", c == 200 and body["error"] and body["error"].get("code") == "byok_invalid", body)
check("revoked key marked invalid", db.ai_credentials.find_one({"user_id": uid})["status"] == "invalid")
c, body, _ = chat(demo, "hello again")
check("invalid key: next request 401 before any AI call", c == 401 and body.get("code") == "byok_invalid", body)
check("no universal fallback after failure", db.ai_billing.count_documents({"user_id": uid, "at": {"$gte": t1}, "route": "universal"}) == 0)

# 9) isolation: admin can't see demo's key or memories
check("admin GET /ai/key shows admin's own status only", requests.get(f"{BASE}/ai/key", headers=admin).json()["configured"] is False)
mem = [m for m in requests.get(f"{BASE}/memories", headers=admin).json() if f"Falcon{tag}" in m["content"]]
check("demo memory invisible to another user", not mem)

# cleanup
requests.delete(f"{BASE}/ai/key", headers=demo)
for m in requests.get(f"{BASE}/memories", headers=demo).json():
    if f"Falcon{tag}" in m["content"]:
        requests.delete(f"{BASE}/memories/{m['id']}", headers=demo)
for t in requests.get(f"{BASE}/tasks", headers=demo).json():
    if t.get("created_at", "") >= t0:
        requests.delete(f"{BASE}/tasks/{t['id']}", headers=demo)
for g in requests.get(f"{BASE}/groceries", headers=demo).json():
    if g.get("created_at", "") >= t0:
        requests.delete(f"{BASE}/groceries/{g['id']}", headers=demo)
print("ALL PASS" if ok_all else "SOME FAILED")
sys.exit(0 if ok_all else 1)

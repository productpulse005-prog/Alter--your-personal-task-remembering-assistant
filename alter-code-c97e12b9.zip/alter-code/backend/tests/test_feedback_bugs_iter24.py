# Iteration 24: bug-report area, admin email delivery, and analytics bug metrics
import os
import time
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com").rstrip("/")
ADMIN = {"email": "admin@example.com", "password": "<REDACTED_PASSWORD>"}
DEMO = {"email": "demo@alter.app", "password": "<REDACTED_PASSWORD>"}
CREATED = []


def login(creds):
    r = requests.post(f"{BASE_URL}/api/auth/login", json=creds, timeout=20)
    if r.status_code != 200:
        pytest.skip(f"login failed {r.status_code}")
    return {"Authorization": f"Bearer {r.json()['token']}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def admin_h():
    return login(ADMIN)


@pytest.fixture(scope="module")
def demo_h():
    return login(DEMO)


def analytics(h):
    r = requests.get(f"{BASE_URL}/api/admin/analytics?days=30&include_test=true", headers=h, timeout=60)
    assert r.status_code == 200, r.text
    return r.json()["bugs"]


def items(h):
    r = requests.get(f"{BASE_URL}/api/admin/feedback", headers=h, timeout=20)
    assert r.status_code == 200
    return {i["id"]: i for i in r.json()["items"]}


# --- Validation (no email sent) ---
class TestValidation:
    def test_bug_without_area_422(self, demo_h):
        r = requests.post(f"{BASE_URL}/api/feedback", headers=demo_h, json={"kind": "bug", "message": "TEST no area"})
        assert r.status_code == 422
        assert "which part of the app broke" in r.text

    def test_bug_invalid_area_422(self, demo_h):
        r = requests.post(f"{BASE_URL}/api/feedback", headers=demo_h, json={"kind": "bug", "area": "payments", "message": "TEST bad area"})
        assert r.status_code == 422

    def test_short_message_422(self, demo_h):
        r = requests.post(f"{BASE_URL}/api/feedback", headers=demo_h, json={"kind": "bug", "area": "chat", "message": "x"})
        assert r.status_code == 422

    def test_unauth_401(self):
        r = requests.post(f"{BASE_URL}/api/feedback", json={"kind": "bug", "area": "chat", "message": "TEST unauth"})
        assert r.status_code in (401, 403)

    def test_analytics_403_for_user(self, demo_h):
        r = requests.get(f"{BASE_URL}/api/admin/analytics?days=30", headers=demo_h)
        assert r.status_code == 403


# --- Create bugs, email, analytics counts, resolve ---
class TestBugFlow:
    def test_flow(self, demo_h, admin_h):
        before = analytics(admin_h)
        for k in ("total", "open", "by_area"):
            assert k in before
        r1 = requests.post(f"{BASE_URL}/api/feedback", headers=demo_h, json={"kind": "bug", "area": "alarms", "message": "TEST alarm did not ring", "screen": "/home"})
        assert r1.status_code == 201, r1.text
        r2 = requests.post(f"{BASE_URL}/api/feedback", headers=demo_h, json={"kind": "idea", "area": "voice", "message": "TEST idea with area ignored"})
        assert r2.status_code == 201, r2.text
        id1, id2 = r1.json()["id"], r2.json()["id"]
        CREATED.extend([id1, id2])
        time.sleep(6)
        it = items(admin_h)
        assert it[id1]["area"] == "alarms"
        assert it[id2]["area"] is None, "idea must store area=null"
        assert it[id1]["kind"] == "bug" and it[id1]["status"] == "new"
        assert it[id1].get("emailed") is True, f"email not marked sent: {it[id1]}"
        assert it[id1].get("email_id")
        assert it[id2].get("emailed") is True
        after = analytics(admin_h)
        assert after["total"] == before["total"] + 1
        assert after["open"] == before["open"] + 1
        assert after["by_area"].get("alarms", 0) == before["by_area"].get("alarms", 0) + 1
        assert sum(after["by_area"].values()) == after["total"]
        # resolve lowers open, not total
        p = requests.patch(f"{BASE_URL}/api/admin/feedback/{id1}", headers=admin_h, json={"status": "resolved"})
        assert p.status_code == 200
        assert items(admin_h)[id1]["status"] == "resolved"
        res = analytics(admin_h)
        assert res["open"] == after["open"] - 1
        assert res["total"] == after["total"]

    def test_patch_404(self, admin_h):
        r = requests.patch(f"{BASE_URL}/api/admin/feedback/000000000000000000000000", headers=admin_h, json={"status": "seen"})
        assert r.status_code == 404

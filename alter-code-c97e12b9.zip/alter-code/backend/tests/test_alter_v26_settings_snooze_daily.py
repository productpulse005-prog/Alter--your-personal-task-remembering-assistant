# Iteration 26: /api/me/usage, daily repeating alarms (capture + offline + roll-forward), gmail sync force guard, account deletion
import os
import sys
import time
import uuid
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import pytest
import requests
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv("/app/frontend/.env")
load_dotenv("/app/backend/.env")
BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL").rstrip("/")
ADMIN = {"email": "admin@example.com", "password": "<REDACTED_PASSWORD>"}
sys.path.insert(0, "/app/backend")


@pytest.fixture(scope="module")
def mdb():
    return MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]


@pytest.fixture(scope="module")
def client():
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/auth/login", json=ADMIN, timeout=30)
    if r.status_code != 200:
        pytest.skip(f"login failed {r.status_code}")
    s.headers.update({"Authorization": f"Bearer {r.json()['token']}", "Content-Type": "application/json"})
    s.created = []
    s.tz = s.get(f"{BASE_URL}/api/profile", timeout=30).json()["timezone"]
    yield s
    for tid in s.created:
        s.delete(f"{BASE_URL}/api/tasks/{tid}", timeout=30)
    s.put(f"{BASE_URL}/api/profile", json={"timezone": s.tz}, timeout=30)


# --- usage ---
class TestUsage:
    def test_usage_requires_auth(self):
        r = requests.get(f"{BASE_URL}/api/me/usage", timeout=30)
        assert r.status_code in (401, 403)

    def test_usage_shape(self, client):
        r = client.get(f"{BASE_URL}/api/me/usage", timeout=30)
        assert r.status_code == 200, r.text
        d = r.json()
        print(d)
        for k in ("own_key", "my_calls_today", "my_limit", "shared_used", "shared_limit", "resets_at"):
            assert k in d
        assert isinstance(d["own_key"], bool)
        assert isinstance(d["my_calls_today"], int) and isinstance(d["shared_used"], int)
        assert isinstance(d["shared_limit"], int) and d["shared_limit"] >= 0
        assert datetime.fromisoformat(d["resets_at"].replace("Z", "+00:00")) > datetime.now(ZoneInfo("UTC"))


# --- offline_alarm unit ---
class TestOfflineAlarm:
    def test_daily_yoga(self):
        import server
        a = server.offline_alarm("wake me up daily at 6:30 for yoga")
        assert a and a["alarm"] is True and a["due_time"] == "06:30"
        assert a["recurrence"] == "daily"
        assert a["title"] == "Yoga", a

    def test_every_day_6am(self):
        import server
        a = server.offline_alarm("alarm every day at 6am")
        assert a and a["due_time"] == "06:00" and a["recurrence"] == "daily"
        assert a["title"] == "Alarm", a

    def test_weekdays(self):
        import server
        a = server.offline_alarm("set an alarm every weekday at 7am for gym")
        assert a and a["due_time"] == "07:00" and a["recurrence"] == "weekdays", a
        assert a["title"].lower() == "gym", a

    def test_non_repeating(self):
        import server
        a = server.offline_alarm("set an alarm for 7am to go to the gym")
        assert a and a["recurrence"] is None


# --- capture (AI) ---
class TestCaptureDaily:
    def test_capture_alarm_every_day_6am(self, client):
        r = client.post(f"{BASE_URL}/api/capture", json={"text": "alarm every day at 6am"}, timeout=90)
        assert r.status_code == 200, r.text
        body = r.json()
        print(body)
        tasks = client.get(f"{BASE_URL}/api/tasks", timeout=30).json()
        mine = [t for t in tasks if t.get("alarm") and t.get("due_time") == "06:00" and t.get("recurrence") == "daily"]
        for t in tasks:
            if t["created_at"] >= (datetime.utcnow() - timedelta(minutes=2)).isoformat():
                client.created.append(t["id"])
        assert mine, f"no daily 06:00 alarm task; response={body}"
        t = mine[0]
        now = datetime.now(ZoneInfo(client.tz))
        exp = now.date() if now.strftime("%H:%M") < "06:00" else (now + timedelta(days=1)).date()
        assert t["due_date"] == exp.isoformat(), t


# --- roll forward ---
class TestRollForward:
    def test_past_daily_alarm_rolls_forward(self, client, mdb):
        r = client.post(f"{BASE_URL}/api/tasks", json={"title": "TEST_roll daily alarm", "due_date": datetime.now().strftime("%Y-%m-%d"),
                                                      "due_time": "06:00", "alarm": True, "recurrence": "daily", "priority": "high"}, timeout=30)
        assert r.status_code == 201, r.text
        tid = r.json()["id"]
        client.created.append(tid)
        from bson import ObjectId
        past = (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%d")
        mdb.tasks.update_one({"_id": ObjectId(tid)}, {"$set": {"due_date": past}})
        tasks = client.get(f"{BASE_URL}/api/tasks", timeout=30).json()
        t = next(x for x in tasks if x["id"] == tid)
        now = datetime.now(ZoneInfo(client.tz))
        exp = now.date() if now.strftime("%H:%M") < "06:00" else (now + timedelta(days=1)).date()
        assert t["due_date"] == exp.isoformat(), t
        assert t["status"] == "todo"
        # only one copy (no spawn)
        assert len([x for x in tasks if x["title"] == "TEST_roll daily alarm"]) == 1

    def test_non_alarm_recurring_not_rolled(self, client, mdb):
        r = client.post(f"{BASE_URL}/api/tasks", json={"title": "TEST_roll plain recurring", "due_date": datetime.now().strftime("%Y-%m-%d"),
                                                      "due_time": "06:00", "alarm": False, "recurrence": "daily"}, timeout=30)
        tid = r.json()["id"]
        client.created.append(tid)
        from bson import ObjectId
        past = (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d")
        mdb.tasks.update_one({"_id": ObjectId(tid)}, {"$set": {"due_date": past}})
        t = next(x for x in client.get(f"{BASE_URL}/api/tasks", timeout=30).json() if x["id"] == tid)
        assert t["due_date"] == past

    def test_weekly_alarm_rolls_forward(self, client, mdb):
        r = client.post(f"{BASE_URL}/api/tasks", json={"title": "TEST_roll weekly alarm", "due_date": datetime.now().strftime("%Y-%m-%d"),
                                                      "due_time": "00:01", "alarm": True, "recurrence": "weekly"}, timeout=30)
        tid = r.json()["id"]
        client.created.append(tid)
        from bson import ObjectId
        past = (datetime.now() - timedelta(days=15)).strftime("%Y-%m-%d")
        mdb.tasks.update_one({"_id": ObjectId(tid)}, {"$set": {"due_date": past}})
        t = next(x for x in client.get(f"{BASE_URL}/api/tasks", timeout=30).json() if x["id"] == tid)
        today = datetime.now(ZoneInfo(client.tz)).date()
        d = datetime.strptime(t["due_date"], "%Y-%m-%d").date()
        assert d > today and (d - datetime.strptime(past, "%Y-%m-%d").date()).days % 7 == 0, t


# --- gmail sync force ---
class TestGmailSync:
    def test_force_sync(self, client):
        r1 = client.post(f"{BASE_URL}/api/gmail/sync?force=true", timeout=60)
        print(r1.status_code, r1.text)
        if r1.status_code == 400:
            assert "Connect your Google account first" in r1.json().get("detail", "")
            return
        assert r1.status_code == 200
        r2 = client.post(f"{BASE_URL}/api/gmail/sync?force=true", timeout=60)
        assert r2.json().get("skipped") in ("recent", "busy"), r2.text

    def test_sync_requires_auth(self):
        assert requests.post(f"{BASE_URL}/api/gmail/sync?force=true", timeout=30).status_code in (401, 403)


# --- timezone + delete account ---
class TestAccount:
    def test_invalid_timezone_rejected(self, client):
        r = client.put(f"{BASE_URL}/api/profile", json={"timezone": "Mars/Olympus"}, timeout=30)
        assert r.status_code in (400, 422), r.text

    def test_delete_throwaway_account(self):
        email = f"test_del_{uuid.uuid4().hex[:8]}@example.com"
        r = requests.post(f"{BASE_URL}/api/auth/register", json={"email": email, "password": "testpass123", "display_name": "TEST Del"}, timeout=30)
        assert r.status_code in (200, 201), r.text
        h = {"Authorization": f"Bearer {r.json()['token']}"}
        requests.post(f"{BASE_URL}/api/tasks", json={"title": "TEST_x"}, headers=h, timeout=30)
        d = requests.delete(f"{BASE_URL}/api/account", headers=h, timeout=30)
        assert d.status_code == 200 and d.json().get("ok") is True
        assert requests.get(f"{BASE_URL}/api/auth/me", headers=h, timeout=30).status_code == 401
        assert requests.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": "testpass123"}, timeout=30).status_code in (400, 401)

"""Iteration 16 — Task duplicate protection across sources.

Covers:
  * POST /api/tasks dedupe (title + due_date + due_time), case/punctuation
    tolerance, different-date -> allowed, different-time -> allowed,
    completed-same-day -> still blocks.
  * Chat path: twice 'Add task: buy flowers on 2026-11-02' -> second
    create_task action is {status:success, detail:'Already on your list — not
    added twice'} and only one such task exists in GET /api/tasks.
  * Calendar sync dedupe via monkeypatched httpx (3 serial + 3 concurrent
    runs). Pre-existing manual task on same date/time + same title is linked
    (no new task). Event moved to new time -> the linked task's due_time is
    updated on next sync.

All test data is cleaned up in finally/teardown.

Running: motor binds to the loop at import; run with:
  cd /app/backend && python -m pytest tests/test_alter_v16_dedupe.py \
    -p asyncio -o asyncio_mode=strict -n 0
(The asyncio tests use loop_scope="session".)
"""
from __future__ import annotations

import asyncio
import os
import sys
import time
from pathlib import Path

import httpx
import pytest
import requests

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

BASE_URL = os.environ.get(
    "EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com"
).rstrip("/")
API = f"{BASE_URL}/api"

DEMO_EMAIL = "demo@alter.app"
DEMO_PASSWORD = "<REDACTED_PASSWORD>"


# ---------------------------------------------------------------------------
# HTTP (requests) based tests — API-level dedupe
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def demo_token():
    r = requests.post(
        f"{API}/auth/login",
        json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD},
        timeout=15,
    )
    assert r.status_code == 200, r.text
    tok = r.json()["token"]
    return tok


@pytest.fixture()
def auth(demo_token):
    s = requests.Session()
    s.headers.update(
        {"Content-Type": "application/json", "Authorization": f"Bearer {demo_token}"}
    )
    return s


def _delete_task(auth, tid):
    try:
        auth.delete(f"{API}/tasks/{tid}", timeout=10)
    except Exception:
        pass


class TestTaskPostDedupe:
    """POST /api/tasks dedupe behaviour."""

    def test_same_title_same_date_second_returns_409(self, auth):
        title = f"TEST_dup_dentist_{int(time.time())}"
        due = "2026-10-05"
        c = auth.post(f"{API}/tasks", json={"title": title, "due_date": due}, timeout=15)
        assert c.status_code == 201, c.text
        tid = c.json()["id"]
        try:
            c2 = auth.post(
                f"{API}/tasks", json={"title": title, "due_date": due}, timeout=15
            )
            assert c2.status_code == 409, c2.text
            detail = c2.json().get("detail", "")
            assert "is already on your list" in detail
            assert due in detail
        finally:
            _delete_task(auth, tid)

    def test_case_and_punctuation_variant_still_409(self, auth):
        base = f"TEST_dedupe_{int(time.time())} dentist appointment"
        due = "2026-10-06"
        c = auth.post(f"{API}/tasks", json={"title": base, "due_date": due}, timeout=15)
        assert c.status_code == 201, c.text
        tid = c.json()["id"]
        try:
            variants = [
                base.upper(),
                base + "!",
                base.replace(" ", "   "),
                base.title() + "...",
            ]
            for v in variants:
                r = auth.post(
                    f"{API}/tasks", json={"title": v, "due_date": due}, timeout=15
                )
                assert r.status_code == 409, f"variant '{v}' expected 409 got {r.status_code} {r.text}"
                assert "already on your list" in r.json().get("detail", "")
        finally:
            _delete_task(auth, tid)

    def test_same_title_different_date_allowed(self, auth):
        title = f"TEST_dup_different_day_{int(time.time())} dentist"
        c1 = auth.post(
            f"{API}/tasks", json={"title": title, "due_date": "2026-10-07"}, timeout=15
        )
        c2 = auth.post(
            f"{API}/tasks", json={"title": title, "due_date": "2026-10-08"}, timeout=15
        )
        try:
            assert c1.status_code == 201
            assert c2.status_code == 201, c2.text
            assert c1.json()["id"] != c2.json()["id"]
        finally:
            for r in (c1, c2):
                if r.status_code == 201:
                    _delete_task(auth, r.json()["id"])

    def test_same_title_different_time_same_day_allowed(self, auth):
        title = f"TEST_dup_time_{int(time.time())} standup"
        due = "2026-10-09"
        c1 = auth.post(
            f"{API}/tasks",
            json={"title": title, "due_date": due, "due_time": "10:00"},
            timeout=15,
        )
        c2 = auth.post(
            f"{API}/tasks",
            json={"title": title, "due_date": due, "due_time": "15:00"},
            timeout=15,
        )
        try:
            assert c1.status_code == 201, c1.text
            assert c2.status_code == 201, c2.text
            assert c1.json()["id"] != c2.json()["id"]
        finally:
            for r in (c1, c2):
                if r.status_code == 201:
                    _delete_task(auth, r.json()["id"])

    def test_completed_same_title_date_still_blocks(self, auth):
        title = f"TEST_dup_completed_{int(time.time())} dentist"
        due = "2026-10-10"
        c = auth.post(
            f"{API}/tasks",
            json={"title": title, "due_date": due, "status": "completed"},
            timeout=15,
        )
        assert c.status_code == 201, c.text
        tid = c.json()["id"]
        try:
            r = auth.post(
                f"{API}/tasks", json={"title": title, "due_date": due}, timeout=15
            )
            assert r.status_code == 409, r.text
            assert "already on your list" in r.json().get("detail", "")
        finally:
            _delete_task(auth, tid)


class TestChatDedupe:
    """Chat endpoint create_task action must not duplicate."""

    def test_chat_duplicate_create_task(self, auth):
        due = "2026-11-02"
        title_substr = "buy flowers"
        prompt = f"Add task: buy flowers on {due}"

        # Clean any pre-existing flowers task from previous aborted runs
        existing = auth.get(f"{API}/tasks", timeout=15).json()
        for t in existing:
            if "flower" in (t.get("title") or "").lower() and t.get("due_date") == due:
                _delete_task(auth, t["id"])

        def chat(msg):
            """Parse SSE stream from /api/chat and collect any 'actions' events."""
            import json as _json

            r = auth.post(f"{API}/chat", json={"message": msg}, timeout=120, stream=True)
            assert r.status_code == 200, r.text
            all_actions: list[dict] = []
            try:
                for raw_line in r.iter_lines(decode_unicode=True):
                    if not raw_line:
                        continue
                    # SSE lines: "data: {...}"
                    if raw_line.startswith("data:"):
                        payload = raw_line[5:].strip()
                        if not payload:
                            continue
                        try:
                            evt = _json.loads(payload)
                        except Exception:
                            continue
                        if evt.get("type") == "actions":
                            all_actions.extend(evt.get("actions") or [])
                        elif evt.get("type") == "done":
                            break
            finally:
                r.close()
            return {"actions": all_actions}

        created_ids = []
        try:
            r1 = chat(prompt)
            actions1 = [a for a in r1.get("actions", []) if a.get("type") == "create_task"]
            if not actions1:
                pytest.skip(f"LLM did not emit create_task action for first turn: {r1}")
            a1 = actions1[0]
            assert a1.get("status") == "success"
            assert "already on your list" not in (a1.get("detail") or "").lower()
            tid1 = a1.get("data", {}).get("id")
            if tid1:
                created_ids.append(tid1)

            r2 = chat(prompt)
            actions2 = [a for a in r2.get("actions", []) if a.get("type") == "create_task"]
            # Dedupe can happen in two valid ways:
            #   (a) LLM still emits create_task -> server returns status=success with
            #       detail "Already on your list — not added twice"  (preferred, documented)
            #   (b) LLM reads context, sees the task exists, and skips emitting an action
            # Both must result in only ONE task in the DB.
            if actions2:
                a2 = actions2[0]
                assert a2.get("status") == "success", a2
                assert "already on your list" in (a2.get("detail") or "").lower(), (
                    f"Expected dedupe detail on 2nd turn, got: {a2}"
                )
            else:
                print(
                    "WARN: LLM did not emit create_task on 2nd turn (context-aware skip); "
                    "falling back to task-count assertion only."
                )

            # Only ONE such task exists
            lst = auth.get(f"{API}/tasks", timeout=15).json()
            matches = [
                t
                for t in lst
                if t.get("due_date") == due
                and title_substr in (t.get("title") or "").lower()
            ]
            assert len(matches) == 1, f"expected 1 flowers task, got {len(matches)}: {matches}"
        finally:
            # Clean up any flowers task
            lst = auth.get(f"{API}/tasks", timeout=15).json()
            for t in lst:
                if "flower" in (t.get("title") or "").lower() and t.get("due_date") == due:
                    _delete_task(auth, t["id"])


# ---------------------------------------------------------------------------
# Calendar sync dedupe via monkeypatched httpx (direct server import)
# ---------------------------------------------------------------------------
import server  # noqa: E402

FAKE_EVENT_ID = "TEST_EVT_v16_dedupe_001"
FAKE_SUMMARY = "TEST_v16 Team lunch"
FAKE_START_UTC = "2099-02-10T10:00:00+00:00"  # tz-aware; after conversion to UTC profile => "10:00"
FAKE_START_UTC_MOVED = "2099-02-10T15:30:00+00:00"


def _fake_client_factory(start_dt_iso: str, summary: str = FAKE_SUMMARY):
    class _FakeAsyncClient:
        def __init__(self, *a, **kw):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *exc):
            return False

        async def get(self, url, headers=None, params=None):
            payload = {
                "items": [
                    {
                        "id": FAKE_EVENT_ID,
                        "status": "confirmed",
                        "summary": summary,
                        "start": {"dateTime": start_dt_iso},
                        "end": {"dateTime": start_dt_iso},
                    }
                ]
            }
            return httpx.Response(200, json=payload, request=httpx.Request("GET", url))

    return _FakeAsyncClient


async def _demo_user_id():
    user = await server.db.users.find_one({"email": DEMO_EMAIL})
    assert user, "demo user missing"
    uid = str(user["_id"])
    await server.get_profile(server.User.from_mongo(user))
    return uid


async def _cleanup_cal(user_id: str, titles: list[str]):
    await server.db.gmail_processed.delete_many(
        {"user_id": user_id, "gmail_id": f"cal:{FAKE_EVENT_ID}"}
    )
    await server.db.tasks.delete_many({"user_id": user_id, "title": {"$in": titles}})


@pytest.mark.asyncio(loop_scope="session")
async def test_calendar_sync_three_serial_calls_only_one_task(monkeypatch):
    user_id = await _demo_user_id()
    await _cleanup_cal(user_id, [FAKE_SUMMARY])

    monkeypatch.setattr(server.httpx, "AsyncClient", _fake_client_factory(FAKE_START_UTC))
    try:
        totals = []
        for _ in range(3):
            added, err = await server._calendar_tasks(user_id, {"Authorization": "Bearer FAKE"})
            assert err is None, err
            totals.append(added)
        assert totals[0] == 1, totals
        assert totals[1] == 0 and totals[2] == 0, totals

        tasks = await server.db.tasks.find(
            {"user_id": user_id, "title": FAKE_SUMMARY, "source": "calendar"}
        ).to_list(10)
        assert len(tasks) == 1, f"expected 1 task, got {len(tasks)}"

        gp = await server.db.gmail_processed.find(
            {"user_id": user_id, "gmail_id": f"cal:{FAKE_EVENT_ID}"}
        ).to_list(5)
        assert len(gp) == 1
    finally:
        await _cleanup_cal(user_id, [FAKE_SUMMARY])


@pytest.mark.asyncio(loop_scope="session")
async def test_calendar_sync_three_concurrent_calls_only_one_task(monkeypatch):
    user_id = await _demo_user_id()
    await _cleanup_cal(user_id, [FAKE_SUMMARY])

    monkeypatch.setattr(server.httpx, "AsyncClient", _fake_client_factory(FAKE_START_UTC))
    try:
        results = await asyncio.gather(
            *[server._calendar_tasks(user_id, {"Authorization": "Bearer FAKE"}) for _ in range(3)]
        )
        added_total = sum(r[0] for r in results)
        # Exactly one of the three concurrent calls should have added the task
        assert added_total == 1, f"expected 1 added across concurrent calls, got {added_total}: {results}"

        tasks = await server.db.tasks.find(
            {"user_id": user_id, "title": FAKE_SUMMARY, "source": "calendar"}
        ).to_list(10)
        assert len(tasks) == 1, f"expected 1 task, got {len(tasks)}"

        gp = await server.db.gmail_processed.find(
            {"user_id": user_id, "gmail_id": f"cal:{FAKE_EVENT_ID}"}
        ).to_list(5)
        assert len(gp) == 1
    finally:
        await _cleanup_cal(user_id, [FAKE_SUMMARY])


@pytest.mark.asyncio(loop_scope="session")
async def test_calendar_sync_links_to_existing_manual_task(monkeypatch):
    """Pre-existing manual task 'Team lunch' same date/time -> sync should NOT create a new task,
    gmail_processed doc must link task_id to the manual task."""
    user_id = await _demo_user_id()
    manual_title = FAKE_SUMMARY  # same title as calendar event
    due_date = "2099-02-10"
    due_time = "10:00"

    await _cleanup_cal(user_id, [manual_title])

    # Insert manual task first
    manual = await server.insert_task(
        user_id,
        server.TaskIn(title=manual_title, due_date=due_date, due_time=due_time),
        source="manual",
    )
    manual_id = manual.id

    monkeypatch.setattr(server.httpx, "AsyncClient", _fake_client_factory(FAKE_START_UTC))
    try:
        added, err = await server._calendar_tasks(user_id, {"Authorization": "Bearer FAKE"})
        assert err is None
        assert added == 0, f"expected 0 added when manual exists, got {added}"

        # Only one task
        tasks = await server.db.tasks.find(
            {"user_id": user_id, "title": manual_title}
        ).to_list(10)
        assert len(tasks) == 1, f"expected 1 task total, got {len(tasks)}"
        assert str(tasks[0]["_id"]) == manual_id
        # Manual task should still be source=manual (not clobbered to calendar)
        assert tasks[0].get("source") == "manual"

        # gmail_processed must link to that manual task
        gp = await server.db.gmail_processed.find_one(
            {"user_id": user_id, "gmail_id": f"cal:{FAKE_EVENT_ID}"}
        )
        assert gp is not None, "gmail_processed row missing"
        assert gp.get("task_id") == manual_id, f"task_id should link to manual: {gp}"
    finally:
        await _cleanup_cal(user_id, [manual_title])


@pytest.mark.asyncio(loop_scope="session")
async def test_calendar_event_moved_updates_linked_task(monkeypatch):
    """First sync: event at 10:00 creates a task. Second sync: same event at 15:30
    updates the linked task's due_time to 15:30."""
    user_id = await _demo_user_id()
    await _cleanup_cal(user_id, [FAKE_SUMMARY])

    try:
        # First sync at original time
        monkeypatch.setattr(server.httpx, "AsyncClient", _fake_client_factory(FAKE_START_UTC))
        added, err = await server._calendar_tasks(user_id, {"Authorization": "Bearer FAKE"})
        assert err is None
        assert added == 1

        tasks = await server.db.tasks.find(
            {"user_id": user_id, "title": FAKE_SUMMARY, "source": "calendar"}
        ).to_list(5)
        assert len(tasks) == 1
        tid = str(tasks[0]["_id"])
        original_time = tasks[0].get("due_time")
        assert original_time == "10:00", original_time

        # Second sync: event moved
        monkeypatch.setattr(
            server.httpx, "AsyncClient", _fake_client_factory(FAKE_START_UTC_MOVED)
        )
        added2, err2 = await server._calendar_tasks(user_id, {"Authorization": "Bearer FAKE"})
        assert err2 is None
        assert added2 == 0  # No new task — just an update

        updated = await server.db.tasks.find_one({"_id": tasks[0]["_id"]})
        assert updated is not None
        assert updated.get("due_time") == "15:30", f"expected 15:30, got {updated.get('due_time')}"
        # Still the same task id
        assert str(updated["_id"]) == tid

        # gmail_processed row updated
        gp = await server.db.gmail_processed.find_one(
            {"user_id": user_id, "gmail_id": f"cal:{FAKE_EVENT_ID}"}
        )
        assert gp and gp.get("due_time") == "15:30"
    finally:
        await _cleanup_cal(user_id, [FAKE_SUMMARY])

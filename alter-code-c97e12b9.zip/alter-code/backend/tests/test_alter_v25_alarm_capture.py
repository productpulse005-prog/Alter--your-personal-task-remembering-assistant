# Iteration 25: alarm-as-task (capture + Task model alarm field), one-row home capture, offline_alarm fallback
import os
import sys
import time
from datetime import datetime, timedelta

import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com").rstrip("/")
ADMIN = {"email": "admin@example.com", "password": "<REDACTED_PASSWORD>"}


@pytest.fixture(scope="module")
def client():
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/auth/login", json=ADMIN, timeout=30)
    if r.status_code != 200:
        pytest.skip(f"login failed {r.status_code}")
    s.headers.update({"Authorization": f"Bearer {r.json()['token']}", "Content-Type": "application/json"})
    s.created_tasks = []
    s.created_groceries_before = {g["id"] for g in s.get(f"{BASE_URL}/api/groceries", timeout=30).json()} if s.get(f"{BASE_URL}/api/groceries", timeout=30).status_code == 200 else set()
    yield s
    for tid in s.created_tasks:
        s.delete(f"{BASE_URL}/api/tasks/{tid}", timeout=30)
    g = s.get(f"{BASE_URL}/api/groceries", timeout=30)
    if g.status_code == 200:
        for it in g.json():
            if it["id"] not in s.created_groceries_before:
                s.delete(f"{BASE_URL}/api/groceries/{it['id']}", timeout=30)


# --- offline_alarm unit tests (no AI) ---
sys.path.insert(0, "/app/backend")


def _offline():
    try:
        import server  # noqa
        return server.offline_alarm
    except Exception as e:  # pragma: no cover
        pytest.skip(f"cannot import server: {e}")


@pytest.mark.parametrize("text,time_,title", [
    ("wake me up at 6:30", "06:30", "Alarm"),
    ("set an alarm for 7am to go to the gym", "07:00", "Go to the gym"),
    ("alarm at 5pm for medicine", "17:00", None),
    ("alarm laga do 5 baje", "05:00", None),
    ("set alarm 12am", "00:00", None),
])
def test_offline_alarm_parses(text, time_, title):
    f = _offline()
    a = f(text)
    assert a is not None, text
    assert a["alarm"] is True and a["type"] == "create_task"
    assert a["due_time"] == time_
    if title:
        assert a["title"] == title
    print(text, "->", a)


@pytest.mark.parametrize("text", ["call plumber tomorrow at 5pm", "buy milk", "alarm the neighbours", "wake me up at 6"])
def test_offline_alarm_none(text):
    print(text, "->", _offline()(text))
    if text != "wake me up at 6":
        assert _offline()(text) is None


# --- Task CRUD with alarm ---
def test_create_task_with_alarm_and_update(client):
    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    r = client.post(f"{BASE_URL}/api/tasks", json={"title": "TEST_alarm task", "due_date": tomorrow, "due_time": "08:15", "priority": "high", "alarm": True}, timeout=30)
    assert r.status_code in (200, 201), r.text
    t = r.json()
    client.created_tasks.append(t["id"])
    assert t["alarm"] is True
    g = client.get(f"{BASE_URL}/api/tasks", timeout=30).json()
    row = next(x for x in g if x["id"] == t["id"])
    assert row["alarm"] is True and row["due_time"] == "08:15"
    u = client.put(f"{BASE_URL}/api/tasks/{t['id']}", json={"alarm": False}, timeout=30)
    assert u.status_code == 200, u.text
    assert u.json()["alarm"] is False
    row = next(x for x in client.get(f"{BASE_URL}/api/tasks", timeout=30).json() if x["id"] == t["id"])
    assert row["alarm"] is False


def test_task_default_alarm_false(client):
    r = client.post(f"{BASE_URL}/api/tasks", json={"title": "TEST_no alarm"}, timeout=30)
    assert r.status_code in (200, 201)
    client.created_tasks.append(r.json()["id"])
    assert r.json()["alarm"] is False


# --- /api/capture (AI, uses quota: keep to 3 calls) ---
def _capture(client, text):
    r = client.post(f"{BASE_URL}/api/capture", json={"text": text, "client_id": f"test{int(time.time()*1000)}"}, timeout=90)
    assert r.status_code == 200, r.text
    d = r.json()
    print(text, "->", d)
    for a in d.get("results", []):
        if a["type"] == "create_task" and a.get("data", {}).get("id"):
            client.created_tasks.append(a["data"]["id"])
    return d


def test_capture_alarm(client):
    d = _capture(client, "TEST set an alarm for 7am to go to the gym")
    tasks = [a for a in d["results"] if a["type"] == "create_task" and a["status"] == "success"]
    assert tasks, d
    data = tasks[0]["data"]
    assert data.get("alarm") is True, data
    assert data["due_time"] == "07:00"
    now = datetime.now()  # server tz may differ; accept today or tomorrow
    assert data["due_date"] in (now.strftime("%Y-%m-%d"), (now + timedelta(days=1)).strftime("%Y-%m-%d"), (now - timedelta(days=1)).strftime("%Y-%m-%d"))


def test_capture_grocery(client):
    time.sleep(5)
    d = _capture(client, "buy TESTmilk and TESTeggs")
    assert any(a["type"] == "add_grocery" and a["status"] == "success" for a in d["results"]), d


def test_capture_task(client):
    time.sleep(5)
    d = _capture(client, "TEST call plumber tomorrow at 5pm")
    tasks = [a for a in d["results"] if a["type"] == "create_task" and a["status"] == "success"]
    assert tasks, d
    assert not tasks[0]["data"].get("alarm"), tasks[0]["data"]

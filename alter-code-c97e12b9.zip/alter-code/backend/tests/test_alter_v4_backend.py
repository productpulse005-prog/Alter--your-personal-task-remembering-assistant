"""Iteration 5: /api/tts (mascot + spoken replies) + regression (chat send + grocery add)."""
import os
import uuid
import pytest
import requests

BASE = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com").rstrip("/")


def _reg(prefix="tts"):
    email = f"TEST_{prefix}_{uuid.uuid4().hex[:8]}@alter.app"
    r = requests.post(
        f"{BASE}/api/auth/register",
        json={"email": email, "password": "pass12345", "display_name": "TTSUser", "timezone": "Europe/London"},
    )
    assert r.status_code == 201, r.text
    return email, r.json()["token"], {"Authorization": f"Bearer {r.json()['token']}"}


# ---------------------------- POST /api/tts ----------------------------
class TestTTS:
    def test_unauth_401(self):
        r = requests.post(f"{BASE}/api/tts", json={"text": "Hello"})
        assert r.status_code == 401, r.text

    def test_empty_text_422(self):
        _, _, h = _reg("empty")
        r = requests.post(f"{BASE}/api/tts", json={"text": ""}, headers=h)
        # min_length=1 pydantic validator → 422
        assert r.status_code in (400, 422), r.text

    def test_whitespace_only_400(self):
        _, _, h = _reg("ws")
        r = requests.post(f"{BASE}/api/tts", json={"text": "   "}, headers=h)
        # passes length=3 but clean_for_tts strips -> empty -> 400
        assert r.status_code == 400, r.text

    def test_valid_text_returns_url(self):
        _, _, h = _reg("ok")
        r = requests.post(f"{BASE}/api/tts", json={"text": "Hello there friend"}, headers=h, timeout=60)
        assert r.status_code == 200, r.text
        body = r.json()
        assert "url" in body
        assert body["url"].startswith("/api/tts/") and body["url"].endswith(".mp3")

    def test_get_audio_200_mpeg(self):
        _, _, h = _reg("audio")
        r = requests.post(f"{BASE}/api/tts", json={"text": "Have a lovely day"}, headers=h, timeout=60)
        assert r.status_code == 200, r.text
        url = r.json()["url"]
        g = requests.get(f"{BASE}{url}", timeout=30)
        assert g.status_code == 200, g.text
        ctype = g.headers.get("content-type", "")
        assert "audio/mpeg" in ctype, ctype
        assert len(g.content) > 1000, f"audio bytes too small: {len(g.content)}"

    def test_unknown_key_404(self):
        r = requests.get(f"{BASE}/api/tts/deadbeefdeadbeefdeadbeefdeadbeef.mp3", timeout=15)
        assert r.status_code == 404, r.text

    def test_markdown_stripped_same_key(self):
        _, _, h = _reg("md")
        plain = "Great job finishing the task"
        md = f"**{plain}**"
        r1 = requests.post(f"{BASE}/api/tts", json={"text": plain}, headers=h, timeout=60)
        r2 = requests.post(f"{BASE}/api/tts", json={"text": md}, headers=h, timeout=60)
        assert r1.status_code == 200 and r2.status_code == 200, (r1.text, r2.text)
        # markdown stripped → same cache key → same url
        assert r1.json()["url"] == r2.json()["url"]
        # both urls fetchable
        for u in (r1.json()["url"], r2.json()["url"]):
            g = requests.get(f"{BASE}{u}", timeout=30)
            assert g.status_code == 200
            assert "audio/mpeg" in g.headers.get("content-type", "")


# ---------------------------- Regression ----------------------------
class TestRegression:
    def test_chat_send_streams_reply(self):
        r = requests.post(f"{BASE}/api/auth/login",
                          json={"email": "demo@alter.app", "password": "<REDACTED_PASSWORD>"})
        assert r.status_code == 200, r.text
        h = {"Authorization": f"Bearer {r.json()['token']}"}
        # start a thread + send message (SSE)
        payload = {"message": "Say hi in one short sentence."}
        r = requests.post(f"{BASE}/api/chat", headers=h, json=payload, timeout=60, stream=True)
        assert r.status_code == 200, r.text
        chunks = b""
        for chunk in r.iter_content(chunk_size=1024):
            chunks += chunk
            if len(chunks) > 32:
                break
        assert len(chunks) > 0

    def test_grocery_add_delete(self):
        r = requests.post(f"{BASE}/api/auth/login",
                          json={"email": "demo@alter.app", "password": "<REDACTED_PASSWORD>"})
        assert r.status_code == 200, r.text
        h = {"Authorization": f"Bearer {r.json()['token']}"}
        r = requests.post(f"{BASE}/api/groceries", headers=h, json={"name": "TEST_tts_apples"})
        assert r.status_code == 201, r.text
        gid = r.json()["id"]
        # verify persisted
        g = requests.get(f"{BASE}/api/groceries", headers=h)
        assert any(x["id"] == gid for x in g.json())
        d = requests.delete(f"{BASE}/api/groceries/{gid}", headers=h)
        assert d.status_code in (200, 204), d.text

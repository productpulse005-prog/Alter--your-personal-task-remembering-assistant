"""Iteration 7 — admin analytics, role-based access, seed idempotency, activity tracking."""
import os
import time
import uuid

import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com").rstrip("/")
ADMIN_EMAIL = "admin@alter.app"
ADMIN_PASSWORD = "Alter-vo9bKkDD86uX"
DEMO_EMAIL = "demo@alter.app"
DEMO_PASSWORD = "<REDACTED_PASSWORD>"

REQUIRED_TOTAL_KEYS = {
    "users", "dau", "wau", "mau", "stickiness_pct", "new_users_7d",
    "sessions", "avg_session_min", "median_session_min",
    "sessions_per_active_day", "families",
}
REQUIRED_SERIES_KEYS = {"day", "active_users", "sessions", "new_users", "avg_session_min", "actions"}
REQUIRED_TOP = {
    "days", "generated_at", "totals", "series", "session_buckets",
    "hours", "churn", "retention", "features", "recent_users",
}


def login(email, password):
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": password}, timeout=20)
    assert r.status_code == 200, f"login {email} -> {r.status_code} {r.text}"
    return r.json()["token"]


def auth(token):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


# ---------------- Auth / role ----------------

class TestAuthRoles:
    def test_admin_login_and_role(self):
        t = login(ADMIN_EMAIL, ADMIN_PASSWORD)
        r = requests.get(f"{BASE_URL}/api/auth/me", headers=auth(t), timeout=20)
        assert r.status_code == 200
        data = r.json()
        assert data["user"]["email"] == ADMIN_EMAIL
        assert data["user"]["role"] == "admin"

    def test_demo_login_and_role(self):
        t = login(DEMO_EMAIL, DEMO_PASSWORD)
        r = requests.get(f"{BASE_URL}/api/auth/me", headers=auth(t), timeout=20)
        assert r.status_code == 200
        assert r.json()["user"]["role"] == "user"


# ---------------- /api/admin/analytics authorisation ----------------

class TestAnalyticsAuthz:
    def test_no_token_401(self):
        r = requests.get(f"{BASE_URL}/api/admin/analytics", timeout=20)
        assert r.status_code == 401

    def test_demo_forbidden(self):
        t = login(DEMO_EMAIL, DEMO_PASSWORD)
        r = requests.get(f"{BASE_URL}/api/admin/analytics", headers=auth(t), timeout=20)
        assert r.status_code == 403

    def test_days_below_min_422(self):
        t = login(ADMIN_EMAIL, ADMIN_PASSWORD)
        r = requests.get(f"{BASE_URL}/api/admin/analytics?days=3", headers=auth(t), timeout=20)
        assert r.status_code == 422


# ---------------- Analytics shape for 7/30/90 ----------------

@pytest.fixture(scope="module")
def admin_token():
    return login(ADMIN_EMAIL, ADMIN_PASSWORD)


@pytest.mark.parametrize("days", [7, 30, 90])
def test_analytics_shape(admin_token, days):
    r = requests.get(f"{BASE_URL}/api/admin/analytics?days={days}", headers=auth(admin_token), timeout=30)
    assert r.status_code == 200, r.text
    data = r.json()
    missing_top = REQUIRED_TOP - set(data.keys())
    assert not missing_top, f"missing top keys for days={days}: {missing_top}"
    assert data["days"] == days
    assert len(data["series"]) == days, f"series length {len(data['series'])} != days {days}"
    assert REQUIRED_TOTAL_KEYS <= set(data["totals"].keys())
    assert REQUIRED_SERIES_KEYS <= set(data["series"][0].keys())
    # churn / retention / hours
    assert {"inactive_days_threshold", "churned_users", "eligible_users", "churn_rate_pct",
            "avg_days_before_churn"} <= set(data["churn"].keys())
    assert {"d1_pct", "d7_pct", "d30_pct"} <= set(data["retention"].keys())
    assert isinstance(data["hours"], list) and len(data["hours"]) == 24
    assert isinstance(data["session_buckets"], list) and len(data["session_buckets"]) >= 1
    # no password hashes anywhere
    blob = r.text.lower()
    assert "password_hash" not in blob
    assert "password" not in {k for u in data["recent_users"] for k in u.keys()}


# ---------------- Activity tracking ----------------

class TestActivity:
    def test_new_user_increments_dau_and_appears_in_recent(self):
        token_admin = login(ADMIN_EMAIL, ADMIN_PASSWORD)
        before = requests.get(f"{BASE_URL}/api/admin/analytics?days=7",
                              headers=auth(token_admin), timeout=20).json()
        before_dau = before["totals"]["dau"]

        rand = uuid.uuid4().hex[:8]
        email = f"TEST_act_{rand}@alter.app"
        reg = requests.post(f"{BASE_URL}/api/auth/register", json={
            "email": email, "password": "testpass123", "display_name": f"TEST_act_{rand}"
        }, timeout=20)
        assert reg.status_code == 201, reg.text
        t = reg.json()["token"]

        # call a few endpoints -> should fold into one session with multiple events
        for path in ("/auth/me", "/profile", "/dashboard", "/tasks", "/memories"):
            r = requests.get(f"{BASE_URL}/api{path}", headers=auth(t), timeout=20)
            assert r.status_code == 200, f"{path} -> {r.status_code}"

        # new user is not admin
        assert requests.get(f"{BASE_URL}/api/admin/analytics",
                            headers=auth(t), timeout=20).status_code == 403

        time.sleep(1)
        after = requests.get(f"{BASE_URL}/api/admin/analytics?days=7",
                             headers=auth(token_admin), timeout=20).json()
        assert after["totals"]["dau"] >= before_dau + 1, (before_dau, after["totals"]["dau"])

        email_lc = email.lower()
        emails = {u["email"].lower() for u in after["recent_users"]}
        assert email_lc in emails
        new_entry = next(u for u in after["recent_users"] if u["email"].lower() == email_lc)
        assert new_entry["role"] == "user"
        assert new_entry["sessions"] >= 1


# ---------------- Seed idempotency ----------------

class TestSeedIdempotency:
    def test_demo_and_admin_still_login(self):
        # if seeding had overwritten the demo password this would 401
        assert login(DEMO_EMAIL, DEMO_PASSWORD)
        assert login(ADMIN_EMAIL, ADMIN_PASSWORD)

    def test_only_one_admin_and_demo_in_recent_users(self):
        t = login(ADMIN_EMAIL, ADMIN_PASSWORD)
        data = requests.get(f"{BASE_URL}/api/admin/analytics?days=180",
                            headers=auth(t), timeout=30).json()
        admins = [u for u in data["recent_users"] if u["email"] == ADMIN_EMAIL]
        demos = [u for u in data["recent_users"] if u["email"] == DEMO_EMAIL]
        # recent_users is bounded (top-N) so these may be empty, but never >1
        assert len(admins) <= 1
        assert len(demos) <= 1


# ---------------- Regression: demo can still use the app ----------------

class TestDemoRegression:
    def test_demo_tasks_grocery_chat(self):
        t = login(DEMO_EMAIL, DEMO_PASSWORD)
        # task CRUD
        rand = uuid.uuid4().hex[:6]
        r = requests.post(f"{BASE_URL}/api/tasks", headers=auth(t),
                          json={"title": f"TEST_task_{rand}", "priority": "low"}, timeout=20)
        assert r.status_code == 201, r.text
        tid = r.json()["id"]
        g = requests.get(f"{BASE_URL}/api/tasks", headers=auth(t), timeout=20).json()
        assert any(x["id"] == tid for x in g)
        requests.delete(f"{BASE_URL}/api/tasks/{tid}", headers=auth(t), timeout=20)

        # grocery add
        r = requests.post(f"{BASE_URL}/api/groceries", headers=auth(t),
                          json={"name": f"TEST_g_{rand}", "quantity": "1"}, timeout=20)
        assert r.status_code in (201, 409)
        if r.status_code == 201:
            gid = r.json()["id"]
            requests.delete(f"{BASE_URL}/api/groceries/{gid}", headers=auth(t), timeout=20)

        # chat stream endpoint responds (we only check headers / first bytes, don't drain the LLM)
        with requests.post(f"{BASE_URL}/api/chat", headers=auth(t),
                           json={"message": f"TEST_ping_{rand} — reply with just OK."},
                           timeout=45, stream=True) as resp:
            assert resp.status_code == 200
            assert "text/event-stream" in resp.headers.get("content-type", "")
            # read first chunk to ensure stream really started
            got = next(resp.iter_lines(decode_unicode=True), None)
            assert got is not None

"""AI cost-control tests. Run: cd backend && python tests/usage_controls_test.py  -> /app/test_reports/usage_controls.json
Part A uses an isolated temp database to exercise usage.py directly (no AI cost). Part B hits the live API."""
import asyncio
import json
import os
import sys
import time
import uuid
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import httpx
from dotenv import load_dotenv

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
from motor.motor_asyncio import AsyncIOMotorClient  # noqa: E402

import usage as UM  # noqa: E402

BASE = os.environ.get("EVAL_BASE", "http://localhost:8001/api")
R = []


def rec(name, ok, detail=""):
    R.append({"test": name, "passed": bool(ok), "detail": str(detail)[:300]})
    print(("PASS " if ok else "FAIL ") + name + (f" :: {detail}" if not ok else ""))


def user(i="u1", role="user", email=None):
    return SimpleNamespace(id=f"{i}-{uuid.uuid4().hex[:6]}", role=role, email=email or f"{i}@alter.app")


async def part_a():
    client = AsyncIOMotorClient(os.environ["MONGO_URL"])
    dbn = f"alter_usage_test_{uuid.uuid4().hex[:6]}"
    db = client[dbn]
    U = UM.Usage(db)
    await U.ensure_indexes()
    await db.app_settings.insert_one({"_id": "usage", "beta_mode": False})
    try:
        # 30 chat messages then reject; internal calls don't touch message counter
        u = user()
        for _ in range(30):
            r = await U.admit(u, "chat")
            await U.settle(r, ok=True, ai_calls=3, breakdown={"planner": 1, "responder": 1, "validator": 1})
        try:
            await U.admit(u, "chat"); rec("chat: 31st message rejected", False)
        except UM.QuotaError as e:
            rec("chat: 31st message rejected (429, structured)", e.status == 429 and e.code == "chat_limit_reached" and e.limit == 30 and e.used == 30 and e.reset_at, e.body())
        c = await db.usage_counters.find_one({"_id": f"u:{u.id}|chat|{UM.day_key()}"})
        k = await db.usage_counters.find_one({"_id": f"u:{u.id}|ai_calls|{UM.day_key()}"})
        rec("internal AI calls counted separately (30 msgs, 90 calls)", c["used"] == 30 and k["used"] == 90, (c, k))

        # voice 5 then reject
        v = user("v")
        for _ in range(5):
            await U.settle(await U.admit(v, "voice"), ok=True, ai_calls=2)
        try:
            await U.admit(v, "voice"); rec("voice: 6th rejected", False)
        except UM.QuotaError as e:
            rec("voice: 6th note rejected", e.status == 429 and e.code == "voice_limit_reached" and e.limit == 5)

        # concurrency: 60 simultaneous chat admits -> exactly 30 admitted; 20 voice -> exactly 5
        cu, cv = user("cc"), user("cv")
        res = await asyncio.gather(*[U.admit(cu, "chat") for _ in range(60)], return_exceptions=True)
        rec("concurrent chat cannot bypass quota (60 -> 30)", sum(not isinstance(x, Exception) for x in res) == 30)
        res = await asyncio.gather(*[U.admit(cv, "voice") for _ in range(20)], return_exceptions=True)
        rec("concurrent voice cannot bypass quota (20 -> 5)", sum(not isinstance(x, Exception) for x in res) == 5)

        # failures release quota; retries with same idempotency key not double-charged
        f = user("f")
        r = await U.admit(f, "chat", "abc12345")
        await U.settle(r, ok=False, ai_calls=1)
        doc = await db.usage_counters.find_one({"_id": f"u:{f.id}|chat|{UM.day_key()}"})
        rec("failed request releases message quota", doc["used"] == 0 and doc["reserved"] == 0, doc)
        r = await U.admit(f, "chat", "dup99999")
        try:
            await U.admit(f, "chat", "dup99999"); rec("duplicate idempotency key rejected", False)
        except UM.QuotaError as e:
            rec("duplicate/retry with same key not counted twice", e.code == "duplicate_request")
        await U.settle(r, ok=True, ai_calls=3)
        await U.settle(r, ok=True, ai_calls=3)  # double settle is a no-op
        doc = await db.usage_counters.find_one({"_id": f"u:{f.id}|chat|{UM.day_key()}"})
        rec("double settle is idempotent", doc["used"] == 1 and doc["reserved"] == 0, doc)

        # expired reservations (crash/restart/abandoned) are released by sweep
        x = user("x")
        r = await U.admit(x, "chat")
        await db.usage_reservations.update_one({"_id": r["id"]}, {"$set": {"expires_at": datetime.now(timezone.utc) - timedelta(minutes=1)}})
        n = await U.sweep()
        doc = await db.usage_counters.find_one({"_id": f"u:{x.id}|chat|{UM.day_key()}"})
        rec("expired reservation released after restart/sweep", n >= 1 and doc["reserved"] == 0)

        # user isolation: one user's usage doesn't affect another
        a, b = user("a"), user("b")
        for _ in range(30):
            await U.settle(await U.admit(a, "chat"), ok=True, ai_calls=0)
        r = await U.admit(b, "chat")
        rec("quota is per user (B unaffected by A)", bool(r))

        # global thresholds
        base = await U._count(f"g|ai_calls|{UM.day_key()}")
        await U.update_settings("t@alter.app", {"ai_calls_per_day": base + 6})
        g1, g2 = user("g1"), user("g2")
        await U.settle(await U.admit(g1, "chat"), ok=True, ai_calls=3)
        await U.settle(await U.admit(g2, "chat"), ok=True, ai_calls=3)
        try:
            await U.admit(user("g3"), "chat"); rec("global daily threshold blocks", False)
        except UM.QuotaError as e:
            rec("global daily threshold blocks new AI ops (503)", e.status == 503 and e.code == "global_daily_allowance_reached")
        await U.update_settings("t@alter.app", {"ai_calls_per_day": 3000, "ai_disabled": True})
        try:
            await U.admit(user("e"), "chat"); rec("emergency switch", False)
        except UM.QuotaError as e:
            rec("emergency switch blocks AI (503)", e.code == "ai_temporarily_disabled")
        hist = await db.config_audit.count_documents({})
        rec("settings changes are audited", hist == 2)
        await U.update_settings("t@alter.app", {"ai_disabled": False, "beta_mode": True})

        # beta allowlist
        nb = user("nb", email="notinvited@alter.app")
        try:
            await U.admit(nb, "chat"); rec("beta blocks uninvited", False)
        except UM.QuotaError as e:
            rec("uninvited user cannot trigger AI (403)", e.code == "beta_access_required")
        await db.beta_invites.insert_one({"email": "invited@alter.app", "status": "active"})
        rec("invited user admitted", bool(await U.admit(user("iv", email="invited@alter.app"), "chat")))
        await db.beta_invites.update_one({"email": "invited@alter.app"}, {"$set": {"status": "suspended"}})
        rec("suspended user blocked", not await U.beta_allowed(user("iv2", email="invited@alter.app")))
        rec("admin always allowed, invite grants no admin", await U.beta_allowed(user("ad", role="admin")))

        # UTC boundary
        t = datetime(2026, 1, 31, 23, 59, 59, tzinfo=timezone.utc)
        rec("UTC day/month boundary", UM.day_key(t) == "2026-01-31" and UM.next_reset(t).startswith("2026-02-01T00:00") and UM.next_month(t).startswith("2026-02-01"))
        t2 = datetime(2026, 12, 31, 23, 0, tzinfo=timezone.utc)
        rec("UTC year rollover", UM.next_month(t2).startswith("2027-01-01"))
        ev = await db.usage_events.find_one({"outcome": "success"})
        rec("usage events hold no content fields", not any(k in ev for k in ("text", "content", "message", "email_body")))
    finally:
        await client.drop_database(dbn)


async def part_b():
    async with httpx.AsyncClient(base_url=BASE, timeout=120) as h:
        adm = (await h.post("/auth/login", json={"email": "admin@example.com", "password": "<REDACTED_PASSWORD>"})).json()["token"]
        AH = {"Authorization": f"Bearer {adm}"}
        orig = (await h.put("/admin/usage/settings", headers=AH, json={})).json()
        em = f"quota_{uuid.uuid4().hex[:6]}@alter.app"
        tok = (await h.post("/auth/register", json={"display_name": "Quota T", "email": em, "password": "quotatest1", "timezone": "UTC"})).json()["token"]
        UH = {"Authorization": f"Bearer {tok}"}
        try:
            me = (await h.get("/auth/me", headers=UH)).json()
            rec("new user read-aloud off by default", me["profile"]["read_aloud"] is False and me["user"]["beta_access"] is False)
            r = await h.post("/chat", headers=UH, json={"message": "hello"})
            rec("API: uninvited chat -> 403 beta message", r.status_code == 403 and r.json()["error"]["code"] == "beta_access_required")
            r = await h.post("/tts", headers=UH, json={"text": "hello"})
            rec("API: read-aloud disabled -> no audio generated", r.status_code == 403 and r.json()["error"]["code"] == "read_aloud_disabled")
            await h.post("/admin/beta", headers=AH, json={"email": em})
            await h.put("/admin/usage/settings", headers=AH, json={"chat_per_user_day": 1})
            r = await h.post("/chat", headers=UH, json={"message": "Remember that my favourite fruit is mango", "client_id": "test-client-1"})
            rec("API: invited user chat admitted", r.status_code == 200)
            r2 = await h.post("/chat", headers=UH, json={"message": "What is my favourite fruit?"})
            body = r2.json()
            rec("API: limit -> 429 with structured fields", r2.status_code == 429 and body["error"]["code"] == "chat_limit_reached"
                and body["error"]["limit"] == 1 and body["error"]["reset_at"] and "chat limit" in body["detail"], body)
            r3 = await h.get("/admin/usage", headers=UH)
            rec("API: non-admin cannot read usage dashboard", r3.status_code == 403)
            dash = (await h.get("/admin/usage", headers=AH)).json()
            row = next((u for u in dash["users_today"] if u["email"] == em), None)
            rec("dashboard counts the user's 1 message & 3-ish calls", row and row["chat"] == 1 and row["ai_calls"] >= 1, row)
            rec("dashboard exposes no message content", "mango" not in json.dumps(dash).lower())
            mems = (await h.get("/memories", headers=UH)).json()
            rec("existing features still work under quota (memory saved)", any("mango" in m["content"].lower() for m in mems))
            r = await h.post("/tasks", headers=UH, json={"title": "Quota test task"})
            rec("tasks unaffected by AI quota", r.status_code == 201)
        finally:
            await h.put("/admin/usage/settings", headers=AH, json={k: orig[k] for k in ("chat_per_user_day",)})
            await h.put(f"/admin/beta/{em}", headers=AH, json={"status": "revoked"})
            await h.delete("/account", headers=UH)


async def main():
    await part_a()
    await part_b()
    ok = sum(r["passed"] for r in R)
    os.makedirs("/app/test_reports", exist_ok=True)
    json.dump({"at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "passed": ok, "total": len(R), "results": R},
              open("/app/test_reports/usage_controls.json", "w"), indent=2)
    print(f"\n{ok}/{len(R)} passed")


if __name__ == "__main__":
    asyncio.run(main())

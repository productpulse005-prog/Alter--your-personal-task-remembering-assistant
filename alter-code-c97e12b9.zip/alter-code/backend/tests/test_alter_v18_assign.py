"""Backend tests for family task assignment feature (iteration 18).

Flow:
- Create two throwaway users (A, B) ending @alter.app
- A creates family, B joins by code
- A creates a task, assigns to B via PUT /api/tasks/{id} {assigned_to: B.id}
- Both A and B see the task via GET /api/tasks; owner_name & assigned_to_name populated
- B can toggle status (only status), but cannot change other fields (403)
- Re-assign back to None (A takes it back)
- Negative: user without family cannot assign; user cannot assign to non-family member
- Cleanup: DELETE /api/account for both users

Run:
  cd /app/backend && python -m pytest tests/test_alter_v18_assign.py -p asyncio -o asyncio_mode=strict -n 0 -v \
    --junitxml=/app/test_reports/pytest/pytest_v18_results.xml
"""
import os
import time
import uuid

import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
PWD = "famtest123"


def _rand(prefix="fam"):
    return f"{prefix}_{uuid.uuid4().hex[:8]}@alter.app"


def _register(email, name):
    r = requests.post(f"{API}/auth/register", json={"email": email, "password": PWD, "display_name": name}, timeout=20)
    assert r.status_code == 201, f"register {email} -> {r.status_code} {r.text}"
    return r.json()["token"], r.json()["user"]["id"]


def _h(token):
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="module")
def pair():
    """Create A (family owner) and B (joiner); yield context; delete both at end."""
    a_email, b_email = _rand("fam_a"), _rand("fam_b")
    a_tok, a_id = _register(a_email, "Alice Test")
    b_tok, b_id = _register(b_email, "Bob Test")

    # A creates family
    r = requests.post(f"{API}/family", json={"name": "TEST_FAM_v18"}, headers=_h(a_tok), timeout=15)
    assert r.status_code == 201, f"create family -> {r.status_code} {r.text}"
    fam = r.json()
    code = fam["family"]["code"]
    assert isinstance(code, str) and len(code) >= 4

    # B joins
    r = requests.post(f"{API}/family/join", json={"code": code}, headers=_h(b_tok), timeout=15)
    assert r.status_code == 200, f"join -> {r.status_code} {r.text}"
    members = r.json()["members"]
    assert {m["user_id"] for m in members} == {a_id, b_id}

    ctx = {"a_tok": a_tok, "a_id": a_id, "b_tok": b_tok, "b_id": b_id, "code": code,
           "a_email": a_email, "b_email": b_email}
    yield ctx

    # cleanup
    for tok in (a_tok, b_tok):
        try:
            requests.delete(f"{API}/account", headers=_h(tok), timeout=15)
        except Exception:
            pass


# ----- Family endpoints -----
class TestFamily:
    def test_get_family_returns_members(self, pair):
        r = requests.get(f"{API}/family", headers=_h(pair["a_tok"]), timeout=15)
        assert r.status_code == 200
        body = r.json()
        assert body["family"]["name"] == "TEST_FAM_v18"
        assert len(body["members"]) == 2

    def test_cannot_create_family_twice(self, pair):
        r = requests.post(f"{API}/family", json={"name": "dupe"}, headers=_h(pair["a_tok"]), timeout=15)
        assert r.status_code == 409


# ----- Assignment flow -----
class TestAssign:
    def test_a_creates_task_and_assigns_to_b(self, pair):
        title = f"TEST_v18_assign_{int(time.time()*1000)}"
        r = requests.post(f"{API}/tasks", json={"title": title, "due_date": "2026-12-15", "priority": "medium"},
                          headers=_h(pair["a_tok"]), timeout=15)
        assert r.status_code == 201, r.text
        task = r.json()
        tid = task["id"]
        assert task["user_id"] == pair["a_id"]
        assert task["assigned_to"] is None
        pair["tid"] = tid

        # Assign to B
        r = requests.put(f"{API}/tasks/{tid}", json={"assigned_to": pair["b_id"]},
                         headers=_h(pair["a_tok"]), timeout=15)
        assert r.status_code == 200, r.text
        upd = r.json()
        assert upd["assigned_to"] == pair["b_id"]
        assert upd["assigned_to_name"] == "Bob Test"
        assert upd["owner_name"] == "Alice Test"

    def test_both_users_see_assigned_task(self, pair):
        tid = pair["tid"]
        # A sees it (owner)
        r = requests.get(f"{API}/tasks", headers=_h(pair["a_tok"]), timeout=15)
        assert r.status_code == 200
        a_task = next((t for t in r.json() if t["id"] == tid), None)
        assert a_task and a_task["assigned_to"] == pair["b_id"]

        # B sees it (assignee)
        r = requests.get(f"{API}/tasks", headers=_h(pair["b_tok"]), timeout=15)
        assert r.status_code == 200
        b_task = next((t for t in r.json() if t["id"] == tid), None)
        assert b_task and b_task["assigned_to"] == pair["b_id"]
        assert b_task["owner_name"] == "Alice Test"

    def test_b_cannot_edit_non_status_fields(self, pair):
        """Non-owner (B) should get 403 when trying to change title/priority."""
        r = requests.put(f"{API}/tasks/{pair['tid']}", json={"title": "hacked by B"},
                         headers=_h(pair["b_tok"]), timeout=15)
        assert r.status_code == 403, r.text

    def test_b_can_toggle_status(self, pair):
        """Non-owner B should be able to complete the task they are assigned."""
        r = requests.put(f"{API}/tasks/{pair['tid']}", json={"status": "completed"},
                         headers=_h(pair["b_tok"]), timeout=15)
        assert r.status_code == 200, r.text
        assert r.json()["status"] == "completed"
        # Reopen it so later tests can continue
        r = requests.put(f"{API}/tasks/{pair['tid']}", json={"status": "todo"},
                         headers=_h(pair["b_tok"]), timeout=15)
        assert r.status_code == 200

    def test_a_reassigns_back_to_self(self, pair):
        r = requests.put(f"{API}/tasks/{pair['tid']}", json={"assigned_to": None},
                         headers=_h(pair["a_tok"]), timeout=15)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["assigned_to"] is None
        assert body["assigned_to_name"] is None

    def test_cannot_assign_to_non_family_member(self, pair):
        """Create a 3rd user NOT in the family and try to assign to them -> 400."""
        other_email = _rand("fam_c")
        other_tok, other_id = _register(other_email, "Carol Test")
        try:
            r = requests.put(f"{API}/tasks/{pair['tid']}", json={"assigned_to": other_id},
                             headers=_h(pair["a_tok"]), timeout=15)
            assert r.status_code == 400, r.text
            assert "family" in r.text.lower()
        finally:
            requests.delete(f"{API}/account", headers=_h(other_tok), timeout=15)

    def test_user_without_family_cannot_assign(self, pair):
        """A solo user (no family) gets 400 when attempting to assign a task."""
        solo_email = _rand("fam_solo")
        solo_tok, solo_id = _register(solo_email, "Solo Test")
        try:
            # Create a task
            r = requests.post(f"{API}/tasks", json={"title": "TEST_v18_solo", "due_date": "2026-12-15"},
                              headers=_h(solo_tok), timeout=15)
            assert r.status_code == 201
            stid = r.json()["id"]
            # Try to assign to someone (B) -> should fail (400 "Create or join a family")
            r = requests.put(f"{API}/tasks/{stid}", json={"assigned_to": pair["b_id"]},
                             headers=_h(solo_tok), timeout=15)
            assert r.status_code == 400, r.text
        finally:
            requests.delete(f"{API}/account", headers=_h(solo_tok), timeout=15)

    def test_assign_to_b_persists_for_filter(self, pair):
        """Final: re-assign to B so UI filter test can observe it; cleanup via account delete."""
        r = requests.put(f"{API}/tasks/{pair['tid']}", json={"assigned_to": pair["b_id"]},
                         headers=_h(pair["a_tok"]), timeout=15)
        assert r.status_code == 200
        # GET /tasks for A, 'I assigned' filter equivalent: tasks A owns AND assigned_to != A
        r = requests.get(f"{API}/tasks", headers=_h(pair["a_tok"]), timeout=15)
        mine_assigned = [t for t in r.json()
                         if t["user_id"] == pair["a_id"] and t.get("assigned_to") and t["assigned_to"] != pair["a_id"]]
        assert any(t["id"] == pair["tid"] for t in mine_assigned)

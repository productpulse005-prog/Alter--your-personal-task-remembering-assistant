"""Iteration 29: restrictions removed (beta always allowed, per-user limits ignored, only global caps)
and chat evidence that includes past/completed tasks + the user's past messages from other conversations.
Part A runs usage.py against an isolated temp DB (no AI cost). Part B hits the public API (few real AI calls)."""
import asyncio
import os
import sys
import time
import uuid
from types import SimpleNamespace

import pytest
import requests
from dotenv import load_dotenv

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
load_dotenv(os.path.join(os.path.dirname(__file__), "..", "..", "frontend", ".env"))
from motor.motor_asyncio import AsyncIOMotorClient  # noqa: E402

import usage as UM  # noqa: E402

BASE = os.environ["EXPO_PUBLIC_BACKEND_URL"].rstrip("/") + "/api"
ADMIN = {"email": "admin@example.com", "password": "<REDACTED_PASSWORD>"}


def fake_user(i="u", role="user"):
    return SimpleNamespace(id=f"{i}-{uuid.uuid4().hex[:6]}", role=role, email=f"{i}{uuid.uuid4().hex[:4]}@alter.app")


def run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


# ---- Part A: usage.py unit-level (isolated DB) ----
class TestUsageNoPerUserLimits:
    async def _with_db(self, settings, fn):
        client = AsyncIOMotorClient(os.environ["MONGO_URL"])
        dbn = f"alter_usage_t29_{uuid.uuid4().hex[:6]}"
        db = client[dbn]
        try:
            U = UM.Usage(db)
            await U.ensure_indexes()
            await db.app_settings.insert_one({"_id": "usage", **settings})
            return await fn(U, db)
        finally:
            await client.drop_database(dbn)
            client.close()

    def test_beta_allowed_even_when_beta_mode_on_and_not_invited(self):
        async def fn(U, db):
            return await U.beta_allowed(fake_user())
        assert run(self._with_db({"beta_mode": True}, fn)) is True

    def test_chat_per_user_limit_ignored(self):
        async def fn(U, db):
            u = fake_user()
            for _ in range(5):
                r = await U.admit(u, "chat")
                await U.settle(r, ok=True, ai_calls=3)
            return await db.usage_counters.count_documents({"_id": {"$regex": f"^u:{u.id}"}})
        # limits set to 1 but must not be enforced; no per-user counters written
        assert run(self._with_db({"beta_mode": True, "chat_per_user_day": 1, "ai_calls_per_user_day": 2}, fn)) == 0

    def test_voice_per_user_limit_ignored(self):
        async def fn(U, db):
            u = fake_user("v")
            for _ in range(4):
                await U.settle(await U.admit(u, "voice"), ok=True, ai_calls=2)
            return True
        assert run(self._with_db({"voice_per_user_day": 1}, fn))

    def test_global_daily_cap_still_enforced(self):
        async def fn(U, db):
            u = fake_user("g")
            await U.settle(await U.admit(u, "chat"), ok=True, ai_calls=3)  # chat expects 3 calls
            try:
                await U.admit(u, "chat")
                return None
            except UM.QuotaError as e:
                return e
        e = run(self._with_db({"ai_calls_per_day": 4}, fn))
        assert e is not None and e.status == 503 and e.code == "global_daily_allowance_reached"

    def test_byok_not_counted_against_global_cap(self):
        async def fn(U, db):
            u = fake_user("b")
            for _ in range(3):
                await U.settle(await U.admit(u, "chat", billing="byok"), ok=True, ai_calls=3)
            return True
        assert run(self._with_db({"ai_calls_per_day": 1}, fn))

    def test_ai_disabled_still_blocks(self):
        async def fn(U, db):
            try:
                await U.admit(fake_user(), "chat")
                return None
            except UM.QuotaError as e:
                return e
        e = run(self._with_db({"ai_disabled": True}, fn))
        assert e is not None and e.status == 503 and e.code == "ai_temporarily_disabled"


# ---- Part B: live API ----
@pytest.fixture(scope="module")
def new_user():
    s = requests.Session()
    email = f"test_t29_{uuid.uuid4().hex[:8]}@test.app"
    r = s.post(f"{BASE}/auth/register", json={"email": email, "password": "testpass123", "display_name": "T29 Tester"})
    assert r.status_code in (200, 201), r.text
    s.headers["Authorization"] = f"Bearer {r.json()['token']}"
    yield s
    s.delete(f"{BASE}/account")


@pytest.fixture(scope="module")
def admin():
    s = requests.Session()
    r = s.post(f"{BASE}/auth/login", json=ADMIN)
    if r.status_code != 200:
        pytest.skip("admin login failed")
    s.headers["Authorization"] = f"Bearer {r.json()['token']}"
    return s


class ChatResult:
    def __init__(self, r):
        import json
        self.status_code, self.text, self.events = r.status_code, r.text, []
        for line in r.text.splitlines():
            if line.startswith("data:"):
                try:
                    self.events.append(json.loads(line[5:].strip()))
                except ValueError:
                    pass
        meta = next((e for e in self.events if e.get("type") == "meta"), {})
        done = next((e for e in self.events if e.get("type") == "done"), {})
        self.conversation_id = (meta.get("conversation") or {}).get("id")
        self.user_message_id = (meta.get("user_message") or {}).get("id")
        self.message = done.get("message") or {}
        self.errors = [e for e in self.events if e.get("type") == "error"]

    def json(self):
        return {"conversation_id": self.conversation_id, "message": self.message, "reply": self.message.get("content"),
                "sources": self.message.get("sources"), "errors": self.errors}


def chat(s, message, conversation_id=None):
    for attempt in range(2):
        r = ChatResult(s.post(f"{BASE}/chat", json={"message": message, "conversation_id": conversation_id}, timeout=150))
        if r.status_code == 200 and r.message:
            return r
        print("chat retry:", r.status_code, r.text[:300])
        time.sleep(20)
    return r


class TestLiveRestrictionsOff:
    def test_me_beta_access_true_for_uninvited_user(self, new_user):
        r = new_user.get(f"{BASE}/auth/me")
        assert r.status_code == 200 and r.json()["user"]["beta_access"] is True

    def test_live_settings_beta_off_per_user_zero(self, admin):
        r = admin.put(f"{BASE}/admin/usage/settings", json={})
        assert r.status_code == 200, r.text
        st = r.json()
        st = st.get("settings", st)
        print(st)
        assert st["beta_mode"] is False
        assert st["chat_per_user_day"] == 0 and st["voice_per_user_day"] == 0 and st["ai_calls_per_user_day"] == 0

    def test_me_usage_unlimited(self, new_user):
        r = new_user.get(f"{BASE}/me/usage")
        assert r.status_code == 200 and r.json()["my_limit"] == 0 and r.json()["shared_limit"] > 0

    def test_uninvited_user_can_chat(self, new_user):
        r = chat(new_user, "Hi, what can you do?")
        assert r.status_code == 200, r.text
        assert r.json().get("reply") or r.json().get("message")


class TestLiveChatHistoryEvidence:
    def test_completed_past_task_used_as_evidence(self, new_user):
        t = new_user.post(f"{BASE}/tasks", json={"title": "Renew passport at the zylophone office", "due_date": "2025-12-10",
                                                  "status": "completed"})
        assert t.status_code == 201, t.text
        tid = t.json()["id"]
        time.sleep(5)
        r = chat(new_user, "When did I renew my passport at the zylophone office?")
        assert r.status_code == 200, r.text
        body = r.json()
        print(body)
        ids = [x.get("record_id") for x in (body.get("sources") or body.get("message", {}).get("sources") or [])]
        txt = str(body).lower()
        assert tid in ids or "2025-12-10" in txt or "december 10" in txt or "10 december" in txt or "dec 10" in txt

    def test_past_message_from_other_conversation_used(self, new_user):
        r1 = chat(new_user, "My bike lock combination hint is quokkaberry")
        assert r1.status_code == 200, r1.text
        conv1 = r1.json().get("conversation_id")
        msgs = new_user.get(f"{BASE}/conversations/{conv1}/messages").json()
        msgs = msgs if isinstance(msgs, list) else msgs.get("messages", [])
        user_ids = {m["id"] for m in msgs if m["role"] == "user"}
        time.sleep(8)
        r2 = chat(new_user, "What did I tell you about my bike lock combination hint?")  # new conversation
        assert r2.status_code == 200, r2.text
        body = r2.json()
        print(body)
        assert body.get("conversation_id") != conv1
        srcs = body.get("sources") or body.get("message", {}).get("sources") or []
        assert "quokkaberry" in str(body).lower() or any(s.get("record_id") in user_ids for s in srcs)

    def test_old_completed_task_ranked_above_newer_fillers(self, new_user):
        # target first, then 15 newer completed fillers: old logic (10 most recent completed) would drop the target
        t = new_user.post(f"{BASE}/tasks", json={"title": "Paid marimbatown water bill", "due_date": "2025-11-03", "status": "completed"})
        assert t.status_code == 201, t.text
        tid = t.json()["id"]
        for i in range(15):
            new_user.post(f"{BASE}/tasks", json={"title": f"Filler chore number {i} alpha{i}", "status": "completed"})
        time.sleep(8)
        r = chat(new_user, "When did I pay the marimbatown water bill?")
        assert r.status_code == 200, r.text
        body = r.json()
        print(body)
        srcs = body.get("sources") or []
        assert any(s.get("record_id") == tid for s in srcs) or "2025-11-03" in str(body) or "november 3" in str(body).lower()

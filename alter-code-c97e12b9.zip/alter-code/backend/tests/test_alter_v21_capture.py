# Iteration 21: /api/capture (multilingual groceries/tasks), grocery dedupe, chat groceries, /api/tts removed
import os
import json
import time
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL").rstrip("/")
API = f"{BASE_URL}/api"
ADMIN = {"email": "admin@example.com", "password": "<REDACTED_PASSWORD>"}
DEMO = {"email": "demo@alter.app", "password": "<REDACTED_PASSWORD>"}


def _login(creds):
    r = requests.post(f"{API}/auth/login", json=creds, timeout=20)
    if r.status_code != 200:
        pytest.skip(f"login failed {creds['email']}: {r.status_code}")
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {r.json()['token']}", "Content-Type": "application/json"})
    return s


@pytest.fixture(scope="module")
def admin():
    s = _login(ADMIN)
    before_g = {g["id"] for g in s.get(f"{API}/groceries", timeout=20).json()}
    before_t = {t["id"] for t in s.get(f"{API}/tasks", timeout=20).json()}
    yield s
    # cleanup: anything created during the module
    for g in s.get(f"{API}/groceries", timeout=20).json():
        if g["id"] not in before_g:
            s.delete(f"{API}/groceries/{g['id']}", timeout=10)
    for t in s.get(f"{API}/tasks", timeout=20).json():
        if t["id"] not in before_t:
            s.delete(f"{API}/tasks/{t['id']}", timeout=10)


@pytest.fixture(scope="module")
def demo():
    s = _login(DEMO)
    before_t = {t["id"] for t in s.get(f"{API}/tasks", timeout=20).json()}
    yield s
    for t in s.get(f"{API}/tasks", timeout=20).json():
        if t["id"] not in before_t:
            s.delete(f"{API}/tasks/{t['id']}", timeout=10)


def _grocery_names(s):
    return [g["name"].lower() for g in s.get(f"{API}/groceries", timeout=20).json() if not g["checked"]]


def _capture(s, text, priority="medium"):
    r = s.post(f"{API}/capture", json={"text": text, "priority": priority}, timeout=60)
    assert r.status_code == 200, r.text
    return r.json()


def _types(res):
    return [x["type"] for x in res["results"]]


class TestCaptureGroceries:
    def test_english_groceries(self, admin):
        res = _capture(admin, "bread, butter and 1kg sugar")
        print(json.dumps(res)[:800])
        assert res["ai"] is True
        assert "add_grocery" in _types(res) and "create_task" not in _types(res)
        names = _grocery_names(admin)
        for n in ("bread", "butter", "sugar"):
            assert any(n in x for x in names), f"{n} missing from {names}"

    def test_hindi_groceries(self, admin):
        res = _capture(admin, "doodh aur anda")
        print(json.dumps(res, ensure_ascii=False)[:800])
        assert res["ai"] is True
        assert _types(res) and all(t == "add_grocery" for t in _types(res)), _types(res)

    def test_spanish_groceries(self, admin):
        res = _capture(admin, "comprar leche y pan")
        print(json.dumps(res, ensure_ascii=False)[:800])
        assert res["ai"] is True
        assert "add_grocery" in _types(res) and "create_task" not in _types(res), _types(res)


class TestCaptureTask:
    def test_task_with_date_time_and_priority_override(self, admin):
        res = _capture(admin, "call plumber tomorrow 10am", priority="high")
        print(json.dumps(res)[:800])
        assert res["ai"] is True
        tasks = [x for x in res["results"] if x["type"] == "create_task"]
        assert len(tasks) == 1
        d = tasks[0]["data"]
        assert "plumber" in d["title"].lower()
        assert d["due_time"] == "10:00"
        assert d["priority"] == "high"
        today = admin.get(f"{API}/dashboard", timeout=20).json()
        prof = admin.get(f"{API}/profile", timeout=20).json()
        print("due_date", d["due_date"], "tz", prof.get("timezone"))
        assert d["due_date"] and len(d["due_date"]) == 10
        got = admin.get(f"{API}/tasks", timeout=20).json()
        assert any(t["id"] == d["id"] and t["priority"] == "high" for t in got)


class TestCaptureFallback:
    def test_demo_quota_exhausted_plain_task(self, demo):
        res = _capture(demo, "TEST_fallback water plants")
        print(json.dumps(res)[:500])
        assert res["ai"] is False
        assert _types(res) == ["create_task"]
        assert res["results"][0]["data"]["title"] == "TEST_fallback water plants"

    def test_demo_fallback_priority(self, demo):
        res = _capture(demo, "TEST_fallback low prio", priority="low")
        assert res["ai"] is False
        assert res["results"][0]["data"]["priority"] == "low"

    def test_capture_validation(self, demo):
        r = demo.post(f"{API}/capture", json={"text": "", "priority": "medium"}, timeout=20)
        assert r.status_code == 422
        r = demo.post(f"{API}/capture", json={"text": "x", "priority": "bogus"}, timeout=20)
        assert r.status_code == 422


class TestGroceryDedupe:
    def test_manual_egg_vs_eggs(self, admin):
        r = admin.post(f"{API}/groceries", json={"name": "TEST_Eggs"}, timeout=20)
        assert r.status_code == 201, r.text
        r2 = admin.post(f"{API}/groceries", json={"name": "test_egg"}, timeout=20)
        assert r2.status_code == 409, r2.text

    def test_manual_tomato_vs_tomatoes(self, admin):
        r = admin.post(f"{API}/groceries", json={"name": "TEST_Tomatoes"}, timeout=20)
        assert r.status_code == 201, r.text
        r2 = admin.post(f"{API}/groceries", json={"name": "TEST_tomato"}, timeout=20)
        assert r2.status_code == 409, r2.text

    def test_capture_egg_already_on_list(self, admin):
        if not any(n in ("eggs", "egg") for n in _grocery_names(admin)):
            admin.post(f"{API}/groceries", json={"name": "Eggs"}, timeout=20)
        res = _capture(admin, "egg")
        print(json.dumps(res)[:500])
        g = [x for x in res["results"] if x["type"] == "add_grocery"]
        assert g and g[0]["detail"] == "Already on your grocery list", res


class TestChatGroceries:
    def test_chat_adds_tomatoes_onions(self, admin):
        # remove any existing tomato/onion first so chat must add them
        for g in admin.get(f"{API}/groceries", timeout=20).json():
            if any(k in g["name"].lower() for k in ("tomato", "onion")) and not g["name"].startswith("TEST_"):
                pass
        r = admin.post(f"{API}/chat", json={"message": "we need tomatoes and onions"}, stream=True, timeout=90)
        assert r.status_code == 200, r.text
        events = []
        for line in r.iter_lines(decode_unicode=True):
            if line and line.startswith("data: "):
                events.append(json.loads(line[6:]))
        acts = [e for e in events if e["type"] == "actions"]
        print(json.dumps(acts)[:800])
        conv = next((e["conversation"]["id"] for e in events if e["type"] == "meta"), None)
        if conv:
            admin.delete(f"{API}/conversations/{conv}", timeout=10)
        assert acts, f"no actions event: {[e['type'] for e in events]}"
        flat = [a for e in acts for a in e["actions"]]
        assert any(a.get("type") == "add_grocery" for a in flat), flat
        names = _grocery_names(admin)
        assert any("onion" in n for n in names), names


class TestTTSRemoved:
    def test_tts_404(self, admin):
        r = admin.post(f"{API}/tts", json={"text": "hello"}, timeout=20)
        assert r.status_code == 404, r.status_code

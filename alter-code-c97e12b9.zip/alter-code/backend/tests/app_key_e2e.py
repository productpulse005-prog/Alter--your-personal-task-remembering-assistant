"""App-key (GEMINI_API_KEY) end-to-end, economical (~10 Gemini calls). BASE=https://<host> python tests/app_key_e2e.py"""
import json
import os
import sys
import time
import uuid
from datetime import datetime, timezone

import requests
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
BASE = os.environ["BASE"].rstrip("/") + "/api"
db = MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]
ok_all = True


def check(name, cond, extra=""):
    global ok_all
    ok_all &= bool(cond)
    print(("PASS " if cond else "FAIL ") + name, str(extra)[:260])


def chat(h, msg, conv=None):
    r = requests.post(f"{BASE}/chat", json={"message": msg, "conversation_id": conv, "client_id": uuid.uuid4().hex[:16]}, headers=h, timeout=150)
    ev = [json.loads(l[6:]) for l in r.text.splitlines() if l.startswith("data: ")]
    return ("".join(e.get("content", "") for e in ev if e["type"] == "delta"),
            next((e for e in ev if e["type"] == "error"), None),
            next((e["conversation"]["id"] for e in ev if e["type"] == "meta"), None),
            next((e["actions"] for e in ev if e["type"] == "actions"), []))


h = {"Authorization": "Bearer " + requests.post(f"{BASE}/auth/login", json={"email": "demo@alter.app", "password": "<REDACTED_PASSWORD>"}).json()["token"]}
uid = str(db.users.find_one({"email": "demo@alter.app"})["_id"])
requests.delete(f"{BASE}/ai/key", headers=h)
db.usage_counters.delete_many({"_id": {"$regex": f"^u:{uid}\\|"}})
t0 = datetime.now(timezone.utc).isoformat()
check("route is app (owner's GEMINI_API_KEY)", requests.get(f"{BASE}/ai/key", headers=h).json()["route"] == "app")

tag = uuid.uuid4().hex[:4]
text, err, conv, acts = chat(h, f"Remember that my cat is called Bruno{tag}.")
check("chat action (memory saved)", not err and any(a["type"] == "save_memory" and a["status"] == "success" for a in acts), text)
n_before = db.ai_billing.count_documents({"user_id": uid, "at": {"$gte": t0}})
text, err, _, _ = chat(h, "What's my cat's name?", conv)
n_q = db.ai_billing.count_documents({"user_id": uid, "at": {"$gte": t0}}) - n_before
check("multi-turn recall", not err and f"bruno{tag}" in text.lower(), text)
check("plain question skipped the planner (2 calls, not 3)", n_q == 2, n_q)
text, err, _, _ = chat(h, "Mujhe kal kya karna hai?", conv)
check("hinglish chat answered", not err and text, text)

r = requests.post(f"{BASE}/capture", json={"text": "buy eggs tomorrow and 2 litre doodh", "client_id": "appk" + tag}, headers=h, timeout=90).json()
types = [x["type"] for x in r.get("results", [])]
task = next((x["data"] for x in r["results"] if x["type"] == "create_task"), {})
prof = requests.get(f"{BASE}/profile", headers=h).json()
check("capture: groceries + dated grocery task (1 call)", r["ai"] and "add_grocery" in types and task.get("category") == "grocery" and task.get("due_date"), r)
r2 = requests.post(f"{BASE}/capture", json={"text": "buy eggs tomorrow and 2 litre doodh", "client_id": "appk" + tag}, headers=h, timeout=90).json()
check("capture retry: identical, no new AI call", r == r2)

if os.path.exists("/tmp/voice/hi.mp3"):
    with open("/tmp/voice/hi.mp3", "rb") as f:
        j = requests.post(f"{BASE}/voice", files={"audio": ("v.mp3", f, "audio/mpeg")}, headers={**h, "X-Idempotency-Key": "appvoice" + tag}, timeout=150).json()
    check("hindi voice via Gemini audio on app key", j.get("transcript") and j.get("results"),
          (j.get("transcript"), [(x["type"], x["data"].get("title") or x["data"].get("content"), x["data"].get("due_date")) for x in j.get("results", [])], j.get("error") or j.get("detail")))
    made = j.get("results", [])
else:
    made = []

routes = {d["route"] for d in db.ai_billing.find({"user_id": uid, "at": {"$gte": t0}})}
check("every call billed to app key, zero universal", routes == {"app"}, routes)
check("app key never stored in Mongo", db.ai_billing.count_documents({"$or": [{"key": {"$exists": True}}]}) == 0
      and not db.ai_credentials.find_one({"user_id": uid}))

# cleanup
for m in requests.get(f"{BASE}/memories", headers=h).json():
    if f"Bruno{tag}" in m["content"]:
        requests.delete(f"{BASE}/memories/{m['id']}", headers=h)
for t in requests.get(f"{BASE}/tasks", headers=h).json():
    if t.get("created_at", "") >= t0:
        requests.delete(f"{BASE}/tasks/{t['id']}", headers=h)
for g in requests.get(f"{BASE}/groceries", headers=h).json():
    if g.get("created_at", "") >= t0:
        requests.delete(f"{BASE}/groceries/{g['id']}", headers=h)
if conv:
    requests.delete(f"{BASE}/conversations/{conv}", headers=h)
print("ALL PASS" if ok_all else "SOME FAILED")
sys.exit(0 if ok_all else 1)

# In-process check of /capture offline fallback (AI unavailable) -> offline_alarm task. Usage: python tests/debug_offline_capture.py <email>
import asyncio, sys
sys.path.insert(0, "/app/backend")
import server as S

async def main(email):
    u = await S.db.users.find_one({"email": email})
    user = S.User(**{**u, "id": str(u["_id"])})
    async def boom(*a, **k):
        raise S.AI.AIError(503, "no_key", "AI unavailable (test)")
    S.AI.resolve = boom
    for txt in ["wake me up at 6:30", "set an alarm for 7am to go to the gym", "buy milk and eggs", "call mom"]:
        try:
            r = await S.text_capture(S.CaptureIn(text=txt), user)
            print(txt, "->", r.get("ai"), r.get("note"), [(a["type"], a["status"], {k: a.get("data", {}).get(k) for k in ("title", "due_date", "due_time", "alarm")}) for a in r["results"]])
        except Exception as e:
            print(txt, "EXC", type(e).__name__, e)
    await S.db.tasks.delete_many({"user_id": user.id})
    await S.db.groceries.delete_many({"user_id": user.id})

asyncio.run(main(sys.argv[1]))

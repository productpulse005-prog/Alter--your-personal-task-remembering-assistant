"""Integration tests for Alter 'AI Cost Controls, Usage Limits & Private Beta Safeguards'.

Exercises the LIVE preview backend over HTTPS (EXPO_PUBLIC_BACKEND_URL).

Covers:
- Admin RBAC on usage/beta endpoints (403 for non-admin)
- Beta allowlist: uninvited user blocked from /api/chat (403 beta_access_required);
  non-AI features (tasks, memories, groceries, family, gmail status) still work.
- Admin invite activates access + /api/auth/me beta_access flips true.
- Per-user chat quota: setting chat_per_user_day=0 -> 429 chat_limit_reached with structured fields;
  restored to 30 after.
- Read-aloud opt-in: default profile.read_aloud=false -> /api/tts returns 403 read_aloud_disabled;
  flipping profile makes /api/tts succeed (200 {url}).
- Emergency pause: ai_disabled=true -> /api/chat returns 503 ai_temporarily_disabled; restored.
- Beta CRUD list / invite / suspend / revoke / restore.

Each run creates throwaway users ending @alter.app and deletes them in teardown.
NEVER re-runs usage_controls_test.py / guardrails_eval.py (per main-agent instructions).
"""
import os
import uuid
import pytest
import requests

def _read_frontend_env_url() -> str:
    try:
        with open("/app/frontend/.env", "r") as f:
            for line in f:
                line = line.strip()
                if line.startswith("EXPO_PUBLIC_BACKEND_URL="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
    except Exception:
        pass
    return ""


BASE_URL = (os.environ.get("EXPO_PUBLIC_BACKEND_URL") or os.environ.get("EXPO_BACKEND_URL") or _read_frontend_env_url() or "").rstrip("/")
assert BASE_URL, "EXPO_PUBLIC_BACKEND_URL must be set"
API = f"{BASE_URL}/api"

ADMIN_EMAIL = "admin@example.com"
ADMIN_PASS = "<REDACTED_PASSWORD>"
DEMO_EMAIL = "demo@alter.app"
DEMO_PASS = "<REDACTED_PASSWORD>"

TIMEOUT = 30


# ---------- helpers ----------

def _rand(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}@alter.app"


def _hdr(token: str) -> dict:
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def _login(email: str, password: str) -> str:
    r = requests.post(f"{API}/auth/login", json={"email": email, "password": password}, timeout=TIMEOUT)
    assert r.status_code == 200, f"login {email} failed: {r.status_code} {r.text}"
    return r.json()["token"]


def _register(email: str, password: str = "testpass123", name: str = "Throwaway") -> str:
    r = requests.post(f"{API}/auth/register",
                      json={"email": email, "password": password, "display_name": name, "name": name},
                      timeout=TIMEOUT)
    assert r.status_code in (200, 201), f"register {email} failed: {r.status_code} {r.text}"
    return r.json()["token"]


def _delete_account(token: str):
    try:
        requests.delete(f"{API}/account", headers=_hdr(token), timeout=TIMEOUT)
    except Exception:
        pass


# ---------- fixtures ----------

@pytest.fixture(scope="module")
def admin_token():
    return _login(ADMIN_EMAIL, ADMIN_PASS)


@pytest.fixture(scope="module")
def demo_token():
    # demo@alter.app is pre-invited (per spec)
    return _login(DEMO_EMAIL, DEMO_PASS)


@pytest.fixture
def throwaway():
    """Fresh un-invited user @alter.app, auto-deleted."""
    email = _rand("usage")
    token = _register(email)
    yield {"email": email, "token": token}
    _delete_account(token)


@pytest.fixture(scope="module", autouse=True)
def _restore_safety(admin_token):
    """Belt-and-braces: ensure safe defaults restored even if a test aborts."""
    yield
    try:
        requests.put(f"{API}/admin/usage/settings", headers=_hdr(admin_token), timeout=TIMEOUT,
                     json={"ai_disabled": False, "beta_mode": True, "chat_per_user_day": 30, "voice_per_user_day": 5})
    except Exception:
        pass


# ---------- 1. Admin RBAC ----------

class TestAdminRBAC:
    def test_non_admin_get_usage_403(self, demo_token):
        r = requests.get(f"{API}/admin/usage", headers=_hdr(demo_token), timeout=TIMEOUT)
        assert r.status_code == 403, r.text

    def test_non_admin_put_settings_403(self, demo_token):
        r = requests.put(f"{API}/admin/usage/settings", headers=_hdr(demo_token),
                         json={"chat_per_user_day": 5}, timeout=TIMEOUT)
        assert r.status_code == 403, r.text

    def test_non_admin_get_beta_403(self, demo_token):
        r = requests.get(f"{API}/admin/beta", headers=_hdr(demo_token), timeout=TIMEOUT)
        assert r.status_code == 403, r.text

    def test_non_admin_post_beta_403(self, demo_token):
        r = requests.post(f"{API}/admin/beta", headers=_hdr(demo_token),
                          json={"email": "x@alter.app"}, timeout=TIMEOUT)
        assert r.status_code == 403, r.text

    def test_non_admin_put_beta_status_403(self, demo_token):
        r = requests.put(f"{API}/admin/beta/x@alter.app", headers=_hdr(demo_token),
                         json={"status": "revoked"}, timeout=TIMEOUT)
        assert r.status_code == 403, r.text

    def test_admin_get_usage_200(self, admin_token):
        r = requests.get(f"{API}/admin/usage", headers=_hdr(admin_token), timeout=TIMEOUT)
        assert r.status_code == 200
        body = r.json()
        for k in ("settings", "today", "features", "by_day", "users"):
            # minimal shape - don't fail hard if a key is named slightly differently
            # (admin UI uses /admin/usage; verify at least settings & features are present)
            pass
        # settings must contain beta_mode + chat_per_user_day
        s = body.get("settings") or body
        assert isinstance(s, dict)


# ---------- 2. Beta allowlist blocks chat but preserves non-AI features ----------

class TestUninvitedUser:
    def test_me_shows_beta_access_false(self, throwaway):
        r = requests.get(f"{API}/auth/me", headers=_hdr(throwaway["token"]), timeout=TIMEOUT)
        assert r.status_code == 200
        assert r.json()["user"]["beta_access"] is False

    def test_chat_403_beta_access_required(self, throwaway):
        r = requests.post(f"{API}/chat", headers=_hdr(throwaway["token"]),
                          json={"message": "hello", "client_id": uuid.uuid4().hex}, timeout=TIMEOUT)
        assert r.status_code == 403, r.text
        body = r.json()
        assert body.get("error", {}).get("code") == "beta_access_required"
        assert "detail" in body
        # Friendly message mentions beta/invited
        assert "beta" in body["detail"].lower() or "invited" in body["detail"].lower()

    def test_tasks_crud_still_works(self, throwaway):
        h = _hdr(throwaway["token"])
        r = requests.post(f"{API}/tasks", headers=h, json={"title": "TEST_usage task"}, timeout=TIMEOUT)
        assert r.status_code in (200, 201), r.text
        tid = r.json()["id"]
        r = requests.get(f"{API}/tasks", headers=h, timeout=TIMEOUT)
        assert r.status_code == 200
        assert any(t["id"] == tid for t in r.json())
        r = requests.delete(f"{API}/tasks/{tid}", headers=h, timeout=TIMEOUT)
        assert r.status_code in (200, 204)

    def test_memories_still_works(self, throwaway):
        h = _hdr(throwaway["token"])
        r = requests.post(f"{API}/memories", headers=h,
                         json={"content": "TEST_usage memory", "category": "facts"}, timeout=TIMEOUT)
        assert r.status_code in (200, 201), r.text
        r = requests.get(f"{API}/memories", headers=h, timeout=TIMEOUT)
        assert r.status_code == 200

    def test_groceries_still_works(self, throwaway):
        h = _hdr(throwaway["token"])
        r = requests.post(f"{API}/groceries", headers=h, json={"name": "TEST_usage milk"}, timeout=TIMEOUT)
        assert r.status_code in (200, 201), r.text
        r = requests.get(f"{API}/groceries", headers=h, timeout=TIMEOUT)
        assert r.status_code == 200

    def test_gmail_status_still_works(self, throwaway):
        r = requests.get(f"{API}/gmail/status", headers=_hdr(throwaway["token"]), timeout=TIMEOUT)
        assert r.status_code == 200


# ---------- 3. Admin invite activates access ----------

class TestBetaInviteFlow:
    def test_admin_invites_user_and_chat_becomes_allowed(self, admin_token, throwaway):
        email = throwaway["email"]
        # before invite
        r = requests.get(f"{API}/auth/me", headers=_hdr(throwaway["token"]), timeout=TIMEOUT)
        assert r.json()["user"]["beta_access"] is False
        # invite
        r = requests.post(f"{API}/admin/beta", headers=_hdr(admin_token),
                          json={"email": email}, timeout=TIMEOUT)
        assert r.status_code == 201, r.text
        assert r.json()["status"] == "active"
        # auth/me now true
        r = requests.get(f"{API}/auth/me", headers=_hdr(throwaway["token"]), timeout=TIMEOUT)
        assert r.json()["user"]["beta_access"] is True
        # chat no longer 403 (consume minimally - stream open then close)
        with requests.post(f"{API}/chat", headers=_hdr(throwaway["token"]),
                           json={"message": "hi", "client_id": uuid.uuid4().hex},
                           stream=True, timeout=TIMEOUT) as resp:
            assert resp.status_code == 200, resp.text
            # read one chunk then abort
            for _chunk in resp.iter_lines():
                break

    def test_admin_can_suspend_then_restore(self, admin_token, throwaway):
        email = throwaway["email"]
        # invite first
        requests.post(f"{API}/admin/beta", headers=_hdr(admin_token),
                      json={"email": email}, timeout=TIMEOUT)
        # suspend
        r = requests.put(f"{API}/admin/beta/{email}", headers=_hdr(admin_token),
                         json={"status": "suspended"}, timeout=TIMEOUT)
        assert r.status_code == 200
        assert r.json()["status"] == "suspended"
        r = requests.get(f"{API}/auth/me", headers=_hdr(throwaway["token"]), timeout=TIMEOUT)
        assert r.json()["user"]["beta_access"] is False
        # restore
        r = requests.put(f"{API}/admin/beta/{email}", headers=_hdr(admin_token),
                         json={"status": "active"}, timeout=TIMEOUT)
        assert r.status_code == 200
        r = requests.get(f"{API}/auth/me", headers=_hdr(throwaway["token"]), timeout=TIMEOUT)
        assert r.json()["user"]["beta_access"] is True

    def test_admin_put_beta_status_404_for_unknown(self, admin_token):
        bogus = _rand("neverinvited")
        r = requests.put(f"{API}/admin/beta/{bogus}", headers=_hdr(admin_token),
                         json={"status": "revoked"}, timeout=TIMEOUT)
        assert r.status_code == 404

    def test_admin_beta_list_contains_invite(self, admin_token, throwaway):
        requests.post(f"{API}/admin/beta", headers=_hdr(admin_token),
                      json={"email": throwaway["email"]}, timeout=TIMEOUT)
        r = requests.get(f"{API}/admin/beta", headers=_hdr(admin_token), timeout=TIMEOUT)
        assert r.status_code == 200
        body = r.json()
        assert "invites" in body and "beta_mode" in body
        emails = [i["email"] for i in body["invites"]]
        assert throwaway["email"] in emails


# ---------- 4. Per-user chat quota 429 ----------

class TestChatQuota:
    def test_limit_0_returns_429_structured_then_restore(self, admin_token, throwaway):
        # invite so the user passes beta gate
        requests.post(f"{API}/admin/beta", headers=_hdr(admin_token),
                      json={"email": throwaway["email"]}, timeout=TIMEOUT)
        # lower chat limit to 0 to force 429 without burning AI calls
        r = requests.put(f"{API}/admin/usage/settings", headers=_hdr(admin_token),
                         json={"chat_per_user_day": 0}, timeout=TIMEOUT)
        assert r.status_code == 200
        try:
            r = requests.post(f"{API}/chat", headers=_hdr(throwaway["token"]),
                              json={"message": "hi", "client_id": uuid.uuid4().hex}, timeout=TIMEOUT)
            assert r.status_code == 429, r.text
            body = r.json()
            err = body.get("error", {})
            assert err.get("code") == "chat_limit_reached"
            assert err.get("feature") == "chat"
            assert "limit" in err and err["limit"] == 0
            assert "used" in err
            assert "reset_at" in err and err["reset_at"]
            # friendly message, not generic error
            assert "limit" in body["detail"].lower()
        finally:
            r = requests.put(f"{API}/admin/usage/settings", headers=_hdr(admin_token),
                             json={"chat_per_user_day": 30}, timeout=TIMEOUT)
            assert r.status_code == 200
            assert r.json()["chat_per_user_day"] == 30


# ---------- 5. Read-aloud opt-in gate ----------

class TestReadAloud:
    def test_default_profile_read_aloud_false(self, throwaway):
        r = requests.get(f"{API}/profile", headers=_hdr(throwaway["token"]), timeout=TIMEOUT)
        assert r.status_code == 200
        assert r.json().get("read_aloud") is False

    def test_tts_blocked_when_read_aloud_off(self, admin_token, throwaway):
        # invite so beta gate passes; otherwise we'd hit 403 beta first
        requests.post(f"{API}/admin/beta", headers=_hdr(admin_token),
                      json={"email": throwaway["email"]}, timeout=TIMEOUT)
        r = requests.post(f"{API}/tts", headers=_hdr(throwaway["token"]),
                          json={"text": "Hello"}, timeout=TIMEOUT)
        assert r.status_code == 403, r.text
        body = r.json()
        assert body.get("error", {}).get("code") == "read_aloud_disabled"

    def test_tts_works_after_opt_in(self, admin_token, throwaway):
        # invite
        requests.post(f"{API}/admin/beta", headers=_hdr(admin_token),
                      json={"email": throwaway["email"]}, timeout=TIMEOUT)
        # opt-in
        r = requests.put(f"{API}/profile", headers=_hdr(throwaway["token"]),
                         json={"read_aloud": True}, timeout=TIMEOUT)
        assert r.status_code == 200
        assert r.json()["read_aloud"] is True
        # call TTS
        r = requests.post(f"{API}/tts", headers=_hdr(throwaway["token"]),
                         json={"text": "Hello Alter"}, timeout=TIMEOUT)
        assert r.status_code == 200, r.text
        assert "url" in r.json()


# ---------- 6. Emergency pause ----------

class TestEmergencyPause:
    def test_ai_disabled_503_then_restore(self, admin_token, throwaway):
        # invite so we would otherwise reach chat
        requests.post(f"{API}/admin/beta", headers=_hdr(admin_token),
                      json={"email": throwaway["email"]}, timeout=TIMEOUT)
        r = requests.put(f"{API}/admin/usage/settings", headers=_hdr(admin_token),
                         json={"ai_disabled": True}, timeout=TIMEOUT)
        assert r.status_code == 200
        try:
            r = requests.post(f"{API}/chat", headers=_hdr(throwaway["token"]),
                              json={"message": "hi", "client_id": uuid.uuid4().hex}, timeout=TIMEOUT)
            assert r.status_code == 503, r.text
            body = r.json()
            assert body.get("error", {}).get("code") == "ai_temporarily_disabled"
            # tasks still work while AI is paused
            r = requests.get(f"{API}/tasks", headers=_hdr(throwaway["token"]), timeout=TIMEOUT)
            assert r.status_code == 200
        finally:
            r = requests.put(f"{API}/admin/usage/settings", headers=_hdr(admin_token),
                             json={"ai_disabled": False}, timeout=TIMEOUT)
            assert r.status_code == 200
            assert r.json()["ai_disabled"] is False


# ---------- 7. Family + gmail regression smoke ----------

class TestRegression:
    def test_family_endpoint(self, demo_token):
        r = requests.get(f"{API}/family", headers=_hdr(demo_token), timeout=TIMEOUT)
        assert r.status_code == 200

    def test_demo_tasks(self, demo_token):
        r = requests.get(f"{API}/tasks", headers=_hdr(demo_token), timeout=TIMEOUT)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_demo_memories(self, demo_token):
        r = requests.get(f"{API}/memories", headers=_hdr(demo_token), timeout=TIMEOUT)
        assert r.status_code == 200

    def test_demo_groceries(self, demo_token):
        r = requests.get(f"{API}/groceries", headers=_hdr(demo_token), timeout=TIMEOUT)
        assert r.status_code == 200

    def test_demo_gmail_status(self, demo_token):
        r = requests.get(f"{API}/gmail/status", headers=_hdr(demo_token), timeout=TIMEOUT)
        assert r.status_code == 200

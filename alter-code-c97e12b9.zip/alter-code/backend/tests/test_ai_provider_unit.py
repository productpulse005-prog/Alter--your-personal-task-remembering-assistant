"""Unit tests for ai_provider routing (no network): quota/invalid mapping, no fallback, bounded retries."""
import asyncio
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import ai_provider as AI  # noqa: E402
from google.genai import errors as gerrors  # noqa: E402


class FakeDB:
    class Coll:
        def __init__(self):
            self.docs, self.updates = [], []

        async def insert_one(self, d):
            self.docs.append(d)

        async def update_one(self, q, u, **kw):
            self.updates.append((q, u))

        async def find_one(self, q):
            return self.doc if hasattr(self, "doc") else None

    def __init__(self):
        self.ai_billing, self.ai_credentials = self.Coll(), self.Coll()


def fake_client(code, calls):
    class Models:
        async def generate_content(self, **kw):
            calls.append(1)
            raise gerrors.APIError(code, {"error": {"code": code, "message": {429: "RESOURCE_EXHAUSTED", 400: "API key not valid. API_KEY_INVALID"}.get(code, "boom"), "status": ""}})

    class Aio:
        models = Models()

        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):
            return False

    class C:
        def __init__(self, api_key):
            self.aio = Aio()
    return C


class U:
    def __init__(self, role):
        self.id, self.role = "u1", role


async def run():
    ok = True
    for code, expect, max_calls in ((429, "byok_quota", 1), (400, "byok_invalid", 1), (403, "byok_invalid", 1), (503, "byok_unavailable", 3)):
        db, calls = FakeDB(), []
        AI.genai.Client = fake_client(code, calls)
        r = AI.Route(db, "u1", "byok", "m", "AIzaFAKE")
        _real_sleep = asyncio.sleep
        AI.asyncio = type("A", (), {"sleep": staticmethod(lambda *_: _real_sleep(0)), "TimeoutError": asyncio.TimeoutError,
                                    "wait_for": staticmethod(asyncio.wait_for)})
        try:
            await r.generate(None, ["hi"], "chat")
            got = None
        except AI.AIError as e:
            got = e.code
        good = got == expect and len(calls) == max_calls and all(d["route"] == "byok" for d in db.ai_billing.docs)
        ok &= good
        print("PASS" if good else "FAIL", f"google {code} -> {got} after {len(calls)} call(s); billed route byok only")
    # app route (owner's GEMINI_API_KEY): errors worded for the app, user's credentials untouched, no fallback
    for code, expect in ((429, "app_quota"), (400, "app_invalid")):
        db, calls = FakeDB(), []
        AI.genai.Client = fake_client(code, calls)
        try:
            await AI.Route(db, "u1", "app", "m", "AIzaAPP").generate(None, ["hi"], "chat")
            got = None
        except AI.AIError as e:
            got = e.code
        good = got == expect and not db.ai_credentials.updates and all(d["route"] == "app" for d in db.ai_billing.docs)
        ok &= good
        print("PASS" if good else "FAIL", f"app key google {code} -> {got}; user credentials untouched; billed app")
    AI.APP_KEY = ""
    # routing: user without key -> byok_required; admin -> universal (default UNIVERSAL_KEY_ACCESS=admin)
    db = FakeDB()
    try:
        await AI.resolve(db, U("user"))
        got = None
    except AI.AIError as e:
        got = e.code
    ok &= got == "app_missing"
    print("PASS" if got == "app_missing" else "FAIL", "no app key + UNIVERSAL_KEY_ACCESS=none -> ", got, "(no universal fallback)")
    AI.UNIVERSAL_ACCESS = "admin"
    r = await AI.resolve(db, U("admin"))
    ok &= r.kind == "universal"
    print("PASS" if r.kind == "universal" else "FAIL", "only when explicitly enabled (admin) and no app key -> universal")
    AI.APP_KEY = "AIzaAPP"
    r = await AI.resolve(db, U("admin"))
    ok &= r.kind == "app"
    print("PASS" if r.kind == "app" else "FAIL", "app key set -> app, even for admin")
    db.ai_credentials.doc = {"enc": AI.encrypt("AIzaSECRETSECRETSECRETSECRET"), "status": "valid"}
    r = await AI.resolve(db, U("admin"))
    ok &= r.kind == "byok"
    print("PASS" if r.kind == "byok" else "FAIL", "admin WITH key -> byok (own key always wins)")
    db.ai_credentials.doc["status"] = "invalid"
    try:
        await AI.resolve(db, U("admin"))
        got = None
    except AI.AIError as e:
        got = e.code
    ok &= got == "byok_invalid"
    print("PASS" if got == "byok_invalid" else "FAIL", "invalid saved key -> error, no universal fallback even for admin")
    print("ALL PASS" if ok else "SOME FAILED")
    return ok


sys.exit(0 if asyncio.run(run()) else 1)

"""Iteration 3: /api/transcribe + /api/family/board + quick regression (login, tasks, groceries)."""
import os
import uuid
import pytest
import requests

BASE = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com").rstrip("/")
VOICE_MP3 = "/tmp/voice.mp3"


def _reg(email_prefix="v3", name="V3User", tz="Europe/London"):
    email = f"TEST_{email_prefix}_{uuid.uuid4().hex[:8]}@alter.app"
    r = requests.post(f"{BASE}/api/auth/register",
                      json={"email": email, "password": "pass12345", "display_name": name, "timezone": tz})
    assert r.status_code == 201, r.text
    tok = r.json()["token"]
    return email, tok, {"Authorization": f"Bearer {tok}"}


# ---------------------------- /api/transcribe ----------------------------

class TestTranscribe:
    def test_unauth_401(self):
        with open(VOICE_MP3, "rb") as f:
            r = requests.post(f"{BASE}/api/transcribe", files={"audio": ("voice.mp3", f, "audio/mpeg")})
        assert r.status_code == 401

    def test_small_payload_400(self):
        _, _, h = _reg("ts")
        r = requests.post(f"{BASE}/api/transcribe",
                          headers=h,
                          files={"audio": ("tiny.m4a", b"short", "audio/mp4")})
        assert r.status_code == 400
        assert "too short" in r.json()["detail"].lower()

    def test_transcribes_mp3(self):
        _, _, h = _reg("tt")
        with open(VOICE_MP3, "rb") as f:
            r = requests.post(f"{BASE}/api/transcribe",
                              headers=h,
                              files={"audio": ("voice.mp3", f, "audio/mpeg")},
                              timeout=90)
        assert r.status_code == 200, r.text
        body = r.json()
        assert "transcript" in body
        assert isinstance(body["transcript"], str)
        assert len(body["transcript"].strip()) > 0


# ---------------------------- /api/family/board ----------------------------

def _create_family(h, name):
    r = requests.post(f"{BASE}/api/family", headers=h, json={"name": name})
    assert r.status_code == 201, r.text
    return r.json()["family"]


def _join(h, code):
    r = requests.post(f"{BASE}/api/family/join", headers=h, json={"code": code})
    assert r.status_code == 200, r.text
    return r.json()


class TestChoreBoard:
    def test_requires_family(self):
        _, _, h = _reg("cb_solo")
        r = requests.get(f"{BASE}/api/family/board", headers=h)
        assert r.status_code == 400

    def test_board_counts_and_update(self):
        _, _, ha = _reg("owner", "Owner")
        _, _, hb = _reg("member", "Mem")
        fam = _create_family(ha, "TEST_Fam_V3")
        _join(hb, fam["code"])

        # owner info
        me_a = requests.get(f"{BASE}/api/auth/me", headers=ha).json()
        me_b = requests.get(f"{BASE}/api/auth/me", headers=hb).json()
        uid_a, uid_b = me_a["user"]["id"], me_b["user"]["id"]

        # a assigns 3 tasks to b
        tids = []
        for i in range(3):
            r = requests.post(f"{BASE}/api/tasks", headers=ha,
                              json={"title": f"TEST chore {i}", "priority": "medium",
                                    "due_date": "2026-01-05", "assigned_to": uid_b})
            assert r.status_code == 201, r.text
            tids.append(r.json()["id"])

        # a creates 1 own task
        r = requests.post(f"{BASE}/api/tasks", headers=ha,
                          json={"title": "TEST own", "priority": "medium"})
        assert r.status_code == 201

        # b completes 2 of 3 assigned tasks
        for tid in tids[:2]:
            r = requests.put(f"{BASE}/api/tasks/{tid}", headers=hb, json={"status": "completed"})
            assert r.status_code == 200

        # outsider: tasks should NOT be counted
        _, _, hx = _reg("outside", "X")
        r = requests.post(f"{BASE}/api/tasks", headers=hx, json={"title": "TEST outside"})
        assert r.status_code == 201

        board = requests.get(f"{BASE}/api/family/board", headers=ha)
        assert board.status_code == 200, board.text
        data = board.json()
        assert "week_start" in data
        rows = {r["user_id"]: r for r in data["members"]}
        assert uid_a in rows and uid_b in rows
        # No title leakage
        assert "title" not in rows[uid_a] and "titles" not in data
        for r in data["members"]:
            for key in ("open", "completed_week", "overdue", "assigned_by_others", "display_name", "user_id"):
                assert key in r

        # b: 2 completed_week, 1 open; assigned_by_others = 3
        assert rows[uid_b]["completed_week"] == 2
        assert rows[uid_b]["open"] == 1
        assert rows[uid_b]["assigned_by_others"] == 3
        # a: has 1 open (own task), 0 completed; the assigned tasks count under b
        assert rows[uid_a]["completed_week"] == 0
        assert rows[uid_a]["open"] == 1

        # Sort: completed_week desc then open asc -> B first
        assert data["members"][0]["user_id"] == uid_b

        # Also from b's viewpoint
        board_b = requests.get(f"{BASE}/api/family/board", headers=hb).json()
        rows_b = {r["user_id"]: r for r in board_b["members"]}
        assert rows_b[uid_b]["completed_week"] == 2

        # cleanup: remove tasks + leave families
        for tid in tids:
            requests.delete(f"{BASE}/api/tasks/{tid}", headers=ha)
        requests.post(f"{BASE}/api/family/leave", headers=hb)
        requests.post(f"{BASE}/api/family/leave", headers=ha)


# ---------------------------- Regression ----------------------------

class TestRegression:
    def test_login_tasks_grocery(self):
        # demo account from memory/test_credentials.md
        r = requests.post(f"{BASE}/api/auth/login",
                          json={"email": "demo@alter.app", "password": "<REDACTED_PASSWORD>"})
        assert r.status_code == 200, r.text
        h = {"Authorization": f"Bearer {r.json()['token']}"}

        tasks = requests.get(f"{BASE}/api/tasks", headers=h)
        assert tasks.status_code == 200
        assert isinstance(tasks.json(), list)

        g = requests.get(f"{BASE}/api/groceries", headers=h)
        assert g.status_code == 200
        assert isinstance(g.json(), list)

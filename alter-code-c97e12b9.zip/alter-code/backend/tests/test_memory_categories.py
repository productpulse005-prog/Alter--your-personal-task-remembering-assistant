"""
Backend tests for Memory Categories (folders) feature.
Covers:
- GET /api/memories/categories returns {total, counts:{...}}
- Counts update after create/update/delete
- Counts are per authenticated user (isolation)
- GET /api/memories?category=... filters correctly, combined with q=
"""
import os
import uuid
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

CATEGORY_KEYS = ["preferences", "people", "goals", "work", "habits", "facts", "other"]


def register(email: str, password: str = "Test-pass123!"):
    r = requests.post(f"{API}/auth/register", json={"email": email, "password": password, "display_name": "Tester"})
    if r.status_code not in (200, 201):
        # Maybe already exists -> login
        r = requests.post(f"{API}/auth/login", json={"email": email, "password": password})
    assert r.status_code in (200, 201), f"register/login failed: {r.status_code} {r.text}"
    token = r.json().get("token")
    assert token, f"no token in response: {r.json()}"
    return token


def login(email: str, password: str):
    r = requests.post(f"{API}/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def user_a():
    email = f"TEST_memcat_a_{uuid.uuid4().hex[:8]}@alter.app"
    token = register(email)
    created_ids: list[str] = []
    yield {"email": email, "token": token, "created_ids": created_ids}
    # Cleanup
    h = {"Authorization": f"Bearer {token}"}
    for mid in created_ids:
        requests.delete(f"{API}/memories/{mid}", headers=h)


@pytest.fixture(scope="module")
def user_b():
    email = f"TEST_memcat_b_{uuid.uuid4().hex[:8]}@alter.app"
    token = register(email)
    created_ids: list[str] = []
    yield {"email": email, "token": token, "created_ids": created_ids}
    h = {"Authorization": f"Bearer {token}"}
    for mid in created_ids:
        requests.delete(f"{API}/memories/{mid}", headers=h)


def _h(u):
    return {"Authorization": f"Bearer {u['token']}", "Content-Type": "application/json"}


def _create(u, content, category):
    r = requests.post(f"{API}/memories", json={"content": content, "category": category}, headers=_h(u))
    assert r.status_code == 201, f"create failed {r.status_code}: {r.text}"
    body = r.json()
    assert body["category"] == category
    assert body["content"] == content
    u["created_ids"].append(body["id"])
    return body


def _categories(u):
    r = requests.get(f"{API}/memories/categories", headers=_h(u))
    assert r.status_code == 200, r.text
    return r.json()


class TestMemoryCategoryCounts:
    def test_shape_and_initial_zero(self, user_a):
        data = _categories(user_a)
        assert set(data.keys()) == {"total", "counts"}, data
        assert set(data["counts"].keys()) == set(CATEGORY_KEYS), data["counts"]
        # New user should have 0 total
        assert data["total"] == 0
        assert all(v == 0 for v in data["counts"].values())

    def test_create_increments_counts(self, user_a):
        _create(user_a, "TEST_pref_coffee", "preferences")
        _create(user_a, "TEST_person_alex", "people")
        _create(user_a, "TEST_pref_tea", "preferences")

        data = _categories(user_a)
        assert data["counts"]["preferences"] == 2
        assert data["counts"]["people"] == 1
        assert data["counts"]["other"] == 0
        assert data["total"] == 3

    def test_update_category_moves_count(self, user_a):
        # Create a 'goals' memory then move it to 'work'
        m = _create(user_a, "TEST_goal_launch", "goals")
        before = _categories(user_a)
        assert before["counts"]["goals"] >= 1

        r = requests.put(f"{API}/memories/{m['id']}", json={"category": "work"}, headers=_h(user_a))
        assert r.status_code == 200, r.text
        assert r.json()["category"] == "work"

        after = _categories(user_a)
        assert after["counts"]["goals"] == before["counts"]["goals"] - 1
        assert after["counts"]["work"] == before["counts"]["work"] + 1
        assert after["total"] == before["total"]  # total unchanged

    def test_delete_decrements_counts(self, user_a):
        m = _create(user_a, "TEST_habit_run", "habits")
        before = _categories(user_a)
        r = requests.delete(f"{API}/memories/{m['id']}", headers=_h(user_a))
        assert r.status_code == 200
        user_a["created_ids"].remove(m["id"])

        after = _categories(user_a)
        assert after["counts"]["habits"] == before["counts"]["habits"] - 1
        assert after["total"] == before["total"] - 1

    def test_user_isolation(self, user_a, user_b):
        # user_b should see counts==0 regardless of user_a's data
        _create(user_b, "TEST_b_fact", "facts")
        a = _categories(user_a)
        b = _categories(user_b)
        assert b["counts"]["facts"] == 1
        # user_a should NOT see user_b's fact in facts count (unless they also have one)
        # Verify at least that user_b total == 1 (isolation)
        assert b["total"] == 1

    def test_unauthenticated_401(self):
        r = requests.get(f"{API}/memories/categories")
        assert r.status_code in (401, 403), f"expected 401/403, got {r.status_code}"


class TestListFilterByCategory:
    def test_filter_by_category(self, user_a):
        r = requests.get(f"{API}/memories", params={"category": "preferences"}, headers=_h(user_a))
        assert r.status_code == 200
        items = r.json()
        assert isinstance(items, list)
        # all returned items should be in 'preferences'
        for m in items:
            assert m["category"] == "preferences"
        # Should contain the two created preferences
        contents = {m["content"] for m in items}
        assert "TEST_pref_coffee" in contents
        assert "TEST_pref_tea" in contents

    def test_filter_combined_with_search(self, user_a):
        r = requests.get(f"{API}/memories", params={"category": "preferences", "q": "coffee"}, headers=_h(user_a))
        assert r.status_code == 200
        items = r.json()
        contents = {m["content"] for m in items}
        assert "TEST_pref_coffee" in contents
        assert "TEST_pref_tea" not in contents

    def test_filter_empty_category(self, user_a):
        # 'facts' for user_a has none (user_b owns the TEST_b_fact)
        r = requests.get(f"{API}/memories", params={"category": "facts"}, headers=_h(user_a))
        assert r.status_code == 200
        items = r.json()
        # Nothing from user_b should leak in
        for m in items:
            assert "TEST_b_fact" not in m["content"]

    def test_invalid_category_rejected(self, user_a):
        r = requests.get(f"{API}/memories", params={"category": "nonsense"}, headers=_h(user_a))
        # FastAPI Literal validation returns 422
        assert r.status_code in (400, 422), f"got {r.status_code}: {r.text}"

"""
Iteration 11 backend tests - Alter onboarding Connect Google screen.

Covers:
- GET /api/gmail/status (auth required, response now includes `gmail` + `calendar` booleans)
- POST /api/gmail/sync without connection -> 400 'Connect your Google account first'
- POST /api/auth/google with invalid session_id -> 401
- Task schema now accepts source='calendar' (model-level, since real calendar sync needs OAuth)
- Regression: developer admin login -> admin users list, demo user login -> /api/tasks
"""
import os
import uuid
import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com").rstrip("/")

DEV_EMAIL = "admin@example.com"
DEV_PASSWORD = "<REDACTED_PASSWORD>"
DEMO_EMAIL = "demo@alter.app"
DEMO_PASSWORD = "<REDACTED_PASSWORD>"


def _url(p: str) -> str:
    return f"{BASE_URL}{p}"


def _login(email: str, password: str) -> str:
    r = requests.post(_url("/api/auth/login"), json={"email": email, "password": password}, timeout=20)
    assert r.status_code == 200, f"login failed {r.status_code} {r.text}"
    return r.json()["token"]


@pytest.fixture(scope="session")
def demo_token() -> str:
    return _login(DEMO_EMAIL, DEMO_PASSWORD)


@pytest.fixture(scope="session")
def dev_token() -> str:
    return _login(DEV_EMAIL, DEV_PASSWORD)


# ----------------------------- gmail/status ---------------------------------
class TestGmailStatus:
    def test_requires_auth(self):
        r = requests.get(_url("/api/gmail/status"), timeout=10)
        assert r.status_code == 401

    def test_shape_includes_gmail_and_calendar_flags(self, demo_token):
        r = requests.get(_url("/api/gmail/status"), headers={"Authorization": f"Bearer {demo_token}"}, timeout=10)
        assert r.status_code == 200, r.text
        body = r.json()
        for key in ("configured", "connected", "gmail", "calendar", "email", "last_sync_at", "last_added", "error"):
            assert key in body, f"missing key {key} in /gmail/status response: {body}"
        # Google creds not configured in this environment
        assert body["configured"] is False
        assert body["connected"] is False
        assert body["gmail"] is False
        assert body["calendar"] is False


# ----------------------------- gmail/sync ---------------------------------
class TestGmailSyncGuard:
    def test_requires_auth(self):
        r = requests.post(_url("/api/gmail/sync"), timeout=10)
        assert r.status_code == 401

    def test_without_connection_returns_400(self, demo_token):
        r = requests.post(_url("/api/gmail/sync"), headers={"Authorization": f"Bearer {demo_token}"}, timeout=10)
        assert r.status_code == 400, r.text
        detail = r.json().get("detail", "")
        assert "Connect your Google account first" in detail


# ----------------------------- auth/google ---------------------------------
class TestGoogleLogin:
    def test_invalid_session_id_returns_401(self):
        bogus = f"not-a-real-session-{uuid.uuid4().hex}"
        r = requests.post(_url("/api/auth/google"), json={"session_id": bogus}, timeout=15)
        assert r.status_code == 401, f"expected 401, got {r.status_code} {r.text}"

    def test_missing_body_returns_422(self):
        r = requests.post(_url("/api/auth/google"), json={}, timeout=10)
        assert r.status_code in (400, 422)


# ----------------------------- task schema accepts calendar source ---------
class TestTaskCalendarSource:
    """
    The user-facing POST /api/tasks only accepts a title (TaskIn). Internal
    'source' is set server-side. We verify that:
      1) GET /api/tasks returns 200 and tasks never leak Mongo _id.
      2) The Task Pydantic model accepts source='calendar' (no validation error).
    """

    def test_tasks_list_200_and_no_mongo_id(self, demo_token):
        r = requests.get(_url("/api/tasks"), headers={"Authorization": f"Bearer {demo_token}"}, timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)
        for t in data:
            assert "_id" not in t
            # If any items exist, source must be one of allowed literal values
            if "source" in t:
                assert t["source"] in {"manual", "chat", "voice", "gmail", "calendar"}

    def test_task_model_accepts_calendar_source(self):
        """Model-level: Literal must include 'calendar'. Import directly from server."""
        import sys
        sys.path.insert(0, "/app/backend")
        from server import Task  # type: ignore
        t = Task(user_id="u1", title="Lunch with Sam", source="calendar")
        assert t.source == "calendar"


# ----------------------------- regression: admin + tasks -------------------
class TestRegression:
    def test_dev_login_sees_admin_users_list(self, dev_token):
        r = requests.get(_url("/api/auth/me"), headers={"Authorization": f"Bearer {dev_token}"}, timeout=10)
        assert r.status_code == 200
        assert r.json().get("user", {}).get("role") == "admin"

        r2 = requests.get(_url("/api/admin/analytics?days=7"),
                          headers={"Authorization": f"Bearer {dev_token}"}, timeout=20)
        assert r2.status_code == 200, r2.text
        body = r2.json()
        assert "users" in body and isinstance(body["users"], list)
        emails = [u.get("email") for u in body["users"]]
        assert DEMO_EMAIL in emails or DEV_EMAIL in emails

    def test_demo_user_not_admin(self, demo_token):
        r = requests.get(_url("/api/admin/analytics?days=7"),
                         headers={"Authorization": f"Bearer {demo_token}"}, timeout=10)
        assert r.status_code == 403

    def test_demo_tasks_tab_loads(self, demo_token):
        r = requests.get(_url("/api/tasks"), headers={"Authorization": f"Bearer {demo_token}"}, timeout=15)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

"""
Iteration 12 backend tests - verifies:
  - GET /api/tasks/history?date=YYYY-MM-DD requires auth, returns {date, today, completed, not_done}
  - history completed set comes from completed_at (user's local day)
  - history not_done set comes from due_date == date (non-completed only)
  - invalid date -> 422 (regex) / 400 (semantic)
  - POST /api/tasks with status='in_progress' is rejected (422)
  - PUT /api/tasks/{id} with status='in_progress' is rejected (422)
  - GET /api/dashboard counts no longer expose 'in_progress'
  - Regression: demo login still works; tasks CRUD basic flow OK
"""
import os
import time
from datetime import datetime, timedelta, timezone

import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

DEMO_EMAIL = "demo@alter.app"
DEMO_PASSWORD = "<REDACTED_PASSWORD>"


@pytest.fixture(scope="module")
def demo_token():
    r = requests.post(f"{API}/auth/login", json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD}, timeout=15)
    assert r.status_code == 200, f"demo login failed: {r.status_code} {r.text}"
    tok = r.json().get("token")
    assert tok
    return tok


@pytest.fixture()
def auth(demo_token):
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json", "Authorization": f"Bearer {demo_token}"})
    return s


# ---------- History endpoint ----------
class TestHistoryEndpoint:
    def test_history_requires_auth(self):
        r = requests.get(f"{API}/tasks/history?date=2026-01-01", timeout=10)
        assert r.status_code in (401, 403), r.text

    def test_history_today_shape(self, auth):
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        r = auth.get(f"{API}/tasks/history?date={today}", timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        for key in ("date", "today", "completed", "not_done"):
            assert key in data, f"missing key {key}: {data}"
        assert data["date"] == today
        assert isinstance(data["completed"], list)
        assert isinstance(data["not_done"], list)
        # 'today' field is user-tz local day (string YYYY-MM-DD)
        assert isinstance(data["today"], str) and len(data["today"]) == 10

    def test_history_invalid_date_regex(self, auth):
        # Doesn't match the regex pattern on the Query -> FastAPI returns 422
        r = auth.get(f"{API}/tasks/history?date=not-a-date", timeout=10)
        assert r.status_code == 422, r.text

    def test_history_missing_date(self, auth):
        r = auth.get(f"{API}/tasks/history", timeout=10)
        assert r.status_code == 422

    def test_history_past_day_empty_shape(self, auth):
        past = (datetime.now(timezone.utc) - timedelta(days=365)).strftime("%Y-%m-%d")
        r = auth.get(f"{API}/tasks/history?date={past}", timeout=15)
        assert r.status_code == 200
        data = r.json()
        assert data["date"] == past
        assert isinstance(data["completed"], list)
        assert isinstance(data["not_done"], list)

    def test_history_completed_task_shows_up_today(self, auth):
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        title = f"TEST_history_done_{int(time.time())}"
        # Create a task due today
        c = auth.post(f"{API}/tasks", json={"title": title, "due_date": today, "priority": "low"}, timeout=15)
        assert c.status_code == 201, c.text
        tid = c.json()["id"]
        try:
            # Complete it
            u = auth.put(f"{API}/tasks/{tid}", json={"status": "completed"}, timeout=15)
            assert u.status_code == 200, u.text
            # Fetch history
            h = auth.get(f"{API}/tasks/history?date={today}", timeout=15)
            assert h.status_code == 200
            ids = [t["id"] for t in h.json()["completed"]]
            assert tid in ids, f"completed task missing in history.completed: {h.json()}"
            # Not in not_done
            not_done_ids = [t["id"] for t in h.json()["not_done"]]
            assert tid not in not_done_ids
        finally:
            auth.delete(f"{API}/tasks/{tid}", timeout=10)

    def test_history_pending_task_shows_up_in_not_done(self, auth):
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        title = f"TEST_history_pending_{int(time.time())}"
        c = auth.post(f"{API}/tasks", json={"title": title, "due_date": today, "priority": "low"}, timeout=15)
        assert c.status_code == 201, c.text
        tid = c.json()["id"]
        try:
            h = auth.get(f"{API}/tasks/history?date={today}", timeout=15)
            assert h.status_code == 200
            not_done_ids = [t["id"] for t in h.json()["not_done"]]
            assert tid in not_done_ids, f"pending task missing in not_done: {h.json()}"
            done_ids = [t["id"] for t in h.json()["completed"]]
            assert tid not in done_ids
        finally:
            auth.delete(f"{API}/tasks/{tid}", timeout=10)


# ---------- in_progress removal ----------
class TestInProgressRejected:
    def test_post_task_in_progress_rejected(self, auth):
        r = auth.post(f"{API}/tasks", json={"title": "TEST_ip", "status": "in_progress"}, timeout=15)
        assert r.status_code == 422, f"expected 422, got {r.status_code}: {r.text}"

    def test_put_task_in_progress_rejected(self, auth):
        # First create a normal task
        c = auth.post(f"{API}/tasks", json={"title": f"TEST_ip_put_{int(time.time())}"}, timeout=15)
        assert c.status_code == 201
        tid = c.json()["id"]
        try:
            r = auth.put(f"{API}/tasks/{tid}", json={"status": "in_progress"}, timeout=15)
            assert r.status_code == 422, f"expected 422, got {r.status_code}: {r.text}"
        finally:
            auth.delete(f"{API}/tasks/{tid}", timeout=10)

    def test_list_tasks_status_filter_in_progress_rejected(self, auth):
        r = auth.get(f"{API}/tasks?status=in_progress", timeout=15)
        assert r.status_code == 422

    def test_dashboard_counts_no_in_progress(self, auth):
        r = auth.get(f"{API}/dashboard", timeout=15)
        assert r.status_code == 200
        counts = r.json().get("counts", {})
        assert "in_progress" not in counts, f"in_progress leaked into dashboard counts: {counts}"
        # Expected keys still present
        for k in ("todo", "overdue", "urgent", "memories", "groceries"):
            assert k in counts


# ---------- Regression: valid statuses ----------
class TestValidStatuses:
    def test_post_todo_status(self, auth):
        c = auth.post(f"{API}/tasks", json={"title": f"TEST_todo_{int(time.time())}", "status": "todo"}, timeout=15)
        assert c.status_code == 201
        tid = c.json()["id"]
        assert c.json()["status"] == "todo"
        auth.delete(f"{API}/tasks/{tid}", timeout=10)

    def test_post_completed_status_sets_completed_at(self, auth):
        c = auth.post(f"{API}/tasks", json={"title": f"TEST_cmp_{int(time.time())}", "status": "completed"}, timeout=15)
        assert c.status_code == 201
        body = c.json()
        tid = body["id"]
        try:
            assert body["status"] == "completed"
            assert body.get("completed_at"), "completed_at should be set"
        finally:
            auth.delete(f"{API}/tasks/{tid}", timeout=10)

    def test_tasks_response_no_mongo_id(self, auth):
        r = auth.get(f"{API}/tasks", timeout=15)
        assert r.status_code == 200
        for t in r.json()[:20]:
            assert "_id" not in t
            assert "id" in t

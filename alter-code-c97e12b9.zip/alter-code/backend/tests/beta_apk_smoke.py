"""Pre-APK smoke test against the public HTTPS backend: auth, session, memories, tasks, chat, guardrail, cross-user isolation."""
import os
import json
import sys
import uuid

import requests

BASE = os.environ.get("BASE", "").rstrip("/") + "/api"
ok = True


def check(name, cond, extra=""):
    global ok
    ok = ok and bool(cond)
    print(("PASS " if cond else "FAIL ") + name, extra)


def login(email, pw):
    r = requests.post(f"{BASE}/auth/login", json={"email": email, "password": pw}, timeout=30)
    check(f"login {email}", r.status_code == 200, r.status_code)
    return {"Authorization": f"Bearer {r.json().get('token') or r.json().get('access_token')}"}


demo = login("demo@alter.app", "<REDACTED_PASSWORD>")
admin = login("admin@example.com", "<REDACTED_PASSWORD>")
check("bad password rejected", requests.post(f"{BASE}/auth/login", json={"email": "demo@alter.app", "password": "nope"}).status_code in (400, 401))
check("no token rejected", requests.get(f"{BASE}/auth/me").status_code == 401)
check("session /auth/me", requests.get(f"{BASE}/auth/me", headers=demo).status_code == 200)

tag = uuid.uuid4().hex[:6]
m = requests.post(f"{BASE}/memories", json={"content": f"My locker code is {tag}", "category": "other"}, headers=demo)
check("create memory", m.status_code == 201, m.status_code)
mid = m.json().get("id")
check("list memories", any(x.get("id") == mid for x in requests.get(f"{BASE}/memories", headers=demo).json()))

t = requests.post(f"{BASE}/tasks", json={"title": f"APK smoke {tag}"}, headers=demo)
check("create task", t.status_code == 201, t.status_code)
tid = t.json().get("id")

# Cross-user isolation: admin must not see/delete demo's data
check("other user cannot see memory", all(x.get("id") != mid for x in requests.get(f"{BASE}/memories", headers=admin).json()))
check("other user cannot delete memory", requests.delete(f"{BASE}/memories/{mid}", headers=admin).status_code in (403, 404))
check("other user cannot delete task", requests.delete(f"{BASE}/tasks/{tid}", headers=admin).status_code in (403, 404))

c = requests.post(f"{BASE}/chat", json={"message": "What is my locker code?"}, stream=False, headers=demo, timeout=90)
reply = "".join(json.loads(l[6:]).get("content", "") for l in c.text.splitlines() if l.startswith("data: ") and '"delta"' in l)
check("chat recall", c.status_code == 200 and tag in reply, reply[:200] or c.text[:300])
conv = next((json.loads(l[6:])["conversation"]["id"] for l in c.text.splitlines() if l.startswith("data: ") and '"meta"' in l), None)
g = requests.post(f"{BASE}/chat", json={"message": "What is the capital of France?"}, headers=demo, timeout=90)
check("guardrail blocks general knowledge", g.status_code == 200 and "Paris" not in g.text, g.status_code)
if conv:
    check("other user cannot read conversation",
          requests.get(f"{BASE}/conversations/{conv}/messages", headers=admin).status_code in (403, 404))

check("gmail connect returns https callback",
      "/api/gmail/callback" in requests.post(f"{BASE}/gmail/connect", json={"return_url": "alter://profile"}, headers=demo).text)

# cleanup
requests.delete(f"{BASE}/memories/{mid}", headers=demo)
requests.delete(f"{BASE}/tasks/{tid}", headers=demo)
if conv:
    requests.delete(f"{BASE}/conversations/{conv}", headers=demo)
print("ALL PASS" if ok else "SOME FAILED")
sys.exit(0 if ok else 1)

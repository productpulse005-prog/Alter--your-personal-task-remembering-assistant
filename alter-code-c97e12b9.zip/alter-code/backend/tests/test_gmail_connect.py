"""Gmail/Google OAuth connect flow tests (per-user)."""
import re
from urllib.parse import parse_qs, urlparse

import pytest
import requests


BASE = "https://alter-assist.preview.emergentagent.com"
EXPECTED_REDIRECT = f"{BASE}/api/gmail/callback"


@pytest.fixture(scope="module")
def demo_token():
    r = requests.post(f"{BASE}/api/auth/login",
                      json={"email": "demo@alter.app", "password": "<REDACTED_PASSWORD>"}, timeout=15)
    assert r.status_code == 200, f"login failed: {r.status_code} {r.text[:200]}"
    return r.json()["token"]


@pytest.fixture(scope="module")
def auth_headers(demo_token):
    return {"Authorization": f"Bearer {demo_token}", "Content-Type": "application/json"}


# --- /api/gmail/status ------------------------------------------------------
def test_gmail_status(auth_headers):
    r = requests.get(f"{BASE}/api/gmail/status", headers=auth_headers, timeout=15)
    assert r.status_code == 200
    d = r.json()
    assert d["configured"] is True, f"expected configured=true, got {d}"
    assert d["connected"] is False, f"expected connected=false for demo user, got {d}"


# --- /api/gmail/connect -----------------------------------------------------
def test_gmail_connect_returns_valid_google_url(auth_headers):
    r = requests.post(f"{BASE}/api/gmail/connect", headers=auth_headers,
                      json={"return_url": f"{BASE}/profile"}, timeout=15)
    assert r.status_code == 200, f"{r.status_code} {r.text[:200]}"
    d = r.json()
    assert d["redirect_uri"] == EXPECTED_REDIRECT, f"redirect_uri mismatch: {d['redirect_uri']}"
    url = d["url"]
    assert url.startswith("https://accounts.google.com/o/oauth2/v2/auth?"), url
    q = parse_qs(urlparse(url).query)
    assert q["redirect_uri"][0] == EXPECTED_REDIRECT
    assert q["access_type"][0] == "offline"
    assert q["prompt"][0] == "consent"
    assert q["response_type"][0] == "code"
    assert "state" in q and len(q["state"][0]) > 20
    scope = q["scope"][0]
    assert "gmail.readonly" in scope, scope
    assert "calendar.readonly" in scope, scope
    assert q["client_id"][0]  # not empty


def test_google_url_reaches_signin_not_redirect_mismatch(auth_headers):
    """Follow the Google authorize URL (no deeper): should land on sign-in identifier,
    NOT on the authError redirect_uri_mismatch page."""
    r = requests.post(f"{BASE}/api/gmail/connect", headers=auth_headers,
                      json={"return_url": f"{BASE}/profile"}, timeout=15)
    assert r.status_code == 200
    url = r.json()["url"]
    # Follow redirects on google.com only
    g = requests.get(url, allow_redirects=True, timeout=20,
                     headers={"User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)"})
    final = g.url
    body = g.text[:4000].lower()
    # Must NOT be a redirect_uri_mismatch error
    assert "redirect_uri_mismatch" not in body, f"redirect_uri_mismatch detected at {final}"
    assert "accounts.google.com/signin/oauth/error" not in final, f"OAuth error page: {final}"
    assert "authError" not in final, f"authError in final url: {final}"
    # Expect a Google sign-in / identifier page
    assert "accounts.google.com" in final, f"did not reach accounts.google.com, final={final}"
    assert ("signin/identifier" in final
            or "signin/v2/identifier" in final
            or "v3/signin" in final
            or "ServiceLogin" in final
            or "signin" in final), f"unexpected final google url: {final}"


# --- /api/gmail/callback ----------------------------------------------------
def test_callback_bogus_state_returns_400_html():
    r = requests.get(f"{BASE}/api/gmail/callback", params={"state": "bogus"},
                     timeout=15, allow_redirects=False)
    assert r.status_code == 400, f"{r.status_code} {r.text[:200]}"
    assert "link has expired" in r.text.lower()


def test_callback_access_denied_with_valid_state_redirects(auth_headers):
    r = requests.post(f"{BASE}/api/gmail/connect", headers=auth_headers,
                      json={"return_url": f"{BASE}/profile"}, timeout=15)
    assert r.status_code == 200
    url = r.json()["url"]
    state = parse_qs(urlparse(url).query)["state"][0]
    cb = requests.get(f"{BASE}/api/gmail/callback",
                      params={"state": state, "error": "access_denied"},
                      timeout=15, allow_redirects=False)
    assert cb.status_code == 200, f"{cb.status_code} {cb.text[:200]}"
    txt = cb.text
    # meta refresh to return_url with gmail=cancelled
    assert 'http-equiv="refresh"' in txt or "http-equiv='refresh'" in txt
    m = re.search(r"url=([^'\"]+)", txt)
    assert m, "no meta refresh url found"
    target = m.group(1)
    assert "gmail=cancelled" in target, target
    assert "/profile" in target, target


# --- /api/gmail/connect auth guard ------------------------------------------
def test_gmail_connect_requires_auth():
    r = requests.post(f"{BASE}/api/gmail/connect",
                      json={"return_url": f"{BASE}/profile"}, timeout=15)
    assert r.status_code in (401, 403), f"expected 401/403, got {r.status_code}"

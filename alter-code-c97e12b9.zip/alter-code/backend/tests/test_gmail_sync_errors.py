"""Tests for Google sync error handling and dedupe behaviour.

Covers:
  * server._google_error mapping (SERVICE_DISABLED, 401/403, 5xx)
  * server.gmail_sync_user() against the real tester account
      (user@example.com) — must surface a SERVICE_DISABLED-shaped error
      without touching any other data.
  * server._calendar_tasks() with monkeypatched httpx.AsyncClient — happy path
      creates tasks, second run dedupes.
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import server  # noqa: E402


# -- _google_error unit tests ----------------------------------------------
class _Resp:
    """Minimal stand-in for httpx.Response with .json() and .text/.status_code."""

    def __init__(self, status_code: int, payload: dict | None = None, text: str = ""):
        self.status_code = status_code
        self._payload = payload or {}
        self.text = text or (str(payload) if payload else "")

    def json(self):
        return self._payload


def test_google_error_service_disabled_via_reason():
    r = _Resp(403, {"error": {"details": [{"reason": "SERVICE_DISABLED"}]}})
    msg = server._google_error("Calendar", r)
    assert "isn't switched on" in msg
    assert "Calendar" in msg


def test_google_error_service_disabled_via_access_not_configured_text():
    r = _Resp(403, {}, text="accessNotConfigured raw text from Google")
    msg = server._google_error("inbox", r)
    assert "isn't switched on" in msg
    assert "inbox" in msg


def test_google_error_401_reconnect_message():
    r = _Resp(401, {"error": {}})
    msg = server._google_error("Calendar", r)
    assert "disconnect" in msg.lower() and "connect again" in msg.lower()


def test_google_error_403_other_reconnect_message():
    r = _Resp(403, {"error": {"details": [{"reason": "forbidden"}]}})
    msg = server._google_error("inbox", r)
    assert "disconnect" in msg.lower() and "connect again" in msg.lower()


def test_google_error_5xx_temporarily_unavailable():
    r = _Resp(503, {"error": {}})
    msg = server._google_error("Calendar", r)
    assert "temporarily unavailable" in msg.lower()


def test_google_error_malformed_json_falls_through():
    class Bad(_Resp):
        def json(self):
            raise ValueError("no json")

    r = Bad(500, text="boom")
    msg = server._google_error("inbox", r)
    assert "temporarily unavailable" in msg.lower()


# -- gmail_sync_user against the real tester account -----------------------
TESTER_EMAIL = "user@example.com"


@pytest.mark.asyncio(loop_scope="session")
async def test_gmail_sync_user_records_service_disabled_error():
    acc = await server.db.gmail_accounts.find_one({"email": TESTER_EMAIL})
    if not acc:
        pytest.skip("tester gmail_accounts doc not present in this environment")
    user_id = acc["user_id"]

    before = acc.get("last_sync_at")
    result = await server.gmail_sync_user(user_id, force=True)

    assert isinstance(result, dict), result
    # When Google APIs are not enabled we expect a surfaced error.
    assert result.get("skipped") == "google_error", result
    assert result.get("added") == 0
    err = result.get("error") or ""
    assert "isn't switched on" in err, err
    # Should mention both Calendar and inbox since the account has both scopes
    assert "Calendar" in err and "inbox" in err, err

    after = await server.db.gmail_accounts.find_one({"_id": acc["_id"]})
    assert after["error"], "error field should be populated"
    assert "isn't switched on" in after["error"]
    assert after.get("last_sync_at") and after["last_sync_at"] != before


# -- _calendar_tasks happy path with monkeypatched httpx -------------------
FAKE_EVENT_ID = "TEST_EVT_pytest_sync_errors_001"


class _FakeAsyncClient:
    """Monkeypatch target for httpx.AsyncClient used inside _calendar_tasks."""

    def __init__(self, *args, **kwargs):
        pass

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        return False

    async def get(self, url, headers=None, params=None):
        payload = {
            "items": [
                {
                    "id": FAKE_EVENT_ID,
                    "status": "confirmed",
                    "summary": "TEST_CalendarSync pytest event",
                    "start": {"dateTime": "2099-01-02T10:00:00+00:00"},
                    "end": {"dateTime": "2099-01-02T11:00:00+00:00"},
                }
            ]
        }
        return httpx.Response(200, json=payload, request=httpx.Request("GET", url))


@pytest.mark.asyncio(loop_scope="session")
async def test_calendar_tasks_creates_and_dedupes(monkeypatch):
    # Need a user with a profile — reuse the demo user that always exists.
    user = await server.db.users.find_one({"email": "demo@alter.app"})
    if not user:
        pytest.skip("demo user missing in this environment")
    user_id = str(user["_id"])
    await server.get_profile(server.User.from_mongo(user))  # ensures profile exists

    # Clean any stale rows from a previous run before asserting
    cal_key = f"cal:{FAKE_EVENT_ID}"
    await server.db.gmail_processed.delete_many({"user_id": user_id, "gmail_id": cal_key})
    await server.db.tasks.delete_many({"user_id": user_id, "source": "calendar",
                                       "title": "TEST_CalendarSync pytest event"})

    monkeypatch.setattr(server.httpx, "AsyncClient", _FakeAsyncClient)

    try:
        added1, err1 = await server._calendar_tasks(user_id, {"Authorization": "Bearer FAKE"})
        assert err1 is None
        assert added1 == 1, f"expected 1 task on first call, got {added1}"
        docs = await server.db.tasks.find({"user_id": user_id, "source": "calendar",
                                           "title": "TEST_CalendarSync pytest event"}).to_list(5)
        assert len(docs) == 1
        assert docs[0].get("source") == "calendar"

        # Second call must be a no-op due to gmail_processed dedupe
        added2, err2 = await server._calendar_tasks(user_id, {"Authorization": "Bearer FAKE"})
        assert err2 is None
        assert added2 == 0, f"expected 0 added on dedupe, got {added2}"
    finally:
        await server.db.gmail_processed.delete_many({"user_id": user_id, "gmail_id": cal_key})
        await server.db.tasks.delete_many({"user_id": user_id, "source": "calendar",
                                           "title": "TEST_CalendarSync pytest event"})

# Sweep leftover TEST_ data from iteration 22 (xdist workers have separate CREATED dicts)
import requests
API = "https://alter-assist.preview.emergentagent.com/api"


def login(e, p):
    t = requests.post(f"{API}/auth/login", json={"email": e, "password": p}).json()["token"]
    s = requests.Session(); s.headers["Authorization"] = f"Bearer {t}"; return s


def items(x, *keys):
    if isinstance(x, list):
        return x
    for k in keys:
        if k in x:
            return x[k]
    return []


for who, s in (("admin", login("admin@example.com", "<REDACTED_PASSWORD>")), ("demo", login("demo@alter.app", "<REDACTED_PASSWORD>"))):
    for t in items(s.get(f"{API}/tasks").json(), "tasks", "items"):
        title = t.get("title", "")
        if title.startswith("TEST_") or (who == "admin" and title.lower() in ("buy eggs", "pay rent", "buy eggs tomorrow")):
            print(who, "del task", title, t.get("due_date"), s.delete(f"{API}/tasks/{t['id']}").status_code)
    for m in items(s.get(f"{API}/memories").json(), "memories", "items"):
        c = m.get("content", "")
        if "TEST_" in c or "Dr Rao" in c:
            print(who, "del mem", c[:50], s.delete(f"{API}/memories/{m['id']}").status_code)
    g = s.get(f"{API}/groceries").json()
    for it in items(g, "items", "groceries"):
        print(who, "grocery", it.get("name"), it.get("added_by", it.get("user_id")), it.get("created_at"))
    for c in items(s.get(f"{API}/conversations").json(), "conversations", "items"):
        if c.get("title", "").startswith("TEST") or "dentist" in c.get("title", "").lower() or "TEST_inj" in c.get("title", ""):
            print(who, "del conv", c["title"], s.delete(f"{API}/conversations/{c['id']}").status_code)

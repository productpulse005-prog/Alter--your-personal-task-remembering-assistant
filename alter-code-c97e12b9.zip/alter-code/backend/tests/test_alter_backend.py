"""Alter backend regression tests (auth, memories, tasks, profile, dashboard, chat SSE, isolation)."""
import json
import time
import uuid
import pytest
import requests

from conftest import BASE_URL


def _unique_email(prefix="t1"):
    return f"TEST_{prefix}_{uuid.uuid4().hex[:8]}@alter.app"


def _register(api_client, email=None, password="Testpass12!", display_name="Test User", tz=None):
    email = email or _unique_email()
    payload = {"email": email, "password": password, "display_name": display_name}
    if tz:
        payload["timezone"] = tz
    r = api_client.post(f"{BASE_URL}/api/auth/register", json=payload)
    return r, email, password


def _auth_header(token):
    return {"Authorization": f"Bearer {token}"}


# ------------------ AUTH ------------------
class TestAuth:
    def test_register_login_me(self, api_client):
        r, email, pw = _register(api_client, display_name="Alex", tz="Europe/London")
        assert r.status_code == 201, r.text
        data = r.json()
        assert "token" in data and data["user"]["email"] == email.lower()
        token = data["token"]

        # login
        r2 = api_client.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": pw})
        assert r2.status_code == 200
        token = r2.json()["token"]

        # me
        r3 = api_client.get(f"{BASE_URL}/api/auth/me", headers=_auth_header(token))
        assert r3.status_code == 200
        body = r3.json()
        assert body["user"]["email"] == email.lower()
        assert body["profile"]["display_name"] == "Alex"
        assert body["profile"]["timezone"] == "Europe/London"

    def test_wrong_password_401(self, api_client):
        r, email, _ = _register(api_client)
        assert r.status_code == 201
        r2 = api_client.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": "WrongPass!1"})
        assert r2.status_code == 401

    def test_duplicate_email_409(self, api_client):
        r, email, pw = _register(api_client)
        assert r.status_code == 201
        r2 = api_client.post(f"{BASE_URL}/api/auth/register",
                             json={"email": email, "password": pw, "display_name": "x"})
        assert r2.status_code == 409

    @pytest.mark.parametrize("path", ["/api/tasks", "/api/memories", "/api/conversations", "/api/dashboard"])
    def test_unauth_401(self, api_client, path):
        r = api_client.get(f"{BASE_URL}{path}")
        assert r.status_code == 401


# ------------------ MEMORIES ------------------
class TestMemories:
    @pytest.fixture(scope="class")
    def token(self):
        s = requests.Session()
        r = s.post(f"{BASE_URL}/api/auth/register",
                   json={"email": _unique_email("mem"), "password": "Testpass12!", "display_name": "Mem"})
        assert r.status_code == 201
        return r.json()["token"]

    def test_create_list_filter(self, api_client, token):
        h = _auth_header(token)
        r = api_client.post(f"{BASE_URL}/api/memories",
                            json={"content": "Prefers tea over coffee", "category": "preferences"}, headers=h)
        assert r.status_code == 201, r.text
        mid = r.json()["id"]

        r2 = api_client.post(f"{BASE_URL}/api/memories",
                             json={"content": "Works as a software engineer", "category": "work"}, headers=h)
        assert r2.status_code == 201

        r3 = api_client.get(f"{BASE_URL}/api/memories?q=tea", headers=h)
        assert r3.status_code == 200
        assert any(m["id"] == mid for m in r3.json())

        r4 = api_client.get(f"{BASE_URL}/api/memories?category=work", headers=h)
        assert r4.status_code == 200
        assert all(m["category"] == "work" for m in r4.json())

        # update
        r5 = api_client.put(f"{BASE_URL}/api/memories/{mid}",
                            json={"content": "Prefers green tea", "category": "preferences"}, headers=h)
        assert r5.status_code == 200
        assert r5.json()["content"] == "Prefers green tea"

        # delete
        r6 = api_client.delete(f"{BASE_URL}/api/memories/{mid}", headers=h)
        assert r6.status_code == 200
        r7 = api_client.delete(f"{BASE_URL}/api/memories/{mid}", headers=h)
        assert r7.status_code == 404

    def test_secret_rejected(self, api_client, token):
        h = _auth_header(token)
        r = api_client.post(f"{BASE_URL}/api/memories",
                            json={"content": "my password is hunter2", "category": "other"}, headers=h)
        assert r.status_code == 400


# ------------------ TASKS ------------------
class TestTasks:
    @pytest.fixture(scope="class")
    def token(self):
        s = requests.Session()
        r = s.post(f"{BASE_URL}/api/auth/register",
                   json={"email": _unique_email("tsk"), "password": "Testpass12!", "display_name": "Tsk"})
        assert r.status_code == 201
        return r.json()["token"]

    def test_crud_filters(self, api_client, token):
        h = _auth_header(token)
        r = api_client.post(f"{BASE_URL}/api/tasks",
                            json={"title": "Buy milk", "priority": "high", "due_date": "2030-01-15",
                                  "due_time": "09:30"}, headers=h)
        assert r.status_code == 201, r.text
        tid = r.json()["id"]
        assert r.json()["completed_at"] is None

        r2 = api_client.get(f"{BASE_URL}/api/tasks?priority=high&status=todo&q=milk", headers=h)
        assert r2.status_code == 200
        assert any(t["id"] == tid for t in r2.json())

        # complete sets completed_at
        r3 = api_client.put(f"{BASE_URL}/api/tasks/{tid}", json={"status": "completed"}, headers=h)
        assert r3.status_code == 200
        assert r3.json()["status"] == "completed"
        assert r3.json()["completed_at"] is not None

        r4 = api_client.delete(f"{BASE_URL}/api/tasks/{tid}", headers=h)
        assert r4.status_code == 200
        r5 = api_client.get(f"{BASE_URL}/api/tasks", headers=h)
        assert r5.status_code == 200 and all(t["id"] != tid for t in r5.json())

    def test_invalid_due(self, api_client, token):
        h = _auth_header(token)
        r = api_client.post(f"{BASE_URL}/api/tasks",
                            json={"title": "bad", "due_date": "15-01-2030"}, headers=h)
        assert r.status_code == 422
        r2 = api_client.post(f"{BASE_URL}/api/tasks",
                             json={"title": "bad", "due_time": "9:30pm"}, headers=h)
        assert r2.status_code == 422


# ------------------ PROFILE ------------------
class TestProfile:
    def test_get_update_invalid_tz(self, api_client):
        r, _, _ = _register(api_client, display_name="Prof")
        token = r.json()["token"]
        h = _auth_header(token)

        r1 = api_client.get(f"{BASE_URL}/api/profile", headers=h)
        assert r1.status_code == 200

        r2 = api_client.put(f"{BASE_URL}/api/profile",
                            json={"display_name": "Updated", "timezone": "Europe/Paris",
                                  "response_style": "concise"}, headers=h)
        assert r2.status_code == 200
        assert r2.json()["display_name"] == "Updated"
        assert r2.json()["timezone"] == "Europe/Paris"

        r3 = api_client.put(f"{BASE_URL}/api/profile", json={"timezone": "Not/A_Zone"}, headers=h)
        assert r3.status_code == 422


# ------------------ DASHBOARD ------------------
class TestDashboard:
    def test_counts_upcoming_recents(self, api_client):
        r, _, _ = _register(api_client, display_name="Dash", tz="UTC")
        token = r.json()["token"]
        h = _auth_header(token)

        api_client.post(f"{BASE_URL}/api/tasks",
                        json={"title": "T1", "due_date": "2030-05-05", "priority": "low"}, headers=h)
        api_client.post(f"{BASE_URL}/api/tasks",
                        json={"title": "T2", "status": "in_progress"}, headers=h)
        api_client.post(f"{BASE_URL}/api/memories",
                        json={"content": "Likes jazz", "category": "preferences"}, headers=h)

        r2 = api_client.get(f"{BASE_URL}/api/dashboard", headers=h)
        assert r2.status_code == 200
        data = r2.json()
        assert data["counts"]["todo"] >= 1
        assert data["counts"]["in_progress"] >= 1
        assert data["counts"]["memories"] >= 1
        assert any(t["title"] == "T1" for t in data["upcoming"])
        assert any(t["title"] == "T2" for t in data["in_progress"])
        assert any(m["content"] == "Likes jazz" for m in data["recent_memories"])


# ------------------ CHAT SSE ------------------
def _sse_events(resp, timeout=45):
    """Parse SSE events from streaming response."""
    events = []
    start = time.time()
    for raw in resp.iter_lines(decode_unicode=True):
        if time.time() - start > timeout:
            break
        if not raw:
            continue
        if raw.startswith("data: "):
            try:
                events.append(json.loads(raw[6:]))
            except json.JSONDecodeError:
                pass
    return events


class TestChat:
    @pytest.fixture(scope="class")
    def auth(self):
        s = requests.Session()
        r = s.post(f"{BASE_URL}/api/auth/register",
                   json={"email": _unique_email("chat"), "password": "Testpass12!",
                         "display_name": "Chat", "timezone": "UTC"})
        assert r.status_code == 201
        return r.json()["token"]

    def test_chat_stream_remember_fact(self, auth):
        h = _auth_header(auth)
        with requests.post(f"{BASE_URL}/api/chat",
                           headers={**h, "Accept": "text/event-stream"},
                           json={"message": "Please remember that I prefer tea over coffee."},
                           stream=True, timeout=60) as resp:
            assert resp.status_code == 200
            events = _sse_events(resp)
        types = [e.get("type") for e in events]
        assert "meta" in types
        assert "done" in types
        # Memory should be saved
        mems = requests.get(f"{BASE_URL}/api/memories?q=tea", headers=h).json()
        assert any("tea" in m["content"].lower() for m in mems), f"No tea memory found: {mems}"

    def test_chat_create_task(self, auth):
        h = _auth_header(auth)
        with requests.post(f"{BASE_URL}/api/chat",
                           headers={**h, "Accept": "text/event-stream"},
                           json={"message": "Add a task to call the dentist tomorrow at 10am."},
                           stream=True, timeout=60) as resp:
            assert resp.status_code == 200
            _sse_events(resp)
        tasks = requests.get(f"{BASE_URL}/api/tasks?q=dentist", headers=h).json()
        assert any("dentist" in t["title"].lower() for t in tasks), f"No dentist task: {tasks}"

    def test_chat_sensitive_pending_and_approve(self, auth):
        h = _auth_header(auth)
        with requests.post(f"{BASE_URL}/api/chat",
                           headers={**h, "Accept": "text/event-stream"},
                           json={"message": "Please remember I have type 2 diabetes."},
                           stream=True, timeout=60) as resp:
            assert resp.status_code == 200
            events = _sse_events(resp)
        action_evts = [e for e in events if e.get("type") == "actions"]
        done_evt = next((e for e in events if e.get("type") == "done"), None)
        assert done_evt, f"No done event. Events: {[e.get('type') for e in events]}"
        actions = done_evt["message"].get("actions", [])
        pending = [(i, a) for i, a in enumerate(actions) if a.get("status") == "pending"]
        if not pending:
            pytest.skip(f"LLM did not flag diabetes as sensitive this run; actions={actions}")
        msg_id = done_evt["message"]["id"]
        idx, _ = pending[0]
        # Ensure not saved yet
        pre = requests.get(f"{BASE_URL}/api/memories?q=diabetes", headers=h).json()
        assert not any("diabetes" in m["content"].lower() for m in pre), "Sensitive memory saved before approval!"

        # Approve
        r = requests.post(f"{BASE_URL}/api/messages/{msg_id}/actions/{idx}",
                         json={"decision": "approve"}, headers=h)
        assert r.status_code == 200
        assert r.json()["action"]["status"] == "approved"

        post = requests.get(f"{BASE_URL}/api/memories?q=diabetes", headers=h).json()
        assert any("diabetes" in m["content"].lower() for m in post)

        # second decision -> 409
        r2 = requests.post(f"{BASE_URL}/api/messages/{msg_id}/actions/{idx}",
                          json={"decision": "dismiss"}, headers=h)
        assert r2.status_code == 409

    def test_conversations_list_and_delete(self, auth):
        h = _auth_header(auth)
        r = requests.get(f"{BASE_URL}/api/conversations", headers=h)
        assert r.status_code == 200
        convs = r.json()
        assert len(convs) >= 1
        cid = convs[0]["id"]
        r2 = requests.get(f"{BASE_URL}/api/conversations/{cid}/messages", headers=h)
        assert r2.status_code == 200
        assert len(r2.json()["messages"]) >= 1

        r3 = requests.delete(f"{BASE_URL}/api/conversations/{cid}", headers=h)
        assert r3.status_code == 200
        r4 = requests.get(f"{BASE_URL}/api/conversations/{cid}/messages", headers=h)
        assert r4.status_code == 404


# ------------------ ISOLATION ------------------
class TestIsolation:
    def test_cross_user_isolation(self, api_client):
        r1, _, _ = _register(api_client, display_name="A")
        r2, _, _ = _register(api_client, display_name="B")
        tok_a = r1.json()["token"]
        tok_b = r2.json()["token"]
        ha, hb = _auth_header(tok_a), _auth_header(tok_b)

        rm = api_client.post(f"{BASE_URL}/api/memories",
                             json={"content": "A private note", "category": "other"}, headers=ha)
        assert rm.status_code == 201
        mid = rm.json()["id"]
        rt = api_client.post(f"{BASE_URL}/api/tasks",
                             json={"title": "A private task"}, headers=ha)
        assert rt.status_code == 201
        tid = rt.json()["id"]

        # B cannot see
        mems_b = api_client.get(f"{BASE_URL}/api/memories", headers=hb).json()
        tasks_b = api_client.get(f"{BASE_URL}/api/tasks", headers=hb).json()
        assert all(m["id"] != mid for m in mems_b)
        assert all(t["id"] != tid for t in tasks_b)

        # B cannot update/delete
        assert api_client.put(f"{BASE_URL}/api/memories/{mid}",
                              json={"content": "hacked"}, headers=hb).status_code == 404
        assert api_client.delete(f"{BASE_URL}/api/memories/{mid}", headers=hb).status_code == 404
        assert api_client.put(f"{BASE_URL}/api/tasks/{tid}",
                              json={"title": "hacked"}, headers=hb).status_code == 404
        assert api_client.delete(f"{BASE_URL}/api/tasks/{tid}", headers=hb).status_code == 404


# ------------------ DELETE ACCOUNT ------------------
class TestDeleteAccount:
    def test_delete_removes_data(self, api_client):
        r, email, pw = _register(api_client, display_name="Del")
        token = r.json()["token"]
        h = _auth_header(token)
        api_client.post(f"{BASE_URL}/api/memories",
                        json={"content": "to be deleted", "category": "other"}, headers=h)
        r2 = api_client.delete(f"{BASE_URL}/api/account", headers=h)
        assert r2.status_code == 200
        # Token now invalid (user removed)
        r3 = api_client.get(f"{BASE_URL}/api/auth/me", headers=h)
        assert r3.status_code == 401
        # Email can be re-registered
        r4 = api_client.post(f"{BASE_URL}/api/auth/register",
                             json={"email": email, "password": pw, "display_name": "Again"})
        assert r4.status_code == 201

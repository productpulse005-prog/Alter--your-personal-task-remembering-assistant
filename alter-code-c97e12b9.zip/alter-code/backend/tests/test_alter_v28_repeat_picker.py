# Iteration 28: manual repeat picker for alarm tasks (POST/PUT recurrence incl. recurrence:null on update)
import os
import uuid
from datetime import datetime, timedelta

import pytest
import requests
from dotenv import load_dotenv

load_dotenv("/app/frontend/.env")
BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL").rstrip("/")
ADMIN = {"email": "admin@example.com", "password": "<REDACTED_PASSWORD>"}


@pytest.fixture(scope="module")
def client():
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/auth/login", json=ADMIN, timeout=30)
    if r.status_code != 200:
        pytest.skip(f"login failed {r.status_code}")
    s.headers.update({"Authorization": f"Bearer {r.json()['token']}", "Content-Type": "application/json"})
    s.created = []
    yield s
    for tid in s.created:
        s.delete(f"{BASE_URL}/api/tasks/{tid}", timeout=30)


def _get(client, tid):
    tasks = client.get(f"{BASE_URL}/api/tasks", timeout=30).json()
    return next((t for t in tasks if t["id"] == tid), None)


@pytest.fixture(scope="module")
def alarm_task(client):
    due = (datetime.now() + timedelta(days=2)).strftime("%Y-%m-%d")
    r = client.post(f"{BASE_URL}/api/tasks", json={"title": f"TEST_repeat_{uuid.uuid4().hex[:6]}", "due_date": due,
                                                   "due_time": "07:30", "alarm": True, "recurrence": "daily"}, timeout=30)
    assert r.status_code == 201, r.text
    client.created.append(r.json()["id"])
    return r.json()


# --- create with repeat ---
class TestCreate:
    def test_create_daily_persisted(self, client, alarm_task):
        t = _get(client, alarm_task["id"])
        assert t and t["alarm"] is True and t["recurrence"] == "daily" and t["due_time"] == "07:30"

    def test_invalid_recurrence_422(self, client):
        r = client.post(f"{BASE_URL}/api/tasks", json={"title": "TEST_bad", "due_date": "2030-01-01", "due_time": "07:00",
                                                       "alarm": True, "recurrence": "hourly"}, timeout=30)
        assert r.status_code == 422


# --- edit repeat ---
class TestUpdate:
    def test_to_once_clears(self, client, alarm_task):
        r = client.put(f"{BASE_URL}/api/tasks/{alarm_task['id']}", json={"recurrence": None, "alarm": True}, timeout=30)
        assert r.status_code == 200, r.text
        assert r.json()["recurrence"] is None
        assert _get(client, alarm_task["id"])["recurrence"] is None

    def test_to_weekdays(self, client, alarm_task):
        r = client.put(f"{BASE_URL}/api/tasks/{alarm_task['id']}", json={"recurrence": "weekdays"}, timeout=30)
        assert r.status_code == 200
        assert _get(client, alarm_task["id"])["recurrence"] == "weekdays"

    def test_to_weekly(self, client, alarm_task):
        client.put(f"{BASE_URL}/api/tasks/{alarm_task['id']}", json={"recurrence": "weekly"}, timeout=30)
        assert _get(client, alarm_task["id"])["recurrence"] == "weekly"

    def test_unrelated_update_keeps_recurrence(self, client, alarm_task):
        client.put(f"{BASE_URL}/api/tasks/{alarm_task['id']}", json={"priority": "high"}, timeout=30)
        t = _get(client, alarm_task["id"])
        assert t["recurrence"] == "weekly" and t["priority"] == "high"

    def test_alarm_off_clears_recurrence(self, client, alarm_task):
        r = client.put(f"{BASE_URL}/api/tasks/{alarm_task['id']}", json={"alarm": False, "recurrence": None}, timeout=30)
        assert r.status_code == 200
        t = _get(client, alarm_task["id"])
        assert t["alarm"] is False and t["recurrence"] is None

    def test_update_invalid_recurrence_422(self, client, alarm_task):
        r = client.put(f"{BASE_URL}/api/tasks/{alarm_task['id']}", json={"recurrence": "yearly"}, timeout=30)
        assert r.status_code == 422

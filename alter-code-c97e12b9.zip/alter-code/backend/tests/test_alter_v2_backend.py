"""Alter backend v2 tests: voice, family, groceries, task assignment, chat family actions, dashboard counts."""
import io
import json
import os
import time
import uuid

import pytest
import requests

from conftest import BASE_URL


def _unique_email(prefix="t2"):
    return f"TEST_{prefix}_{uuid.uuid4().hex[:8]}@alter.app"


def _h(token):
    return {"Authorization": f"Bearer {token}"}


def _register(email=None, display_name="U", tz="UTC"):
    email = email or _unique_email()
    r = requests.post(f"{BASE_URL}/api/auth/register",
                      json={"email": email, "password": "Testpass12!",
                            "display_name": display_name, "timezone": tz})
    assert r.status_code == 201, r.text
    return r.json()["token"], r.json()["user"]["id"], email


# ------------------ VOICE ------------------
class TestVoice:
    @pytest.fixture(scope="class")
    def token(self):
        t, _, _ = _register(display_name="Voicer", tz="UTC")
        return t

    def test_unauth_401(self):
        with open("/tmp/voice.mp3", "rb") as f:
            r = requests.post(f"{BASE_URL}/api/voice",
                              files={"audio": ("voice.mp3", f, "audio/mpeg")})
        assert r.status_code == 401

    def test_too_short_400(self, token):
        r = requests.post(f"{BASE_URL}/api/voice",
                          headers=_h(token),
                          files={"audio": ("tiny.mp3", io.BytesIO(b"\x00" * 100), "audio/mpeg")})
        assert r.status_code == 400

    def test_transcribe_and_organise(self, token):
        with open("/tmp/voice.mp3", "rb") as f:
            r = requests.post(f"{BASE_URL}/api/voice",
                              headers=_h(token),
                              files={"audio": ("voice.mp3", f, "audio/mpeg")},
                              timeout=120)
        assert r.status_code == 200, r.text
        body = r.json()
        assert "transcript" in body
        transcript = body["transcript"].lower()
        results = body.get("results", [])
        # Expect at least one grocery action and at least one task action
        kinds = {a.get("type") for a in results if a.get("status") == "success"}
        print(f"transcript={transcript[:200]!r} kinds={kinds}")
        # transcript might differ slightly; verify at least one succeeded op
        assert kinds, f"No successful voice actions. Results: {results}"
        # Fetch groceries & tasks – at least one should exist from this call
        groc = requests.get(f"{BASE_URL}/api/groceries", headers=_h(token)).json()
        tasks = requests.get(f"{BASE_URL}/api/tasks", headers=_h(token)).json()
        assert groc or tasks, "Voice capture produced no DB rows"


# ------------------ TASK DEFAULT DUE DATE ------------------
class TestTaskDefaults:
    def test_due_date_defaults_to_today(self):
        token, _, _ = _register(display_name="DueDef", tz="UTC")
        # Create task without due_date
        r = requests.post(f"{BASE_URL}/api/tasks", headers=_h(token),
                          json={"title": "No date task"})
        assert r.status_code == 201, r.text
        from datetime import datetime, timezone
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        assert r.json()["due_date"] == today

    def test_priority_urgent_accepted(self):
        token, _, _ = _register(display_name="PrioU", tz="UTC")
        r = requests.post(f"{BASE_URL}/api/tasks", headers=_h(token),
                          json={"title": "critical", "priority": "urgent"})
        assert r.status_code == 201, r.text
        assert r.json()["priority"] == "urgent"


# ------------------ FAMILY ------------------
class TestFamily:
    def test_full_family_lifecycle(self):
        tok_a, uid_a, _ = _register(display_name="OwnerA")
        tok_b, uid_b, _ = _register(display_name="MemberB")
        tok_c, uid_c, _ = _register(display_name="OutsiderC")

        # Create family
        r = requests.post(f"{BASE_URL}/api/family", headers=_h(tok_a),
                          json={"name": "TEST_Family"})
        assert r.status_code == 201, r.text
        payload = r.json()
        code = payload["family"]["code"]
        assert len(code) == 6

        # Already in family
        r2 = requests.post(f"{BASE_URL}/api/family", headers=_h(tok_a),
                           json={"name": "Dup"})
        assert r2.status_code == 409

        # Invalid code
        r3 = requests.post(f"{BASE_URL}/api/family/join", headers=_h(tok_b),
                           json={"code": "ZZZZZZ"})
        assert r3.status_code == 404

        # Join
        r4 = requests.post(f"{BASE_URL}/api/family/join", headers=_h(tok_b),
                           json={"code": code})
        assert r4.status_code == 200
        members = r4.json()["members"]
        ids = {m["user_id"] for m in members}
        assert uid_a in ids and uid_b in ids

        # Already in family -> 409 when joining another
        tok_x, _, _ = _register(display_name="OtherOwner")
        r_x = requests.post(f"{BASE_URL}/api/family", headers=_h(tok_x),
                            json={"name": "OtherFam"})
        assert r_x.status_code == 201
        other_code = r_x.json()["family"]["code"]
        r5 = requests.post(f"{BASE_URL}/api/family/join", headers=_h(tok_b),
                           json={"code": other_code})
        assert r5.status_code == 409

        # GET family lists members
        r6 = requests.get(f"{BASE_URL}/api/family", headers=_h(tok_a))
        assert r6.status_code == 200
        assert len(r6.json()["members"]) >= 2

        # Outsider: no family
        r7 = requests.get(f"{BASE_URL}/api/family", headers=_h(tok_c))
        assert r7.status_code == 200
        assert r7.json()["family"] is None

        # Grocery assignments: A adds grocery, B sees it
        rg = requests.post(f"{BASE_URL}/api/groceries", headers=_h(tok_a),
                           json={"name": "Milk", "quantity": "2L"})
        assert rg.status_code == 201
        gid = rg.json()["id"]
        rg_b = requests.get(f"{BASE_URL}/api/groceries", headers=_h(tok_b)).json()
        assert any(g["id"] == gid for g in rg_b), "B should see A's family grocery"
        # Outsider C cannot see it or modify
        rg_c = requests.get(f"{BASE_URL}/api/groceries", headers=_h(tok_c)).json()
        assert all(g["id"] != gid for g in rg_c)
        rdel_c = requests.delete(f"{BASE_URL}/api/groceries/{gid}", headers=_h(tok_c))
        assert rdel_c.status_code == 404

        # Duplicate grocery -> 409
        rg_dup = requests.post(f"{BASE_URL}/api/groceries", headers=_h(tok_b),
                               json={"name": "Milk"})
        assert rg_dup.status_code == 409

        # Toggle checked + clear-checked
        rt = requests.put(f"{BASE_URL}/api/groceries/{gid}", headers=_h(tok_b),
                          json={"checked": True})
        assert rt.status_code == 200
        rc = requests.post(f"{BASE_URL}/api/groceries/clear-checked", headers=_h(tok_a))
        assert rc.status_code == 200 and rc.json()["deleted"] >= 1

        # TASK ASSIGNMENT: A assigns task to B
        rt1 = requests.post(f"{BASE_URL}/api/tasks", headers=_h(tok_a),
                            json={"title": "TEST assigned task", "assigned_to": uid_b})
        assert rt1.status_code == 201, rt1.text
        task_id = rt1.json()["id"]
        assert rt1.json()["assigned_to"] == uid_b
        assert rt1.json()["assigned_to_name"]

        # Assignee B sees it
        tb = requests.get(f"{BASE_URL}/api/tasks", headers=_h(tok_b)).json()
        assert any(t["id"] == task_id for t in tb)

        # B can update status only
        rp = requests.put(f"{BASE_URL}/api/tasks/{task_id}", headers=_h(tok_b),
                          json={"status": "in_progress"})
        assert rp.status_code == 200

        # B cannot update other fields
        rpt = requests.put(f"{BASE_URL}/api/tasks/{task_id}", headers=_h(tok_b),
                           json={"title": "hacked"})
        assert rpt.status_code == 403

        # B cannot delete
        rdel = requests.delete(f"{BASE_URL}/api/tasks/{task_id}", headers=_h(tok_b))
        assert rdel.status_code == 403

        # Dashboard shows counts.urgent and counts.groceries for A
        rd = requests.get(f"{BASE_URL}/api/dashboard", headers=_h(tok_a)).json()
        assert "urgent" in rd["counts"]
        assert "groceries" in rd["counts"]
        assert rd["family"] and rd["family"]["name"] == "TEST_Family"

        # Assigning to non-member -> 400
        rbad = requests.post(f"{BASE_URL}/api/tasks", headers=_h(tok_a),
                             json={"title": "bad assign", "assigned_to": uid_c})
        assert rbad.status_code == 400

        # Assigning without family -> 400
        rbad2 = requests.post(f"{BASE_URL}/api/tasks", headers=_h(tok_c),
                              json={"title": "bad", "assigned_to": uid_a})
        assert rbad2.status_code == 400

        # Leave family: B leaves
        rl = requests.post(f"{BASE_URL}/api/family/leave", headers=_h(tok_b))
        assert rl.status_code == 200

        # Verify assignment got cleared on B leaving
        tnew = requests.get(f"{BASE_URL}/api/tasks", headers=_h(tok_a)).json()
        tfound = next((t for t in tnew if t["id"] == task_id), None)
        assert tfound is not None
        assert tfound["assigned_to"] is None

        # X owner only in their family — leave to test family deletion
        rlx = requests.post(f"{BASE_URL}/api/family/leave", headers=_h(tok_x))
        assert rlx.status_code == 200
        # X groceries should be gone (none added) — just confirm family null now
        rfx = requests.get(f"{BASE_URL}/api/family", headers=_h(tok_x)).json()
        assert rfx["family"] is None

        # A still has family. A leaves -> last member -> family deleted
        rla = requests.post(f"{BASE_URL}/api/family/leave", headers=_h(tok_a))
        assert rla.status_code == 200
        rfa = requests.get(f"{BASE_URL}/api/family", headers=_h(tok_a)).json()
        assert rfa["family"] is None

    def test_personal_groceries_move_to_family_on_join(self):
        tok_a, _, _ = _register(display_name="PGa")
        tok_b, _, _ = _register(display_name="PGb")
        # B creates personal grocery before joining
        r = requests.post(f"{BASE_URL}/api/groceries", headers=_h(tok_b),
                          json={"name": "TEST_PersonalBanana"})
        assert r.status_code == 201
        # A creates family
        r2 = requests.post(f"{BASE_URL}/api/family", headers=_h(tok_a),
                           json={"name": "TEST_PFam"})
        code = r2.json()["family"]["code"]
        # B joins
        requests.post(f"{BASE_URL}/api/family/join", headers=_h(tok_b),
                      json={"code": code})
        # A should see B's grocery
        ga = requests.get(f"{BASE_URL}/api/groceries", headers=_h(tok_a)).json()
        assert any(g["name"] == "TEST_PersonalBanana" for g in ga)


# ------------------ CHAT FAMILY ACTIONS ------------------
class TestChatFamily:
    def test_chat_adds_grocery_and_assigns_task(self):
        tok_a, _, _ = _register(display_name="ChatA")
        tok_b, uid_b, _ = _register(display_name="Sam")
        r = requests.post(f"{BASE_URL}/api/family", headers=_h(tok_a),
                          json={"name": "TEST_ChatFam"})
        code = r.json()["family"]["code"]
        requests.post(f"{BASE_URL}/api/family/join", headers=_h(tok_b),
                      json={"code": code})

        with requests.post(f"{BASE_URL}/api/chat",
                           headers={**_h(tok_a), "Accept": "text/event-stream"},
                           json={"message": "we need bananas and ask Sam to take out the trash tonight"},
                           stream=True, timeout=90) as resp:
            assert resp.status_code == 200
            # drain
            for _ in resp.iter_lines(decode_unicode=True):
                pass

        groc = requests.get(f"{BASE_URL}/api/groceries", headers=_h(tok_a)).json()
        tasks = requests.get(f"{BASE_URL}/api/tasks", headers=_h(tok_a)).json()
        assert any("banana" in g["name"].lower() for g in groc), f"groceries: {groc}"
        trash = [t for t in tasks if "trash" in t["title"].lower()]
        if not trash:
            pytest.skip(f"LLM didn't create trash task this run: {tasks}")
        # assigned to Sam
        assert any(t.get("assigned_to") == uid_b for t in trash), f"trash task not assigned to Sam: {trash}"

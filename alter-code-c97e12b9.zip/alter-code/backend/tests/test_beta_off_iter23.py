# Iteration 23: Beta mode OFF -> every signed-in user can use capture/chat/voice. Global budget still in place.
import io
import os
import struct
import uuid
import wave

import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", os.environ.get("EXPO_BACKEND_URL", "")).rstrip("/")
ADMIN = {"email": "admin@example.com", "password": "<REDACTED_PASSWORD>"}
BETA_MSG = "invited beta users"
STATE = {}


def _login(creds):
    r = requests.post(f"{BASE_URL}/api/auth/login", json=creds, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_h():
    return {"Authorization": f"Bearer {_login(ADMIN)}"}


@pytest.fixture(scope="module")
def user_h():
    email = f"betaoff_{uuid.uuid4().hex[:8]}@alter.app"
    r = requests.post(f"{BASE_URL}/api/auth/register", json={"email": email, "password": "Test12345!", "display_name": "Beta Off"}, timeout=30)
    assert r.status_code in (200, 201), r.text
    STATE["email"] = email
    h = {"Authorization": f"Bearer {r.json()['token']}"}
    yield h
    # cleanup: tasks/groceries die with the account
    d = requests.delete(f"{BASE_URL}/api/account", headers=h, timeout=30)
    print("DELETE /api/account ->", d.status_code, d.text[:200])


def _silent_wav(seconds=1.0, rate=16000):
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
        w.writeframes(struct.pack("<h", 0) * int(rate * seconds))
    return buf.getvalue()


# --- admin settings: beta off, per-user limits 0, global budget 3000
class TestAdminSettings:
    def test_usage_settings(self, admin_h):
        r = requests.get(f"{BASE_URL}/api/admin/usage", headers=admin_h, timeout=30)
        assert r.status_code == 200, r.text
        data = r.json()
        STATE["usage"] = data
        s = data["settings"]
        assert s["beta_mode"] is False
        assert s["chat_per_user_day"] == 0
        assert s["voice_per_user_day"] == 0
        assert s["ai_calls_per_user_day"] == 0
        assert s["ai_calls_per_day"] == 3000

    def test_global_today_limit(self, admin_h):
        data = STATE.get("usage") or requests.get(f"{BASE_URL}/api/admin/usage", headers=admin_h, timeout=30).json()
        txt = str(data)
        print("global:", data.get("global"))
        assert data["global"]["ai_calls_today_limit"] == 3000


# --- new non-invited user: me, capture, chat, transcribe
class TestNonInvitedUser:
    def test_me_beta_access(self, user_h):
        r = requests.get(f"{BASE_URL}/api/auth/me", headers=user_h, timeout=30)
        assert r.status_code == 200
        body = r.json()
        print("me:", body)
        ba = body.get("beta_access", body.get("user", {}).get("beta_access"))
        assert ba is True

    def test_capture(self, user_h):
        r = requests.post(f"{BASE_URL}/api/capture", headers=user_h, json={"text": "buy milk"}, timeout=90)
        print("capture:", r.status_code, r.text[:600])
        assert r.status_code != 403
        assert BETA_MSG not in r.text
        d = r.json()
        if d.get("ai") is not True:
            note = str(d.get("note") or d.get("ai_note") or "")
            assert "quota" in note.lower() or "limit" in note.lower(), f"ai false with non-quota note: {d}"
            pytest.xfail(f"AI quota note (not beta): {note}")
        assert d["ai"] is True

    def test_chat(self, user_h):
        r = requests.post(f"{BASE_URL}/api/chat", headers=user_h, json={"message": "hi"}, timeout=120, stream=True)
        txt = "".join(chunk.decode("utf-8", "ignore") for chunk in r.iter_content(chunk_size=None))
        print("chat:", r.status_code, txt[:800])
        assert r.status_code != 403
        assert BETA_MSG not in txt
        assert "beta_access_required" not in txt

    def test_transcribe(self, user_h):
        audio = _silent_wav()  # >=2000 bytes so quota/beta admission path is executed
        r = requests.post(f"{BASE_URL}/api/transcribe", headers=user_h,
                          files={"audio": ("rec.wav", audio, "audio/wav")}, timeout=90)
        print("transcribe:", r.status_code, r.text[:400])
        assert r.status_code != 403
        assert "beta_access_required" not in r.text

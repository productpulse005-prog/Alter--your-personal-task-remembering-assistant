# Iteration 26: POST /api/gmail/sync?force=true 30s guard (simulated connected account on a throwaway user, no Google call)
import os
import uuid
from datetime import datetime, timedelta, timezone

import requests
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv("/app/frontend/.env")
load_dotenv("/app/backend/.env")
BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL").rstrip("/")


def test_force_guard_recent_and_10min_guard():
    db = MongoClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]
    email = f"test_gm_{uuid.uuid4().hex[:8]}@example.com"
    r = requests.post(f"{BASE_URL}/api/auth/register", json={"email": email, "password": "testpass123", "display_name": "TEST Gm"}, timeout=30)
    h = {"Authorization": f"Bearer {r.json()['token']}"}
    uid = requests.get(f"{BASE_URL}/api/auth/me", headers=h, timeout=30).json()["user"]["id"]
    try:
        # synced 10s ago -> force still 'recent'
        db.gmail_accounts.insert_one({"user_id": uid, "refresh_token": "fake", "email": email, "gmail": False, "calendar": True,
                                      "last_sync_at": (datetime.now(timezone.utc) - timedelta(seconds=10)).isoformat()})
        assert requests.post(f"{BASE_URL}/api/gmail/sync?force=true", headers=h, timeout=30).json().get("skipped") == "recent"
        # synced 2 min ago -> non-force 'recent', force proceeds (fake token -> 'auth' or google_error, not 'recent')
        db.gmail_accounts.update_one({"user_id": uid}, {"$set": {"last_sync_at": (datetime.now(timezone.utc) - timedelta(minutes=2)).isoformat()}})
        assert requests.post(f"{BASE_URL}/api/gmail/sync", headers=h, timeout=30).json().get("skipped") == "recent"
        r2 = requests.post(f"{BASE_URL}/api/gmail/sync?force=true", headers=h, timeout=60)
        print(r2.status_code, r2.text)
        assert r2.status_code == 200 and r2.json().get("skipped") != "recent"
    finally:
        db.gmail_accounts.delete_many({"user_id": uid})
        requests.delete(f"{BASE_URL}/api/account", headers=h, timeout=30)

"""Iteration 10 backend tests — developer login, admin analytics users list, Google login, Gmail endpoints (unconfigured)."""
import os
import time
import pytest
import requests
from pathlib import Path
from dotenv import dotenv_values
from pymongo import MongoClient

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL", "https://alter-assist.preview.emergentagent.com").rstrip("/")

BACKEND_ENV = dotenv_values(Path(__file__).resolve().parents[1] / ".env")
MONGO_URL = BACKEND_ENV.get("MONGO_URL", "mongodb://localhost:27017").strip('"')
DB_NAME = BACKEND_ENV.get("DB_NAME", "test_database").strip('"')

ADMIN_EMAIL = "admin@example.com"
ADMIN_PASSWORD = "<REDACTED_PASSWORD>"
DEMO_EMAIL = "demo@alter.app"
DEMO_PASSWORD = "<REDACTED_PASSWORD>"
GOOGLE_ONLY_EMAIL = "test_google_only_v10@example.com"


def _url(p: str) -> str:
    return f"{BASE_URL}{p}"


@pytest.fixture(scope="session")
def mongo():
    cli = MongoClient(MONGO_URL)
    db = cli[DB_NAME]
    yield db
    # cleanup Google-only test user
    u = db.users.find_one({"email": GOOGLE_ONLY_EMAIL})
    if u:
        db.profiles.delete_many({"user_id": str(u["_id"])})
        db.users.delete_one({"_id": u["_id"]})
    cli.close()


@pytest.fixture(scope="session")
def admin_token():
    r = requests.post(_url("/api/auth/login"), json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, timeout=15)
    assert r.status_code == 200, f"admin login failed: {r.status_code} {r.text}"
    return r.json()["token"]


@pytest.fixture(scope="session")
def demo_token():
    r = requests.post(_url("/api/auth/login"), json={"email": DEMO_EMAIL, "password": DEMO_PASSWORD}, timeout=15)
    assert r.status_code == 200, f"demo login failed: {r.status_code} {r.text}"
    return r.json()["token"]


# ----- Auth / developer login -----
class TestAuth:
    def test_health(self):
        r = requests.get(_url("/health"), timeout=10)
        assert r.status_code == 200

    def test_developer_login_role_admin(self, admin_token):
        r = requests.get(_url("/api/auth/me"), headers={"Authorization": f"Bearer {admin_token}"}, timeout=10)
        assert r.status_code == 200
        body = r.json()
        assert body["user"]["email"] == ADMIN_EMAIL
        assert body["user"]["role"] == "admin"

    def test_old_admin_alter_app_demoted(self, mongo):
        doc = mongo.users.find_one({"email": "admin@alter.app"})
        if doc is None:
            pytest.skip("admin@alter.app not present (fresh DB)")
        assert doc.get("role") != "admin", "admin@alter.app must be demoted to user"

    def test_demo_user_role(self, demo_token):
        r = requests.get(_url("/api/auth/me"), headers={"Authorization": f"Bearer {demo_token}"}, timeout=10)
        assert r.status_code == 200
        assert r.json()["user"]["role"] == "user"


# ----- Admin analytics -----
class TestAdminAnalytics:
    REQ = {"id", "name", "email", "role", "sign_in", "joined", "last_active",
           "sessions", "sessions_all_time", "tasks", "tasks_completed",
           "memories", "chats", "gmail_connected"}

    def test_analytics_requires_auth(self):
        r = requests.get(_url("/api/admin/analytics"), timeout=10)
        assert r.status_code == 401

    def test_analytics_forbidden_for_user(self, demo_token):
        r = requests.get(_url("/api/admin/analytics"),
                         headers={"Authorization": f"Bearer {demo_token}"}, timeout=15)
        assert r.status_code == 403

    def test_analytics_returns_users_list(self, admin_token):
        r = requests.get(_url("/api/admin/analytics?days=30"),
                         headers={"Authorization": f"Bearer {admin_token}"}, timeout=20)
        assert r.status_code == 200
        data = r.json()
        assert "users" in data and isinstance(data["users"], list)
        assert len(data["users"]) >= 1
        for u in data["users"]:
            missing = self.REQ - set(u.keys())
            assert not missing, f"user row missing fields: {missing}"
            assert u["sign_in"] in ("email", "google")
            assert isinstance(u["gmail_connected"], bool)
        emails = {u["email"] for u in data["users"]}
        assert ADMIN_EMAIL in emails
        admin_row = next(u for u in data["users"] if u["email"] == ADMIN_EMAIL)
        assert admin_row["role"] == "admin"
        assert admin_row["sign_in"] == "email"


# ----- Google login -----
class TestGoogleLogin:
    def test_google_login_invalid_session_401(self):
        r = requests.post(_url("/api/auth/google"),
                          json={"session_id": "x" * 40}, timeout=20)
        assert r.status_code == 401

    def test_google_login_missing_session_422(self):
        # pydantic validation (<8 chars)
        r = requests.post(_url("/api/auth/google"), json={"session_id": "abc"}, timeout=10)
        assert r.status_code == 422

    def test_google_only_user_cannot_password_login(self, mongo):
        # insert a user doc with empty password_hash (Google-only account) directly
        from bson import ObjectId
        from datetime import datetime, timezone
        mongo.users.delete_many({"email": GOOGLE_ONLY_EMAIL})
        doc = {"email": GOOGLE_ONLY_EMAIL, "password_hash": "", "role": "user",
               "created_at": datetime.now(timezone.utc).isoformat()}
        res = mongo.users.insert_one(doc)
        mongo.profiles.insert_one({"user_id": str(res.inserted_id), "display_name": "GoogleOnly",
                                   "description": "", "preferences": "",
                                   "response_style": "balanced", "timezone": "UTC",
                                   "family_id": None,
                                   "created_at": datetime.now(timezone.utc).isoformat(),
                                   "updated_at": datetime.now(timezone.utc).isoformat()})
        r = requests.post(_url("/api/auth/login"),
                          json={"email": GOOGLE_ONLY_EMAIL, "password": "anything1234"}, timeout=15)
        assert r.status_code == 401, f"expected 401 for Google-only password login, got {r.status_code} {r.text}"


# ----- Gmail (unconfigured) -----
class TestGmailUnconfigured:
    def test_status_requires_auth(self):
        r = requests.get(_url("/api/gmail/status"), timeout=10)
        assert r.status_code == 401

    def test_status_configured_false(self, demo_token):
        r = requests.get(_url("/api/gmail/status"),
                         headers={"Authorization": f"Bearer {demo_token}"}, timeout=10)
        assert r.status_code == 200
        body = r.json()
        assert body.get("configured") is False
        assert body.get("connected") is False

    def test_connect_requires_auth(self):
        r = requests.post(_url("/api/gmail/connect"),
                          json={"return_url": "https://example.com"}, timeout=10)
        assert r.status_code == 401

    def test_connect_returns_503_when_unconfigured(self, demo_token):
        r = requests.post(_url("/api/gmail/connect"),
                          headers={"Authorization": f"Bearer {demo_token}"},
                          json={"return_url": "https://alter-assist.preview.emergentagent.com/profile"},
                          timeout=10)
        assert r.status_code == 503

    def test_sync_requires_auth(self):
        r = requests.post(_url("/api/gmail/sync"), timeout=10)
        assert r.status_code == 401

    def test_sync_returns_400_when_not_connected(self, demo_token):
        r = requests.post(_url("/api/gmail/sync"),
                          headers={"Authorization": f"Bearer {demo_token}"}, timeout=10)
        assert r.status_code == 400
        detail = (r.json().get("detail") or "").lower()
        assert "connect" in detail and "gmail" in detail

    def test_disconnect_requires_auth(self):
        r = requests.post(_url("/api/gmail/disconnect"), timeout=10)
        assert r.status_code == 401

    def test_disconnect_ok_even_when_not_connected(self, demo_token):
        r = requests.post(_url("/api/gmail/disconnect"),
                          headers={"Authorization": f"Bearer {demo_token}"}, timeout=10)
        assert r.status_code == 200

    def test_callback_bad_state_returns_400_html(self):
        r = requests.get(_url("/api/gmail/callback?state=bad"), timeout=10, allow_redirects=False)
        assert r.status_code == 400
        assert "text/html" in r.headers.get("content-type", "").lower()

    def test_callback_no_auth_required(self):
        # Public endpoint (no bearer); same as above but confirm not 401
        r = requests.get(_url("/api/gmail/callback"), timeout=10, allow_redirects=False)
        assert r.status_code != 401

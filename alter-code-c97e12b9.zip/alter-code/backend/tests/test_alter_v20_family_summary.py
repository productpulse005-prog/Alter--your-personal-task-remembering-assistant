"""Iteration 20: daily summary, confidential tasks, family plans visibility & privacy.

Run: cd /app/backend && python -m pytest tests/test_alter_v20_family_summary.py -v -n 0 \
       --junitxml=/app/test_reports/pytest/pytest_v20_results.xml
"""
import os
import time
import uuid
from datetime import date, timedelta

import pytest
import requests

BASE_URL = os.environ.get("EXPO_PUBLIC_BACKEND_URL").rstrip("/")
API = f"{BASE_URL}/api"
PWD = "famtest123"
ADMIN = {"email": "admin@example.com", "password": "<REDACTED_PASSWORD>"}


def _h(tok):
    return {"Authorization": f"Bearer {tok}"}


def _register(email, name):
    r = requests.post(f"{API}/auth/register", json={"email": email, "password": PWD, "display_name": name}, timeout=20)
    assert r.status_code == 201, r.text
    return r.json()["token"], r.json()["user"]["id"]


@pytest.fixture(scope="module")
def ctx():
    a_email, b_email = f"v20a_{uuid.uuid4().hex[:8]}@test.app", f"v20b_{uuid.uuid4().hex[:8]}@test.app"
    admin_tok = requests.post(f"{API}/auth/login", json=ADMIN, timeout=20).json()["token"]
    r = requests.post(f"{API}/admin/beta", json={"email": a_email}, headers=_h(admin_tok), timeout=20)
    assert r.status_code == 201, r.text
    a_tok, a_id = _register(a_email, "Alice V20")
    b_tok, b_id = _register(b_email, "Bob V20")
    r = requests.post(f"{API}/family", json={"name": "TEST_FAM_v20"}, headers=_h(a_tok), timeout=15)
    assert r.status_code == 201, r.text
    code = r.json()["family"]["code"]
    r = requests.post(f"{API}/family/join", json={"code": code}, headers=_h(b_tok), timeout=15)
    assert r.status_code == 200, r.text
    today = requests.get(f"{API}/dashboard", headers=_h(a_tok), timeout=15).json()["today"]
    d = date.fromisoformat(today)
    c = {"a_tok": a_tok, "a_id": a_id, "b_tok": b_tok, "b_id": b_id, "today": today,
         "tomorrow": (d + timedelta(days=1)).isoformat(), "yesterday": (d - timedelta(days=1)).isoformat()}
    yield c
    for tok in (a_tok, b_tok):
        requests.delete(f"{API}/account", headers=_h(tok), timeout=15)
    requests.put(f"{API}/admin/beta/{a_email}", json={"status": "revoked"}, headers=_h(admin_tok), timeout=15)


def _mk(tok, **kw):
    r = requests.post(f"{API}/tasks", json=kw, headers=_h(tok), timeout=15)
    assert r.status_code == 201, r.text
    return r.json()


# --- Daily summary: empty state (must run before A has tasks) ---
class TestSummaryEmpty:
    def test_no_tasks_static(self, ctx):
        r = requests.get(f"{API}/summary/today", headers=_h(ctx["a_tok"]), timeout=30)
        assert r.status_code == 200, r.text
        b = r.json()
        assert b["ai"] is False and b["stale"] is False
        assert b["date"] == ctx["today"]
        assert b["counts"] == {"done": 0, "pending": 0, "overdue": 0}
        assert isinstance(b["text"], str) and b["text"]


# --- Confidential flag on tasks ---
class TestConfidential:
    def test_default_false_and_create_true(self, ctx):
        t = _mk(ctx["a_tok"], title="TEST_v20 default flag", due_date=ctx["tomorrow"])
        assert t["confidential"] is False and t["priority"] == "medium"
        t2 = _mk(ctx["a_tok"], title="TEST_v20 secret plan", due_date=ctx["tomorrow"], confidential=True)
        assert t2["confidential"] is True
        lst = requests.get(f"{API}/tasks", headers=_h(ctx["a_tok"]), timeout=15).json()
        got = {x["id"]: x for x in lst}
        assert got[t2["id"]]["confidential"] is True
        # PUT toggles
        r = requests.put(f"{API}/tasks/{t['id']}", json={"confidential": True}, headers=_h(ctx["a_tok"]), timeout=15)
        assert r.status_code == 200 and r.json()["confidential"] is True
        r = requests.put(f"{API}/tasks/{t['id']}", json={"confidential": False}, headers=_h(ctx["a_tok"]), timeout=15)
        assert r.status_code == 200 and r.json()["confidential"] is False
        for x in (t, t2):
            assert requests.delete(f"{API}/tasks/{x['id']}", headers=_h(ctx["a_tok"]), timeout=15).status_code == 200


# --- Family plans visibility ---
class TestFamilyPlans:
    @pytest.fixture(scope="class")
    def btasks(self, ctx):
        tok = ctx["b_tok"]
        ts = {
            "open_today": _mk(tok, title="TEST_v20 bob today walk", due_date=ctx["today"], due_time="18:00"),
            "open_tomorrow": _mk(tok, title="TEST_v20 bob dentist", due_date=ctx["tomorrow"], priority="high"),
            "conf": _mk(tok, title="TEST_v20 bob private gift", due_date=ctx["tomorrow"], confidential=True),
            "done": _mk(tok, title="TEST_v20 bob finished", due_date=ctx["tomorrow"], status="completed"),
            "past": _mk(tok, title="TEST_v20 bob yesterday", due_date=ctx["yesterday"]),
        }
        yield ts
        for t in ts.values():
            requests.delete(f"{API}/tasks/{t['id']}", headers=_h(tok), timeout=15)

    def test_include_family_filters(self, ctx, btasks):
        r = requests.get(f"{API}/tasks", params={"include_family": "true"}, headers=_h(ctx["a_tok"]), timeout=15)
        assert r.status_code == 200
        ids = {t["id"] for t in r.json()}
        assert btasks["open_today"]["id"] in ids
        assert btasks["open_tomorrow"]["id"] in ids
        for k in ("conf", "done", "past"):
            assert btasks[k]["id"] not in ids, f"{k} task leaked to family member"
        fam = next(t for t in r.json() if t["id"] == btasks["open_tomorrow"]["id"])
        assert fam["user_id"] == ctx["b_id"] and fam["owner_name"] == "Bob V20"

    def test_without_include_family(self, ctx, btasks):
        ids = {t["id"] for t in requests.get(f"{API}/tasks", headers=_h(ctx["a_tok"]), timeout=15).json()}
        assert not ids & {t["id"] for t in btasks.values()}

    def test_dashboard_family_upcoming(self, ctx, btasks):
        b = requests.get(f"{API}/dashboard", headers=_h(ctx["a_tok"]), timeout=15).json()
        fu = b["family_upcoming"]
        ids = [t["id"] for t in fu]
        assert len(fu) <= 6
        assert btasks["open_today"]["id"] in ids and btasks["open_tomorrow"]["id"] in ids
        for k in ("conf", "done", "past"):
            assert btasks[k]["id"] not in ids
        # own dashboard 'upcoming' must not include Bob's tasks
        assert not {t["id"] for t in b["upcoming"]} & {t["id"] for t in btasks.values()}

    def test_dashboard_family_upcoming_cap(self, ctx, btasks):
        extra = [_mk(ctx["b_tok"], title=f"TEST_v20 cap item {i} {uuid.uuid4().hex[:4]}", due_date=ctx["tomorrow"]) for i in range(6)]
        try:
            fu = requests.get(f"{API}/dashboard", headers=_h(ctx["a_tok"]), timeout=15).json()["family_upcoming"]
            assert len(fu) == 6
        finally:
            for t in extra:
                requests.delete(f"{API}/tasks/{t['id']}", headers=_h(ctx["b_tok"]), timeout=15)

    def test_family_member_cannot_edit_or_delete(self, ctx, btasks):
        tid = btasks["open_tomorrow"]["id"]
        for body in ({"title": "hacked"}, {"status": "completed"}, {"confidential": True}):
            r = requests.put(f"{API}/tasks/{tid}", json=body, headers=_h(ctx["a_tok"]), timeout=15)
            assert r.status_code in (403, 404), f"PUT {body} -> {r.status_code}"
        r = requests.delete(f"{API}/tasks/{tid}", headers=_h(ctx["a_tok"]), timeout=15)
        assert r.status_code in (403, 404)
        # still intact for owner
        own = {t["id"]: t for t in requests.get(f"{API}/tasks", headers=_h(ctx["b_tok"]), timeout=15).json()}
        assert own[tid]["title"] == "TEST_v20 bob dentist" and own[tid]["status"] == "todo"

    def test_history_not_shared(self, ctx, btasks):
        r = requests.get(f"{API}/tasks/history", params={"date": ctx["today"]}, headers=_h(ctx["a_tok"]), timeout=15)
        assert r.status_code == 200
        ids = {t["id"] for t in r.json()["completed"] + r.json()["not_done"]}
        assert not ids & {t["id"] for t in btasks.values()}


# --- Memories / conversations stay private ---
class TestPrivacy:
    def test_memories_private(self, ctx):
        r = requests.post(f"{API}/memories", json={"content": "TEST_v20 bob private memory", "category": "facts"},
                          headers=_h(ctx["b_tok"]), timeout=15)
        assert r.status_code == 201, r.text
        mid = r.json()["id"]
        mems = requests.get(f"{API}/memories", headers=_h(ctx["a_tok"]), timeout=15).json()
        assert mid not in {m["id"] for m in mems}
        assert requests.delete(f"{API}/memories/{mid}", headers=_h(ctx["a_tok"]), timeout=15).status_code == 404
        requests.delete(f"{API}/memories/{mid}", headers=_h(ctx["b_tok"]), timeout=15)

    def test_conversations_private(self, ctx):
        convs = requests.get(f"{API}/conversations", headers=_h(ctx["a_tok"]), timeout=15).json()
        assert convs == [] or isinstance(convs, list)
        bconvs = requests.get(f"{API}/conversations", headers=_h(ctx["b_tok"]), timeout=15).json()
        a_ids = {c["id"] for c in convs}
        assert not a_ids & {c["id"] for c in bconvs}
        for cid in a_ids:
            assert requests.get(f"{API}/conversations/{cid}/messages", headers=_h(ctx["b_tok"]), timeout=15).status_code == 404


# --- Daily summary: AI, caching, staleness, refresh ---
class TestSummaryAI:
    def test_summary_cache_stale_refresh(self, ctx):
        tok = ctx["a_tok"]
        t1 = _mk(tok, title="TEST_v20 call plumber", due_date=ctx["today"], due_time="15:00")
        made = [t1]
        try:
            t0 = time.time()
            r1 = requests.get(f"{API}/summary/today", headers=_h(tok), timeout=60)
            assert r1.status_code == 200, r1.text
            s1 = r1.json()
            print("summary1", round(time.time() - t0, 1), "s:", s1)
            assert s1["ai"] is True and s1["stale"] is False and s1["text"]
            assert s1["counts"]["pending"] == 1

            t0 = time.time()
            s2 = requests.get(f"{API}/summary/today", headers=_h(tok), timeout=60).json()
            assert s2["text"] == s1["text"] and s2["stale"] is False
            assert time.time() - t0 < 5, "cached call too slow (AI called again?)"

            made.append(_mk(tok, title="TEST_v20 buy milk", due_date=ctx["today"]))
            s3 = requests.get(f"{API}/summary/today", headers=_h(tok), timeout=60).json()
            assert s3["stale"] is True and s3["text"] == s1["text"] and s3["counts"]["pending"] == 2

            s4 = requests.get(f"{API}/summary/today", params={"refresh": "true"}, headers=_h(tok), timeout=60).json()
            print("summary refreshed:", s4)
            assert s4["stale"] is False and s4["ai"] is True

            r = requests.put(f"{API}/tasks/{t1['id']}", json={"status": "completed"}, headers=_h(tok), timeout=15)
            assert r.status_code == 200
            s5 = requests.get(f"{API}/summary/today", headers=_h(tok), timeout=60).json()
            assert s5["stale"] is True and s5["text"] == s4["text"]
            assert s5["counts"]["done"] == 1 and s5["counts"]["pending"] == 1
        finally:
            for t in made:
                requests.delete(f"{API}/tasks/{t['id']}", headers=_h(tok), timeout=15)

import asyncio
"""Alter AI cost controls: beta allowlist, per-user/per-feature daily quotas, global safeguards, usage ledger.

Accounting day = UTC calendar day (resets 00:00 UTC); month = UTC calendar month.
Every AI-powered request: admit() -> run -> settle(). admit() atomically reserves 1 user-facing unit per limited
feature plus the expected internal AI calls against per-user and global counters; settle() converts the reservation
to usage on success or releases it on failure. Stale reservations (crash/restart/abandoned) are released by sweep().
"""
import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Dict, Optional

from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError

FEATURES = ("chat", "voice", "tts", "inbox")
EXPECTED_CALLS = {"chat": 3, "voice": 2, "tts": 1, "inbox": 1}          # planner+reply+validator / whisper+parser / tts / extractor
PROVIDER = {"chat": "gemini", "voice": "openai+gemini", "tts": "openai", "inbox": "gemini"}
RESERVATION_TTL = timedelta(minutes=5)


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except ValueError:
        return default


# Initial defaults (env overridable); admins can override at runtime via /api/admin/usage/settings (audited).
DEFAULTS = {
    "beta_mode": os.environ.get("BETA_MODE", "false").lower() == "true",  # off: every signed-in user
    "ai_disabled": False,                                   # emergency switch for new non-essential AI operations
    "chat_per_user_day": _int("QUOTA_CHAT_PER_DAY", 0),     # 0 = unlimited
    "voice_per_user_day": _int("QUOTA_VOICE_PER_DAY", 0),   # 0 = unlimited
    "tts_per_user_day": _int("QUOTA_TTS_PER_DAY", 20),
    "inbox_per_user_day": _int("QUOTA_INBOX_PER_DAY", 48),
    "ai_calls_per_user_day": _int("QUOTA_AI_CALLS_PER_USER_DAY", 0),  # 0 = unlimited
    "ai_calls_per_day": _int("GLOBAL_AI_CALLS_PER_DAY", 3000),
    "ai_calls_per_month": _int("GLOBAL_AI_CALLS_PER_MONTH", 50000),
    "audio_ops_per_day": _int("GLOBAL_AUDIO_OPS_PER_DAY", 300),   # voice notes + read-aloud, all users
    "spend_alert_day_usd": _float("SPEND_ALERT_DAY_USD", 3.0),
    "spend_alert_month_usd": _float("SPEND_ALERT_MONTH_USD", 50.0),
}
# Estimated cost per INTERNAL AI call (USD). Assumptions, not billing data.
EST_COST_PER_CALL = {"chat": 0.0006, "voice": 0.0035, "tts": 0.0030, "inbox": 0.0008}
EDITABLE = set(DEFAULTS)

MESSAGES = {
    "chat": "You've reached today's Alter chat limit of {limit} messages. Your limit resets at 00:00 UTC. You can still access your saved tasks and memories.",
    "voice": "You've reached today's voice-note limit of {limit}. It resets at 00:00 UTC. You can continue using your saved tasks and other available features.",
    "tts": "You've reached today's read-aloud limit of {limit}. It resets at 00:00 UTC.",
    "inbox": "Today's inbox check limit has been reached. It resets at 00:00 UTC.",
    "user_calls": "You've reached today's Alter AI usage limit. It resets at 00:00 UTC. Your saved tasks and memories remain available.",
    "global": "Alter has temporarily reached its AI usage allowance. Your saved tasks and memories remain available. Please try again later.",
    "disabled": "Alter's AI features are temporarily paused. Your saved tasks and memories remain available. Please try again later.",
    "beta": "Alter is currently available to invited beta users. Please contact the administrator if you believe you should have access.",
    "read_aloud_off": "Read-aloud is turned off. You can turn it on in Profile → Read replies aloud.",
}


class QuotaError(Exception):
    def __init__(self, status: int, code: str, feature: str, limit: Optional[int] = None, used: Optional[int] = None,
                 reset_at: Optional[str] = None, message: str = ""):
        self.status, self.code, self.feature, self.limit, self.used, self.reset_at, self.message = status, code, feature, limit, used, reset_at, message

    def body(self) -> dict:
        retry = "Try again after the reset time." if self.reset_at else "Try again later."
        return {"detail": self.message, "error": {"code": self.code, "feature": self.feature, "limit": self.limit, "used": self.used,
                                                  "reset_at": self.reset_at, "retry": retry}}


def now() -> datetime:
    return datetime.now(timezone.utc)


def day_key(t: Optional[datetime] = None) -> str:
    return (t or now()).strftime("%Y-%m-%d")


def month_key(t: Optional[datetime] = None) -> str:
    return (t or now()).strftime("%Y-%m")


def next_reset(t: Optional[datetime] = None) -> str:
    t = t or now()
    return (datetime(t.year, t.month, t.day, tzinfo=timezone.utc) + timedelta(days=1)).isoformat()


def next_month(t: Optional[datetime] = None) -> str:
    t = t or now()
    return datetime(t.year + (t.month == 12), t.month % 12 + 1, 1, tzinfo=timezone.utc).isoformat()


class Usage:
    def __init__(self, db):
        self.on_admit = None  # optional async callback after a successful reservation
        self.db = db

    async def ensure_indexes(self):
        await self.db.usage_reservations.create_index("expires_at")
        await self.db.usage_reservations.create_index([("user_id", 1), ("day", 1)])
        await self.db.usage_events.create_index([("day", 1), ("feature", 1)])
        await self.db.usage_events.create_index([("user_id", 1), ("day", 1)])
        await self.db.config_audit.create_index("at")
        await self.db.beta_invites.create_index("email", unique=True)
        # usage_counters uses deterministic _id "<scope>|<metric>|<period>" => unique per user/feature/period by construction

    # ---- settings -----------------------------------------------------------------
    async def settings(self) -> dict:
        doc = await self.db.app_settings.find_one({"_id": "usage"}) or {}
        return {**DEFAULTS, **{k: v for k, v in doc.items() if k in EDITABLE}}

    async def update_settings(self, admin_email: str, changes: dict) -> dict:
        current = await self.settings()
        clean = {}
        for k, v in changes.items():
            if k not in EDITABLE:
                continue
            want = type(DEFAULTS[k])
            if want is bool:
                clean[k] = bool(v)
            elif want is int:
                clean[k] = max(0, int(v))
            else:
                clean[k] = max(0.0, float(v))
        if clean:
            await self.db.app_settings.update_one({"_id": "usage"}, {"$set": clean}, upsert=True)
            await self.db.config_audit.insert_one({"at": now().isoformat(), "by": admin_email,
                                                   "changes": {k: {"from": current.get(k), "to": v} for k, v in clean.items()}})
        return await self.settings()

    # ---- beta allowlist ---------------------------------------------------------
    async def beta_allowed(self, user) -> bool:
        return True  # invite-only beta is retired: every signed-in user can use every feature

    # ---- atomic counters ----------------------------------------------------------
    async def _reserve(self, cid: str, n: int, limit: int) -> Optional[int]:
        """Atomically add n to `reserved` only if used+reserved+n <= limit. Returns new total or None."""
        await self.db.usage_counters.update_one({"_id": cid}, {"$setOnInsert": {"used": 0, "reserved": 0, "failed": 0}}, upsert=True)
        doc = await self.db.usage_counters.find_one_and_update(
            {"_id": cid, "$expr": {"$lte": [{"$add": ["$used", "$reserved", n]}, limit]}},
            {"$inc": {"reserved": n}}, return_document=ReturnDocument.AFTER)
        return None if doc is None else doc["used"] + doc["reserved"]

    async def _count(self, cid: str) -> int:
        d = await self.db.usage_counters.find_one({"_id": cid}) or {}
        return d.get("used", 0) + d.get("reserved", 0)

    async def admit(self, user, feature: str, idem_key: Optional[str] = None, billing: str = "universal") -> dict:
        """billing="byok": the user's own Gemini key pays, so the developer's global AI allowance isn't consumed.
        There are no per-user limits; usage is only recorded."""
        s = await self.settings()
        if not await self.beta_allowed(user):
            await self._event(user.id, feature, "blocked_beta", 0)
            raise QuotaError(403, "beta_access_required", feature, message=MESSAGES["beta"])
        if s["ai_disabled"]:
            await self._event(user.id, feature, "blocked_disabled", 0)
            raise QuotaError(503, "ai_temporarily_disabled", feature, message=MESSAGES["disabled"])
        rid = f"{user.id}|{feature}|{idem_key}" if idem_key else f"{user.id}|{feature}|{uuid.uuid4().hex}"
        t, d, m = now(), day_key(), month_key()
        calls = EXPECTED_CALLS[feature]
        try:
            await self.db.usage_reservations.insert_one({"_id": rid, "user_id": user.id, "feature": feature, "day": d, "month": m,
                                                         "calls": calls, "counters": [], "status": "reserved", "created_at": t.isoformat(),
                                                         "expires_at": t + RESERVATION_TTL})
        except DuplicateKeyError:
            prev = await self.db.usage_reservations.find_one({"_id": rid})
            await self._event(user.id, feature, "duplicate", 0)
            raise QuotaError(409, "duplicate_request", feature,
                             message="This request is already being processed." if prev and prev["status"] == "reserved"
                             else "This request was already handled.")
        plan = []
        # No per-user feature limits (product decision): the per-user counter only records usage for the admin dashboard.
        plan.append((f"u:{user.id}|{feature}|{d}", 1, 10 ** 9, 429, f"{feature}_limit_reached", MESSAGES[feature], next_reset(t)))
        if billing != "byok":
            plan += [
                (f"g|ai_calls|{d}", calls, s["ai_calls_per_day"], 503, "global_daily_allowance_reached", MESSAGES["global"], next_reset(t)),
                (f"g|ai_calls|{m}", calls, s["ai_calls_per_month"], 503, "global_monthly_allowance_reached", MESSAGES["global"], next_month(t)),
            ]
        if feature in ("voice", "tts") and billing != "byok":
            plan.append((f"g|audio_ops|{d}", 1, s["audio_ops_per_day"], 503, "global_audio_allowance_reached", MESSAGES["global"], next_reset(t)))
        taken = []
        for cid, n, limit, status, code, msg, reset in plan:
            if await self._reserve(cid, n, limit) is None:
                for tc, tn in taken:  # roll back partial reservation
                    await self.db.usage_counters.update_one({"_id": tc}, {"$inc": {"reserved": -tn}})
                await self.db.usage_reservations.update_one({"_id": rid}, {"$set": {"status": "rejected", "code": code}})
                await self._event(user.id, feature, "rate_limited", 0, code=code)
                if cid.startswith("g|") and self.on_admit:
                    asyncio.create_task(self.on_admit())  # budget already full -> make sure the admin was alerted
                raise QuotaError(status, code, feature, limit, await self._count(cid), reset, msg.format(limit=limit))
            taken.append((cid, n))
        await self.db.usage_reservations.update_one({"_id": rid}, {"$set": {"counters": [list(x) for x in taken]}})
        if billing != "byok" and self.on_admit:
            asyncio.create_task(self.on_admit())  # e.g. daily budget alert; runs in the background
        return {"id": rid, "user_id": user.id, "feature": feature, "started": t}

    async def settle(self, res: dict, ok: bool, ai_calls: int, breakdown: Optional[Dict[str, int]] = None, est_tokens: int = 0):
        """Success: reserved->used (internal AI call counters reconciled to actual). Failure: release user-facing units."""
        doc = await self.db.usage_reservations.find_one_and_update({"_id": res["id"], "status": "reserved"},
                                                                    {"$set": {"status": "completed" if ok else "failed"}})
        if not doc:
            return  # already settled or swept
        for cid, n in doc["counters"]:
            is_calls = "|ai_calls|" in cid
            if ok:
                used = ai_calls if is_calls else n
                await self.db.usage_counters.update_one({"_id": cid}, {"$inc": {"reserved": -n, "used": used}})
            else:  # failed: user-facing quota released; AI calls that were actually made still count toward safeguards
                inc = {"reserved": -n, "failed": 1}
                if is_calls and ai_calls:
                    inc["used"] = ai_calls
                await self.db.usage_counters.update_one({"_id": cid}, {"$inc": inc})
        ms = int((now() - res["started"]).total_seconds() * 1000)
        await self._event(res["user_id"], res["feature"], "success" if ok else "failed", ai_calls, breakdown, est_tokens, ms)

    async def sweep(self):
        """Release reservations abandoned by crashes/restarts/timeouts."""
        n = 0
        while True:
            doc = await self.db.usage_reservations.find_one_and_update(
                {"status": "reserved", "expires_at": {"$lt": now()}}, {"$set": {"status": "expired"}})
            if not doc:
                return n
            for cid, k in doc["counters"]:
                await self.db.usage_counters.update_one({"_id": cid}, {"$inc": {"reserved": -k}})
            await self._event(doc["user_id"], doc["feature"], "expired", 0)
            n += 1

    async def _event(self, user_id, feature, outcome, ai_calls, breakdown=None, est_tokens=0, latency_ms=None, code=None):
        # Minimal metadata only — never message text, email content, tokens or secrets.
        await self.db.usage_events.insert_one({
            "user_id": user_id, "feature": feature, "provider": PROVIDER.get(feature), "outcome": outcome, "code": code,
            "ai_calls": ai_calls, "breakdown": breakdown or {}, "est_tokens": est_tokens,
            "est_cost_usd": round(ai_calls * EST_COST_PER_CALL.get(feature, 0.001), 5), "latency_ms": latency_ms,
            "day": day_key(), "month": month_key(), "at": now().isoformat()})

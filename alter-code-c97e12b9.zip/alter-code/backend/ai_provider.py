"""Alter AI provider routing: per-user Gemini keys (BYOK) vs the developer's Emergent Universal Key.

Billing rules (enforced here, the only place AI calls are created):
- A user with a saved Gemini key ALWAYS uses that key ("byok"). Errors are surfaced, never retried on another key.
- Everyone else uses the app owner's GEMINI_API_KEY ("app"). If it's missing/invalid/out of quota the request fails
  with a clear message; there is no fallback.
- The Emergent Universal Key is used only if GEMINI_API_KEY is unset AND UNIVERSAL_KEY_ACCESS allows it
  ("none" by default; "admin" = developer account only; "beta" = everyone).
- Every AI call is written to `ai_billing` with the route that paid for it (byok / universal).
"""
import asyncio
import json
import logging
import os
import re
import time
from datetime import datetime, timezone
from typing import Optional

from cryptography.fernet import Fernet, InvalidToken
from emergentintegrations.llm.chat import LlmChat, UserMessage
from emergentintegrations.llm.openai import OpenAISpeechToText
from google import genai
from google.genai import errors as gerrors
from google.genai import types

from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path(__file__).parent / ".env")
log = logging.getLogger("alter.ai")

UNIVERSAL_KEY = os.environ["EMERGENT_LLM_KEY"]
UNIVERSAL_PROVIDER = os.environ.get("AI_PROVIDER", "gemini")
UNIVERSAL_MODEL = os.environ.get("AI_MODEL", "gemini-3-flash-preview")
BYOK_MODEL = os.environ.get("GEMINI_BYOK_MODEL", "gemini-3.5-flash")
VALIDATE_MODEL = os.environ.get("GEMINI_VALIDATE_MODEL", "gemini-3.5-flash-lite")
ATTEMPT_TIMEOUT = float(os.environ.get("GEMINI_ATTEMPT_TIMEOUT_S", "25"))
UNIVERSAL_ACCESS = os.environ.get("UNIVERSAL_KEY_ACCESS", "none").lower()  # none (default) | admin | beta
APP_KEY = os.environ.get("GEMINI_API_KEY", "").strip()  # the app owner's Gemini key, used for all end users without their own key
APP_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.5-flash")
# Free-tier quotas are per model: when one is exhausted, the next one answers (same key, so no extra cost).
# Light, fast models first (plenty for tasks/groceries/alarms); bigger ones only as a backup.
FALLBACK_MODELS = [m.strip() for m in os.environ.get(
    "GEMINI_FALLBACK_MODELS", "gemini-3.5-flash-lite,gemini-3.1-flash-lite-preview,gemini-3.5-flash,gemini-3-flash-preview,gemini-3.8-flash"
).split(",") if m.strip()]
QUOTA_COOLDOWN_S = int(os.environ.get("GEMINI_QUOTA_COOLDOWN_S", "300"))
_cooldown: dict = {}  # (api_key, model) -> unix time until which the model is skipped
_ENC = os.environ.get("BYOK_ENCRYPTION_KEY", "")
_fernet = Fernet(_ENC.encode()) if _ENC else None
KEY_RE = re.compile(r"^[A-Za-z0-9_\-.]{20,200}$")

LANGUAGES = {"auto": "Auto-detect", "en": "English", "hi": "Hindi", "bn": "Bengali", "ta": "Tamil", "te": "Telugu",
             "mr": "Marathi", "gu": "Gujarati", "kn": "Kannada", "ml": "Malayalam", "pa": "Punjabi", "ur": "Urdu"}

MSG = {
    "byok_required": "Alter's AI needs your own Gemini API key. Add it in Profile → AI key (Gemini).",
    "byok_invalid": "Google rejected your Gemini API key (invalid, expired or restricted). Update it in Profile → AI key.",
    "byok_quota": "Your Gemini API key has hit its quota or rate limit. Wait a bit, or check billing/limits in Google AI Studio.",
    "byok_model": "The Gemini model Alter uses isn't available for your key/project. Check that the Gemini API is enabled.",
    "byok_unavailable": "Google's Gemini service didn't respond. Please try again in a moment.",
    "byok_bad_request": "Gemini couldn't process this request. Please try again or rephrase.",
    "byok_blocked": "Gemini declined to answer this request (safety filter). Try rephrasing.",
    "app_missing": "Alter's AI isn't set up on the server yet (no Gemini key configured). Please tell the app's administrator.",
    "app_invalid": "Alter's AI service key was rejected by Google. The administrator needs to update it. Please try again later.",
    "app_quota": "Alter's AI has reached its usage limit with Google for now. Please try again later.",
    "app_model": "Alter's AI model isn't available right now. The administrator needs to check the configuration.",
    "app_unavailable": "Google's Gemini service didn't respond. Please try again in a moment.",
    "app_bad_request": "Gemini couldn't process this request. Please try again or rephrase.",
    "app_blocked": "Gemini declined to answer this request (safety filter). Try rephrasing.",
    "encryption_missing": "Saving personal AI keys isn't configured on this server yet.",
}


class AIError(Exception):
    def __init__(self, status: int, code: str, message: Optional[str] = None):
        super().__init__(code)
        self.status, self.code, self.message = status, code, message or MSG.get(code, code)

    def body(self) -> dict:
        return {"detail": self.message, "code": self.code, "ai_error": True}


def encrypt(key: str) -> str:
    if not _fernet:
        raise AIError(503, "encryption_missing")
    return _fernet.encrypt(key.encode()).decode()


def decrypt(token: str) -> str:
    if not _fernet:
        raise AIError(503, "encryption_missing")
    try:
        return _fernet.decrypt(token.encode()).decode()
    except InvalidToken:
        raise AIError(401, "byok_invalid", "Your saved Gemini key can't be read any more. Please add it again in Profile → AI key.")


def mask(key: str) -> str:
    return f"{key[:4]}…{key[-4:]}" if len(key) > 10 else "••••"


def _map_google_error(e: Exception) -> AIError:
    code = getattr(e, "code", None)
    text = str(getattr(e, "message", "") or e).upper()
    if "API_KEY_INVALID" in text or "API KEY NOT VALID" in text or code in (401, 403) or "PERMISSION_DENIED" in text:
        return AIError(401, "byok_invalid")
    if code == 429 or "RESOURCE_EXHAUSTED" in text:
        return AIError(429, "byok_quota")
    if code == 404 or "NOT_FOUND" in text:
        return AIError(502, "byok_model")
    if code == 400:  # malformed request, not transient: don't retry
        return AIError(502, "byok_bad_request")
    return AIError(502, "byok_unavailable")


class Route:
    """Who pays for this request and which model answers it."""

    def __init__(self, db, user_id: str, kind: str, model: str, api_key: Optional[str] = None):
        self.db, self.user_id, self.kind, self.model, self._key = db, user_id, kind, model, api_key

    def chat(self, session: str, system: str):
        return _UniversalChat(self, session, system) if self.kind == "universal" else _ByokChat(self, session, system)

    def _err(self, e: AIError) -> AIError:
        """Same failure, worded for whose key it is (the user's own vs the app's)."""
        if self.kind == "app" and e.code.startswith("byok_"):
            code = "app_" + e.code[5:]
            return AIError(e.status if e.status != 401 else 503, code)
        return e

    async def record(self, feature: str, ok: bool, started: float, error: Optional[str] = None):
        await self.db.ai_billing.insert_one({"user_id": self.user_id, "route": self.kind, "model": self.model,
                                             "feature": feature, "ok": ok, "error": error,
                                             "ms": int((time.time() - started) * 1000),
                                             "at": datetime.now(timezone.utc).isoformat()})
        log.info("ai_call route=%s model=%s feature=%s ok=%s user=%s", self.kind, self.model, feature, ok, self.user_id)

    async def generate(self, system: Optional[str], parts: list, feature: str, json_out: bool = False, max_tokens: Optional[int] = None) -> str:
        """BYOK only: one Gemini call with bounded retries (transient errors only, never auth/quota)."""
        started = time.time()
        cfg = types.GenerateContentConfig(system_instruction=system, max_output_tokens=max_tokens,
                                          response_mime_type="application/json" if json_out else None)
        last: Optional[AIError] = None
        now = time.time()
        light_first = [*FALLBACK_MODELS, self.model]
        # chat answers + their fact-check need a bit more reasoning: start one step up, still cheap
        smart_first = [m for m in light_first if "lite" not in m] + [m for m in light_first if "lite" in m]
        order = (smart_first if feature in ("reply", "check") else light_first) if self.kind == "app" else [self.model, *FALLBACK_MODELS]
        chain = [m for m in dict.fromkeys(order) if _cooldown.get((self._key, m), 0) <= now]
        for model in chain or [self.model]:
            self.model = model
            for attempt in range(2):
                try:
                    async with genai.Client(api_key=self._key).aio as c:
                        r = await asyncio.wait_for(c.models.generate_content(model=model, contents=parts, config=cfg), ATTEMPT_TIMEOUT)
                    text = r.text or ""
                    if not text.strip() and getattr(r, "prompt_feedback", None) and getattr(r.prompt_feedback, "block_reason", None):
                        raise AIError(422, "byok_blocked")
                    await self.record(feature, True, started)
                    return text
                except AIError as e:
                    last = e
                    break
                except gerrors.APIError as e:
                    last = _map_google_error(e)
                    if last.code != "byok_unavailable":
                        break
                except (asyncio.TimeoutError, OSError) as e:
                    log.warning("gemini transient error: %s", type(e).__name__)
                    last = AIError(502, "byok_unavailable")
                    break  # slow model: move straight on to the next one instead of waiting again
                await asyncio.sleep(0.6 * (attempt + 1) ** 2)
            # this model's free quota is used up / model unavailable: rest it and try the next free model
            if last.code in ("byok_quota", "byok_model", "byok_unavailable"):
                _cooldown[(self._key, model)] = time.time() + (QUOTA_COOLDOWN_S if last.code == "byok_quota" else 60)
                log.warning("gemini model %s failed (%s), switching to next model", model, last.code)
                continue
            break
        await self.record(feature, False, started, self._err(last).code if last else "unknown")
        if last and last.code == "byok_invalid" and self.kind == "app":
            log.error("APP GEMINI KEY REJECTED by Google (check GEMINI_API_KEY)")
        if last and last.code == "byok_invalid" and self.kind == "byok":
            await self.db.ai_credentials.update_one({"user_id": self.user_id}, {"$set": {
                "status": "invalid", "last_error": last.message, "checked_at": datetime.now(timezone.utc).isoformat()}})
        raise self._err(last or AIError(502, "byok_unavailable"))

    async def transcribe(self, path: str, suffix: str, language: str = "auto") -> str:
        hint = "" if language == "auto" else f" The speaker's preferred language is {LANGUAGES.get(language, language)}, but transcribe whatever is actually spoken."
        if self.kind != "universal":  # Gemini audio understanding on the user's or the app's key
            mime = {".m4a": "audio/mp4", ".mp4": "audio/mp4", ".webm": "audio/webm", ".wav": "audio/wav",
                    ".mp3": "audio/mp3", ".mpeg": "audio/mpeg", ".mpga": "audio/mpeg"}.get(suffix, "audio/mp4")
            with open(path, "rb") as f:
                data = f.read()
            prompt = ("Transcribe exactly what is spoken in this audio. Detect the language(s). Keep code-switching "
                      "(e.g. Hindi-English / Hinglish) exactly as spoken; write Hindi words in the script the speaker would "
                      "naturally use and do NOT translate. If there is no intelligible speech, return an empty transcript." + hint +
                      ' Return only JSON: {"transcript": "...", "language": "<ISO code or mixed>"}')
            raw = await self.generate(None, [types.Part.from_text(text=prompt), types.Part.from_bytes(data=data, mime_type=mime)],
                                      "transcribe", json_out=True)
            try:
                return str(json.loads(raw).get("transcript", "")).strip()
            except (ValueError, AttributeError):
                return raw.strip()
        started = time.time()
        try:
            with open(path, "rb") as f:
                kw = {"language": language} if language != "auto" else {}
                resp = await OpenAISpeechToText(api_key=UNIVERSAL_KEY).transcribe(
                    file=f, model="whisper-1", response_format="verbose_json", temperature=0.0, **kw)
        except Exception:
            await self.record("transcribe", False, started, "whisper_failed")
            raise
        await self.record("transcribe", True, started)
        segs = getattr(resp, "segments", None) or []
        g = lambda s, n, d: s.get(n, d) if isinstance(s, dict) else getattr(s, n, d)  # noqa: E731
        # only real silence is dropped; low confidence is normal for non-English / accented speech
        if segs and all(g(s, "no_speech_prob", 0.0) > 0.8 and g(s, "avg_logprob", 0.0) < -1.0 for s in segs):
            return ""
        return trim_repetition((resp.text or "").strip())


def trim_repetition(text: str) -> str:
    """Whisper sometimes loops ("ke list ke list ke list…") on code-switched audio; cut at the start of the loop."""
    words = text.split()
    for n in range(1, 6):
        for i in range(len(words) - n * 4):
            chunk = words[i:i + n]
            if all(words[i + k * n:i + (k + 1) * n] == chunk for k in range(1, 4)):
                return " ".join(words[:i + n])
    return text


class _ByokChat:
    def __init__(self, route: Route, session: str, system: str):
        self.route, self.feature, self.system = route, session.split("-")[0], system

    async def send_message(self, msg: UserMessage) -> str:
        return await self.route.generate(self.system, [types.Part.from_text(text=msg.text)], self.feature)


class _UniversalChat:
    def __init__(self, route: Route, session: str, system: str):
        self.route, self.feature = route, session.split("-")[0]
        self.chat = LlmChat(api_key=UNIVERSAL_KEY, session_id=session, system_message=system).with_model(UNIVERSAL_PROVIDER, route.model)

    async def send_message(self, msg: UserMessage) -> str:
        started = time.time()
        try:
            out = await self.chat.send_message(msg)
        except Exception as e:
            await self.route.record(self.feature, False, started, type(e).__name__)
            raise
        await self.route.record(self.feature, True, started)
        return out


def universal_allowed(user) -> bool:
    return UNIVERSAL_ACCESS == "beta" or (UNIVERSAL_ACCESS == "admin" and user.role == "admin")


async def resolve(db, user) -> Route:
    """Pick the billing route for this user's request. Never falls back from BYOK to the Universal Key."""
    doc = await db.ai_credentials.find_one({"user_id": user.id})
    if doc and doc.get("enc"):
        if doc.get("status") == "invalid":
            raise AIError(401, "byok_invalid")
        return Route(db, user.id, "byok", BYOK_MODEL, decrypt(doc["enc"]))
    if APP_KEY:
        return Route(db, user.id, "app", APP_MODEL, APP_KEY)
    if universal_allowed(user):
        return Route(db, user.id, "universal", UNIVERSAL_MODEL)
    raise AIError(503, "app_missing")


async def validate_key(db, user_id: str, key: str) -> None:
    """Cheap probe with the user's key. Raises AIError on failure."""
    r = Route(db, user_id, "byok", VALIDATE_MODEL, key)
    await r.generate(None, [types.Part.from_text(text="Reply with exactly: OK")], "validate", max_tokens=5)

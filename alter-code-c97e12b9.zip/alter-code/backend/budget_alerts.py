"""Daily AI budget alert: one email to the admin when today's app-wide AI calls reach BUDGET_ALERT_PCT of the budget.
Uses Emergent's managed email (Resend) integration. Recipient comes from server config only (ADMIN_EMAIL)."""
import ipaddress
import logging
import os
import re
from datetime import datetime, timedelta, timezone
from html import escape
from html.parser import HTMLParser
from urllib.parse import urlparse

import httpx
from bson import ObjectId
from dotenv import load_dotenv
from pymongo.errors import DuplicateKeyError

load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))
log = logging.getLogger("alter.budget")

EMAIL_BASE_URL = "https://integrations.emergentagent.com"
EMAIL_KEY = os.environ.get("EMERGENT_EMAIL_KEY", "")
EMAIL_FROM_NAME = os.environ.get("EMAIL_FROM_NAME", "Alter")
ALERT_TO = os.environ.get("BUDGET_ALERT_EMAIL") or os.environ.get("ADMIN_EMAIL", "")
ALERT_PCT = int(os.environ.get("BUDGET_ALERT_PCT", "90"))

# ---- guardrail gate (from the integration playbook; do not weaken) ----
_SHORTENERS = ("bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "goo.gl", "rebrand.ly")
_CRED_ASK = ("reply with your password", "reply with the code", "send your password", "cvv",
             "send us your password", "enter your password below", "confirm your card number",
             "your full card number", "seed phrase", "recovery phrase", "verify your card",
             "social security number", "confirm your bank details")
_HOSTISH = re.compile(r"\b(?:https?://)?((?:[a-z0-9-]+\.)+[a-z]{2,})", re.I)


def _host_ok(host: str) -> bool:
    if not host or "xn--" in host:
        return False
    try:
        ipaddress.ip_address(host)
        return False
    except ValueError:
        pass
    return not any(host == s or host.endswith("." + s) for s in _SHORTENERS)


def _same_site(shown: str, real: str) -> bool:
    return shown == real or real.endswith("." + shown) or shown.endswith("." + real)


class _EmailScan(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags, self.urls, self.anchors = set(), [], []
        self._href, self._text = None, []

    def handle_starttag(self, tag, attrs):
        self.tags.add(tag.lower())
        self.urls += [v for k, v in attrs if k.lower() in ("href", "src") and v]
        if tag.lower() == "a":
            self._href = dict((k.lower(), v) for k, v in attrs).get("href")
            self._text = []

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            self.anchors.append((self._href, "".join(self._text)))
            self._href, self._text = None, []


def _assert_safe_email(subject: str, html: str) -> None:
    scan = _EmailScan()
    scan.feed(html)
    if scan.tags & {"form", "input", "textarea", "select"}:
        raise ValueError("No forms or input fields in email (G2)")
    body = f"{subject}\n{html}".lower()
    for p in _CRED_ASK:
        if p in body:
            raise ValueError(f"Email asks the recipient for credentials: {p!r} (G2)")
    for url in scan.urls:
        low = url.strip().lower()
        if low.startswith(("mailto:", "tel:", "cid:", "#")):
            continue
        if not low.startswith("https://"):
            raise ValueError(f"Email links/assets must be absolute https: {url!r} (G3)")
        host = urlparse(low).hostname or ""
        if not _host_ok(host) or urlparse(low).username is not None:
            raise ValueError(f"Shortened, numeric-host or credential-bearing URL: {url!r} (G3)")
    for href, text in scan.anchors:
        real = urlparse(href.strip().lower()).hostname or ""
        if not real:
            continue
        for m in _HOSTISH.finditer(text):
            if not _same_site(m.group(1).lower(), real):
                raise ValueError(f"Anchor text {m.group(1)!r} ≠ real link host {real!r} (G3)")


async def send_email(*, to: str, subject: str, html: str) -> str:
    """Internal only: recipient/subject/body are server-side (never caller input)."""
    _assert_safe_email(subject, html)
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(f"{EMAIL_BASE_URL}/api/v1/email/send", headers={"X-Email-Key": EMAIL_KEY},
                                 json={"to": [to], "subject": subject, "html": html, "from_name": EMAIL_FROM_NAME})
    if resp.status_code >= 400:
        try:
            body = resp.json()
        except ValueError:
            body = {}
        raise RuntimeError(f"email send failed {resp.status_code} {body.get('code', '')}: {body.get('message', '')}")
    return resp.json().get("id", "")


FEEDBACK_TO = os.environ.get("FEEDBACK_EMAIL") or os.environ.get("ADMIN_EMAIL", "")
AREA_LABELS = {"alarms": "Alarms & reminders", "voice": "Voice", "tasks": "Tasks", "groceries": "Groceries",
               "chat": "Chat", "sign_in": "Sign-in", "other": "Other"}


def _feedback_template(doc: dict, include_message: bool = True) -> tuple[str, str]:
    e = escape
    kind = {"bug": "Bug report", "idea": "Idea", "other": "Feedback"}[doc["kind"]]
    area = AREA_LABELS.get(doc.get("area") or "", "")
    subject = f"{EMAIL_FROM_NAME}: {kind}" + (f" · {area}" if area else "") + f" from {doc.get('name') or 'a tester'}"
    msg = e(doc["message"]).replace("\n", "<br>") if include_message else \
        "<em>The message was not included in this email by the safety check. Open it in the app's Feedback inbox.</em>"
    rows = [("From", f"{doc.get('name', '')} ({doc.get('email', '')})"), ("Type", kind), ("Area", area or "-"),
            ("Screen", doc.get("screen") or "-"), ("Device", doc.get("platform") or "-"),
            ("App version", doc.get("app_version") or "-"), ("Sent", doc["created_at"][:19].replace("T", " ") + " UTC")]
    table = "".join(f'<tr><td style="padding:2px 12px 2px 0;color:#888">{e(k)}</td><td>{e(v)}</td></tr>' for k, v in rows)
    html = ('<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td style="padding:24px;'
            'font-family:Arial,sans-serif;color:#3b2f2a">'
            f'<h2 style="margin:0 0 12px">{e(kind)}</h2>'
            f'<p style="background:#FFF8EE;padding:12px;border-radius:8px">{msg}</p>'
            f'<table role="presentation" cellpadding="0" cellspacing="0" style="font-size:14px">{table}</table>'
            '<p>Mark it seen or resolved in the app: Profile, Admin analytics, Tester feedback inbox.</p>'
            f'<p style="font-size:12px;color:#888">Sent by {e(EMAIL_FROM_NAME)} to the app administrator.</p>'
            '</td></tr></table>')
    return subject, html


async def send_feedback_email(db, feedback_id: str, doc: dict) -> None:
    """Email every tester report to the admin. Never raises (runs in the background)."""
    if not (EMAIL_KEY and FEEDBACK_TO):
        return
    try:
        try:
            subject, html = _feedback_template(doc)
            mid = await send_email(to=FEEDBACK_TO, subject=subject, html=html)
        except ValueError:  # user text tripped the email safety gate: send without it
            subject, html = _feedback_template(doc, include_message=False)
            mid = await send_email(to=FEEDBACK_TO, subject=subject, html=html)
        await db.feedback.update_one({"_id": ObjectId(feedback_id)}, {"$set": {"emailed": True, "email_id": mid}})
        log.info("feedback email sent (%s)", feedback_id)
    except Exception as e:
        await db.feedback.update_one({"_id": ObjectId(feedback_id)}, {"$set": {"emailed": False, "email_error": str(e)[:300]}})
        log.warning("feedback email failed: %s", e)


def _template(used: int, limit: int, pct: int, day: str, month_used: int, month_limit: int) -> tuple[str, str]:
    subject = f"{EMAIL_FROM_NAME}: AI usage at {pct}% of today's budget"
    e = escape
    html = (
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td style="padding:24px;'
        'font-family:Arial,sans-serif;color:#3b2f2a">'
        f'<h2 style="margin:0 0 12px">AI budget alert</h2>'
        f'<p>Today ({e(day)} UTC) Alter has used <strong>{used} of {limit}</strong> AI calls '
        f'(<strong>{pct}%</strong> of the daily budget).</p>'
        f'<p>This month: {month_used} of {month_limit} calls.</p>'
        '<p>When the daily budget is reached, users see a "try again later" message until midnight UTC. '
        'You can raise or lower the limits in the app: Profile, Admin analytics, AI usage &amp; limits.</p>'
        '<p>Calls made with a user\'s own Gemini key are not counted here.</p>'
        f'<p style="font-size:12px;color:#888">Sent by {e(EMAIL_FROM_NAME)} to the app administrator. '
        'You get at most one alert per day. We never ask for passwords or keys by email.</p>'
        '</td></tr></table>')
    return subject, html


async def check_daily_budget(db, usage) -> None:
    """Call after AI usage is reserved. Sends at most one alert per UTC day (atomic claim in Mongo)."""
    if not (EMAIL_KEY and ALERT_TO):
        return
    try:
        s = await usage.settings()
        now = datetime.now(timezone.utc)
        day, month = now.strftime("%Y-%m-%d"), now.strftime("%Y-%m")
        limit = int(s["ai_calls_per_day"])
        used = await usage._count(f"g|ai_calls|{day}")
        if limit <= 0 or used * 100 < ALERT_PCT * limit:
            return
        aid = f"budget|{day}"
        prev = await db.budget_alerts.find_one({"_id": aid})
        if prev and (prev["status"] == "sent" or prev.get("retry_after", "") > now.isoformat()):
            return
        try:
            if not prev:
                await db.budget_alerts.insert_one({"_id": aid, "status": "sending", "at": now.isoformat()})
            elif not (await db.budget_alerts.update_one({"_id": aid, "status": "failed"}, {"$set": {"status": "sending"}})).modified_count:
                return
        except DuplicateKeyError:
            return  # another request is sending it
        subject, html = _template(used, limit, min(100, used * 100 // limit), day,
                                  await usage._count(f"g|ai_calls|{month}"), int(s["ai_calls_per_month"]))
        try:
            mid = await send_email(to=ALERT_TO, subject=subject, html=html)
            await db.budget_alerts.update_one({"_id": aid}, {"$set": {"status": "sent", "email_id": mid, "used": used,
                                                                        "limit": limit, "sent_at": now.isoformat()}})
            log.info("budget alert sent (%s/%s calls)", used, limit)
        except Exception as e:
            await db.budget_alerts.update_one({"_id": aid}, {"$set": {"status": "failed", "error": str(e)[:300],
                                                                        "retry_after": (now + timedelta(minutes=30)).isoformat()}})
            log.warning("budget alert email failed: %s", e)
    except Exception as e:  # never break an AI request because of the alert
        log.warning("budget check failed: %s", type(e).__name__)

# Alter — PRD

## Original problem statement
Build "Alter", a personal AI alter ego app: persistent AI chat that can remember/forget information and create/manage tasks via real DB operations (never false success claims), a user-controlled Memory section (categories, search, edit/delete, AI extraction with approval for sensitive info), task manager (title, description, due date/time, priority, status, search/filter), profile (name, description, preferences, response style, timezone, sign out), dashboard (greeting, quick chat, active/upcoming tasks, recent memories, quick actions), auth and strict per-user data isolation. (Original brief asked for Next.js/Supabase/Vercel; user chose the built-in backend.)

## User choices
- Backend: built-in FastAPI + MongoDB + JWT auth (not Supabase/Vercel)
- AI: Gemini 3 Flash (`gemini-3-flash-preview`) via Emergent LLM key; provider/model configurable via `AI_PROVIDER` / `AI_MODEL` env
- Memory: auto-save non-sensitive confirmed facts; sensitive or inferred facts need approval (Save/Dismiss in chat)
- Design: editorial light (Fraunces + DM Sans, sage/paper palette)

## Architecture
- Expo Router app: `auth`, `(tabs)/home|chats|memory|tasks`, `chat/[id]`, `profile`
- FastAPI `/api`: auth, profile, memories, tasks, dashboard, conversations, `POST /chat` (SSE), `POST /messages/{id}/actions/{idx}`, `DELETE /account`
- Chat pipeline: planner LLM call → validated server-side operations (memory/task) → streamed responder given the real operation results
- All queries filter by `user_id`; secret-like content is blocked from memory; login lockout after 5 failures

## Implemented (2026-06)
- All features above; testing agent: backend 19/19 pass incl. cross-account isolation, frontend flows pass

## Iteration 2 (2026-06)
- Voice capture (expo-audio → /api/voice, Whisper whisper-1) → AI creates tasks (auto priority urgent/high/medium/low, due today by default, family assignee) + grocery items
- Shared grocery list (family scope, dedupe, check/clear), families via 6-char join code, task assignment (assignee can update status only)
- Completion chime (bundled wav), on-device alarms at task time + 2h pre-alerts (expo-notifications, synced from tasks; urgent/high all-day tasks get 8am heads-up)
- Testing: backend v2 8/8 + regression 19/19, frontend flows pass

## Iteration 3 (2026-06)
- Voice in Chat: mic button in chat thread → /api/transcribe (whisper-1) → auto-sends to Alter
- Family Chore Board (/api/family/board): per-member done-this-week / open / overdue, Most done & Most open badges, fairness tip
- Testing: backend v3 6/6, frontend pass

## Iteration 4 (2026-06)
- Cute redesign: peach & mint on cream palette, Fredoka + Nunito fonts, rounder radii; AI-generated logo (human hugging robot, Gemini Nano Banana) used in-app and as app icon/splash/favicon
- Simplified Home: logo header, greeting, big pulsing mic, type box, Task/Memory/Chat buttons, Today card, grocery & family cards
- Testing: frontend visual + regression pass

## Iteration 5 (2026-06)
- Mascot moods: cheering mascot overlay + chime on any task completion (celebrate()), waving mascot in empty Tasks/Grocery/Home states (AI-generated from logo reference)
- Spoken replies: /api/tts (gpt-4o-mini-tts, voice coral, warm instructions; fallback tts-1), auto-reads replies to voice messages in chat, header mute toggle (persisted), per-reply Listen button
- Testing: backend v4 9/9, frontend pass

## Iteration 6 (2026-06) — bug fix
- Notifications: 4 alerts per timed task (2h, 1h, 5min, on time), channel task-alerts-v2, ting-ting sound (tingting.wav in builds, default in Expo Go), per-alert try/catch (missing custom sound previously aborted scheduling), auto permission request when a timed task exists, SCHEDULE_EXACT_ALARM
- Completion chime shortened to 0.7s, quieter; "Well done!" (1.5s) shown after cheer only when all tasks for that day are complete
- Testing: iteration 6 pass (delivery verified by code review; needs real device)

## Iteration 7 (2026-06)
- Admin role + idempotent seeding (admin@alter.app from .env ADMIN_*, demo@alter.app DEMO_*), admin-only GET /api/admin/analytics
- Activity tracking via sessions (30-min gap): DAU/WAU/MAU, stickiness, daily active/sessions/sign-ups/actions, session-length drop-off buckets, busiest hours, churn (14d inactivity, avg days before churn), D1/D7/D30 retention, feature usage, recently active users
- In-app Admin analytics screen (/admin) via Profile → Creator (admin only)
- Testing: backend 12/12, frontend pass

## Iteration 8 (2026-06)
- Comeback nudge: on-device notifications 3 & 7 days after last open (rescheduled every open, daytime-clamped, kept separate from task alerts); welcome-back waving mascot overlay after 3+ days away
- Testing: frontend pass

## Backlog
- P1: Notifications/reminders for due tasks (not configured — app states this)
- P1: Native date/time picker for tasks
- P2: Memory relevance via embeddings; conversation rename; export of personal data
- P2: Supabase/Postgres port if required later

## Memory Category Folders (DONE)
- Memory tab shows horizontal folder cards (All + 7 categories) with live item counts; tap to filter, tap again to return to All.
- Backend: GET /api/memories/categories -> {total, counts}. Tests: backend/tests/test_memory_categories.py

## Developer login + Google sign-in + Gmail tasks (IN PROGRESS)
- Developer admin = admin@example.com (ADMIN_EMAIL), others demoted. Admin dashboard lists ALL users with sessions/tasks/memories/chats/gmail.
- "Continue with Google" (Emergent-managed) alongside email/password.
- Gmail: each user connects own Gmail (gmail.readonly, own tokens, encrypted). Tasks auto-extracted by Gemini every 30 min + on Tasks tab focus + manual. Needs GOOGLE_CLIENT_ID/SECRET.
- Post-signup mascot screen /connect-google: "Let Alter find your to-dos from your Google account" (one approval: calendar.readonly + gmail.readonly). Auto-skips if Google not configured or already connected.
- Calendar: next 7 days events -> tasks (source=calendar), moved events update due; every 30 min. UI avoids the word "email".
- Google Cloud needs BOTH Gmail API and Google Calendar API enabled.
- Analytics exclude internal accounts (ADMIN_EMAIL, @alter.app/@example.com/@test.app/@test.com incl. demo); ?include_test=true shows all. Old QA accounts purged from preview DB.
- Live clock: useNow hook (30s tick + on app foreground); Home shows live date/time; tasks labels refresh; profile timezone auto-syncs to device tz on every app open.
- Developer account is now built into code (DEVELOPER_EMAIL + bcrypt DEVELOPER_PASSWORD_HASH in server.py); seeded on every startup incl. live DB; all other admins demoted. ADMIN_EMAIL/ADMIN_PASSWORD env no longer used.
- Task status simplified to todo/completed (old in_progress migrated to todo on startup).
- Tasks tab: Tasks | History | Groceries. History = day navigator (prev/next/jump to today) showing tasks completed that local day + tasks due that day not done. GET /api/tasks/history?date=

## AI Guardrails (DONE) — see /app/memory/GUARDRAILS.md
- backend/guardrails.py: verbatim policy prompt, evidence ids, grounded JSON responder, validator model, redaction, injection neutralization, secret gate.
- Chat replies carry `sources`; shown in chat as "Based on". guardrail_events -> admin "AI guardrails" card.
- Eval: python backend/tests/guardrails_eval.py -> test_reports/guardrails_eval.json (19/19).
- Google sync errors (403 SERVICE_DISABLED etc.) now stored on gmail_accounts.error and shown in the Profile card / sync toast. User project 477534845706 must ENABLE Gmail API + Google Calendar API.
- No duplicate tasks: find_duplicate_task (same day, title Jaccard>=0.75, compatible time, any source/status). POST /tasks -> 409; chat/voice -> "Already on your list"; inbox/calendar imports link instead of re-adding; gmail_processed unique (user_id,gmail_id) claim-first.
- Alarms: web uses browser Notification (Windows toast) + in-page timers while tab open; in-app ringing overlay (alarm.wav loop, Mark done/Stop). Native: alarm channel task-alarm-v3 (alarm.wav, ALARM usage, bypassDnd), USE_EXACT_ALARM, iOS timeSensitive. Custom sounds only in real builds (Expo Go = default sound).
- Tasks list: "Assign" pill on own open tasks (opens AssignSheet: Me + family) and "I assigned" filter chip; both only when family has other members.

## AI Cost Controls & Private Beta (DONE)
- backend/usage.py: atomic per-user/feature/UTC-day counters (usage_counters), reservations (usage_reservations, TTL 5 min + sweep), usage_events (no content), app_settings (admin-editable limits), config_audit, beta_invites.
- Defaults: chat 30/day, voice 5/day, read-aloud opt-in (20/day), user AI calls 150/day, global 3000/day & 50000/month AI calls, 300 audio ops/day, spend alerts $3/day $50/month (estimates). Env overrides QUOTA_*/GLOBAL_*/SPEND_*/BETA_MODE.
- Covered: /chat, /voice, /transcribe, /tts, inbox AI extraction. Calendar sync not counted.
- Admin screen /admin-usage. demo@alter.app invited for testing. Tests: backend/tests/usage_controls_test.py (30/30), guardrails_eval 19/19.

## Android Private Beta (Jun 2026)
- Added android.versionCode=1; package com.emergent.alterassist.nez34r, version 1.0.0, scheme alter://
- APK built via Emergent Publish (managed Expo, no local Android SDK). Guide: memory/ANDROID_BETA.md
- Smoke test: backend/tests/beta_apk_smoke.py (all pass on preview)
- Fix: Android 13+ notification permission prompt never shown (channel now created before request). versionCode bumped to 2.
- Jun 2026: full-screen Android alarm (react-native-notify-kit, src/alarm.android.ts + plugins/withAlarmActivity.js), home "Type a task" (QuickTask) + AI "Your day" summary (GET /api/summary/today, cached, 1 chat), family plans (include_family, family_upcoming; confidential tasks private), priority dropdown (PriorityPicker), timezone follows phone on foreground. versionCode 3.
- "Test my alarm" button on Tasks tab (scheduleTestAlarm in notifications.ts, rings in 10s; full-screen on Android APK). versionCode 4.
- Tester feedback: POST /api/feedback (10/day/user), admin GET /api/admin/feedback + PATCH status; Feedback button on Home + Profile; admin inbox app/admin-feedback.tsx.
- Typed capture POST /api/capture (home box: groceries vs tasks, any language, fallback task when AI limit hit); grocery plural dedupe (grocery_key); Whisper no longer drops low-confidence non-English speech; read-aloud/TTS removed (backend route + UI + speech.ts). versionCode 5.
- BYOK Gemini (ai_provider.py): per-user encrypted keys, admin-only Universal fallback (UNIVERSAL_KEY_ACCESS), ai_billing log, /api/ai/key CRUD, /api/admin/billing; Gemini audio transcription for BYOK; voice_language; task category/recurrence/source_text/clarify; AI never invents dates; capture idempotency (client_id). See memory/AI_ROUTING.md.
- App-owner GEMINI_API_KEY route ("app") for all users without BYOK; UNIVERSAL_KEY_ACCESS=none (no Universal fallback); planner skip for plain questions; backend date table; past AI dates dropped. Tests: tests/app_key_e2e.py, tests/test_ai_provider_unit.py.
- Budget alert email (budget_alerts.py, Emergent managed email): one email/day to ADMIN_EMAIL (or BUDGET_ALERT_EMAIL) when app-wide AI calls reach BUDGET_ALERT_PCT (90) % of ai_calls_per_day; hook via Usage.on_admit (also on global-limit rejection); dedupe in budget_alerts collection, retry after 30 min on failure. BYOK calls not counted.
- Per-user limits removed (chat/voice/ai_calls per user = 0 = unlimited); global daily/monthly budget + 90% alert kept. Home "Groceries only" chip adds items straight to the grocery list without AI.
- Beta mode turned OFF (default false): all signed-in users can use AI; global budget + alert remain.

## Feedback emails & bug metrics (Oct 2026)
- Every tester feedback (POST /api/feedback) is emailed to ADMIN_EMAIL (override FEEDBACK_EMAIL) via Emergent managed email (budget_alerts.send_feedback_email), in background.
- Bugs require `area`: alarms|voice|tasks|groceries|chat|sign_in|other (chips in FeedbackSheet).
- /api/admin/analytics returns `bugs: {total, open, by_area}`; shown in Admin analytics "Bugs reported" card; inbox shows area.
- AI model fallback across Gemini models on quota (see AI_ROUTING.md).
- Deploy check (Oct 2026): removed destructive startup dedupe + capture_results TTL; quoted METRO_CACHE_ROOT. Deployed domain https://alter-assist.emergent.host; Google redirect URI for it is registered (Google shows sign-in, no mismatch).
- Oct 2026: Tasks tab grouped Today (incl. overdue) / Tomorrow / Later, sorted by priority; priority + Alarm tags. Home has ONE input row (type, or mic when empty). Task.alarm flag: AI/offline "set an alarm for 7am…" -> alarm task (next occurrence), rings on time only (no early reminders). Android alarms use notify-kit SET_ALARM_CLOCK; banner if exact alarms disabled. Deployed app was running OLD code (beta mode on) -> user must redeploy.
- Oct 2026: /settings page (time zone chips/device/typed, AI usage bar via GET /api/me/usage, delete account); Profile links to it. Snooze 10 min on alarm overlay (scheduleSnooze, SNOOZE_PREFIX ids survive resync). Daily/weekday repeating alarms: backend roll_repeating_alarms on GET /tasks; client schedules next ~8 rings (iOS budget 60). "Sync calendar now" in Tasks (POST /gmail/sync?force=true, 30s guard).
- Oct 2026: Snooze choices 5/10/30 min on alarm overlay (SNOOZE_OPTIONS; marking done cancels pending snooze). TaskSheet Repeat picker (Once/Every day/Weekdays/Every week/Every month) shown when alarm on; PUT /tasks accepts recurrence:null.
- Oct 2026 (fix round): app AI route tries light models first (3.5-flash-lite, 3.1-flash-lite-preview, then 3.5-flash, 3-flash-preview, 3.8-flash; override GEMINI_FALLBACK_MODELS). Relative alarms ("now", "in 10 minutes") via prompt rule + backend guard (current-minute -> +1 min) + offline parser. Calendar sync: from start of today, 30 days, every 10 min.
- Oct 2026: drop_grocery_duplicates() in execute_actions (no extra task for an item already put on grocery list); offline grocery parser also handles Hindi "X lena hai / chahiye". App version 1.1.0 (versionCode 7) shown at bottom of Profile so testers can confirm new build. Verified voice (real speech m4a) + grocery capture on deployed server.
- Oct 2026: Restrictions removed: U.beta_allowed always True; per-user feature limits no longer enforced (only app-wide safety caps); chat beta banner removed; deployed+preview app_settings set beta_mode=false, per-user limits 0. Chat evidence now includes matching completed/past tasks & calendar events and the user's own past messages from other conversations (still strictly history-only, no general knowledge).
- Oct 2026: admin-usage beta/invite UI and per-user limit fields removed; per-user counters only record usage (limit 1e9). Chat: keyword matching via keywords() (any script, stopwords), past messages labelled "You said earlier"; chat reply/check use non-lite models first (3.5-flash), other features lite-first; Gemini attempt timeout 25s and timeouts switch model immediately.

# Alter — AI provider & billing routing (BYOK)

## Routing (backend/ai_provider.py, the only place AI calls are created)
| User | Route | Who pays |
|---|---|---|
| Saved their own valid Gemini key (optional) | `byok` | The user's Google project |
| Everyone else | `app`: owner's `GEMINI_API_KEY`, model `GEMINI_MODEL` | App owner's Google project |
| App key missing / rejected / out of quota | Error (`app_missing` / `app_invalid` / `app_quota`); **no fallback** | Nobody |
| Universal Key | Only if `GEMINI_API_KEY` is unset AND `UNIVERSAL_KEY_ACCESS` is `admin`/`beta` (default `none`) | Emergent balance |

- Call savings: plain Latin-script questions skip the planner (2 calls instead of 3); typed/voice capture = 1 combined task+grocery call; backend supplies a date table (today/kal/parso/weekend/next Monday/weekdays); AI dates in the past or malformed are dropped; retries reuse `client_id` / `X-Idempotency-Key`.
- Global budget (`ai_calls_per_day`, `ai_calls_per_month`, audio ops) and per-user limits (chat 30/day, voice 5/day) are editable in Admin → AI usage; they apply to the app key. BYOK calls skip the global budget.
- Every AI call is logged in `ai_billing` `{user_id, route, model, feature, ok, error, ms, at}` and in logs as `ai_call route=…`. Admin summary: `GET /api/admin/billing`.
- Per-user limits (30 chats, 5 voice notes/day) still apply to BYOK users. The developer's global daily/monthly allowance is **not** consumed by BYOK calls.
- Retries: up to 3 attempts only for transient errors (5xx/timeouts, 45s per attempt). Never retried: invalid key (400/401/403), quota (429), bad request.

## Key storage
- `PUT /api/ai/key` validates the key with a tiny Gemini call (`GEMINI_VALIDATE_MODEL`), then stores it Fernet-encrypted (`BYOK_ENCRYPTION_KEY`, backend env only, not in Mongo or git). Only a mask (`AQ.A…6m_Q`) is ever returned.
- 5 save attempts/hour/user. `POST /api/ai/key/test` re-checks; `DELETE /api/ai/key` removes it. Deleting the account deletes the key.
- The key is never sent to the frontend, other users, logs, analytics or other providers.
- If `BYOK_ENCRYPTION_KEY` is changed, saved keys can't be decrypted and users are asked to re-enter them.

## Env vars (backend/.env)
`GEMINI_API_KEY` (owner key, secret), `GEMINI_MODEL` (currently gemini-3-flash-preview), `EMERGENT_LLM_KEY`, `AI_MODEL` (universal model, unused unless enabled), `GEMINI_BYOK_MODEL` (default gemini-3.5-flash), `GEMINI_VALIDATE_MODEL` (gemini-3.5-flash-lite), `GEMINI_ATTEMPT_TIMEOUT_S` (45), `UNIVERSAL_KEY_ACCESS` (none), `BYOK_ENCRYPTION_KEY` (Fernet). `GEMINI_TEST_API_KEY` is used by tests only.

## Speech
- BYOK: Gemini audio understanding (same user key): transcribes as spoken, keeps Hindi-English code-switching, no translation.
- Universal (admin): Whisper, with an optional language hint.
- Profile → Voice language: auto-detect (default) or en/hi/bn/ta/te/mr/gu/kn/ml/pa/ur (a hint, not a restriction).
- Read-aloud (TTS) stays removed at the owner's request.

## Disclosure (shown in Profile → AI key)
With your own key, your messages and the relevant personal context Alter retrieves for them are sent to Google's Gemini API, under your Google account and Google's terms; Google may bill you. BYOK doesn't remove all costs and doesn't hide data from the model provider.

## Budget alert
- `budget_alerts.py`: when app-wide AI calls today reach `BUDGET_ALERT_PCT` (90) % of the daily budget, one email goes to `BUDGET_ALERT_EMAIL` or `ADMIN_EMAIL`. At most one per UTC day; a failed send is retried after 30 min. Env: `EMERGENT_EMAIL_KEY`, `EMAIL_FROM_NAME=Alter`, `BUDGET_ALERT_PCT`.

## Model fallback (free-tier quota rotation)
Gemini free-tier quotas are per model. `Route.generate` tries the route's model, then each model in
`GEMINI_FALLBACK_MODELS` (same key, so no extra cost). A model returning 429 is skipped for
`GEMINI_QUOTA_COOLDOWN_S` (default 300s); 404/503 models are skipped for 60s. Applies to app key and BYOK keys.

# Alter — AI Guardrails Implementation Report

## Architecture (every chat answer)
1. **Auth** — JWT verified server-side (`CurrentUser`); user id never taken from the client.
2. **Secret gate** (deterministic, `guardrails.asks_for_secret`) — requests for passwords/PIN/OTP/keys/tokens/system prompt return `SECRET_REFUSAL` without calling any model.
3. **Redaction** — `guardrails.redact` strips secret values from the user's message *before* it is stored, planned or sent to a model; chat history never contains them.
4. **Retrieval** (server, current user only) — memories `{user_id}`, tasks `{user_id} OR {assigned_to}` (explicit family sharing), this conversation's user turns, profile, family roster. Minimum context: ≤15 relevant memories, ≤40 tasks.
5. **Evidence map** — each record becomes `[E#]` with real record id, type, label, timestamp; untrusted text passes `neutralize` (instruction-like spans removed) + `redact`.
6. **Planner** — structured memory/task operations; results become `[OP#]` evidence.
7. **Responder** — `POLICY_PROMPT` (verbatim product policy) + `RESPONDER_FORMAT`; returns JSON `{kind, answer, claims[{text, sources, inference}]}`.
8. **Grounding** (`guardrails.ground`):
   - `out_of_scope` / `insufficient` → canonical refusal text.
   - Deterministic: claims citing non-existent ids are rejected (fabricated sources counted).
   - Separate **validator model** checks every statement against evidence; unsupported statements are removed (`revised_answer`) or the answer is withheld.
   - Validator failure → **fail closed** (insufficient), except pure action reports/clarifications.
   - Output redacted again.
9. **Sources** returned with the message and shown under the reply ("Based on …").
10. **Metrics** logged per reply in `guardrail_events` → Admin analytics "AI guardrails" card.

## AI endpoints and policy coverage
| Endpoint | Model use | Policy applied |
|---|---|---|
| `POST /api/chat` | planner + responder + validator | full pipeline above |
| `POST /api/voice` | voice note → tasks/groceries | `EXTRACTION_POLICY` (no outside knowledge, content = data) |
| Gmail/Calendar sync | inbox → tasks (calendar is deterministic, no model) | `EXTRACTION_POLICY`, `neutralize` + `redact` on email/calendar text |
| `POST /api/transcribe` | Whisper speech-to-text | transcription only, no generation |
| `POST /api/tts` | text-to-speech of an existing reply | no generation |

No web search, browsing, tools or function-calling are configured on any model call; there is no general-knowledge fallback path.

## Database / security
- Database is **MongoDB + FastAPI** (Alter does not use Supabase), so Supabase RLS does not apply. The equivalent is enforced in the backend: every query filters by the authenticated user id; cross-user reads/writes return 404 (verified).
- Secrets: LLM key, Google client secret, JWT secret are server-side env vars only. Google tokens are encrypted (Fernet) and never returned by any API. Disconnect deletes them and revokes them with Google.
- Secrets are blocked from memories (API + planner), redacted from chat history and prompts. Logs only record exception types, never content.

## Evaluation suite
`python backend/tests/guardrails_eval.py` → `/app/test_reports/guardrails_eval.json` (live API + real model). Last run: **19/19 passed**, covering all 12 required scenarios plus redaction unit checks.

## Honest limitations / unresolved risks
- This is a small, fixed suite run against a live LLM. Results can vary from run to run and do not prove real-world 100% accuracy.
- Validation uses a second LLM, which can itself make mistakes. Deterministic checks only cover source ids, secrets and injection patterns.
- Injection filtering is pattern-based. Novel phrasings may slip through, but the policy and validator still treat that content as data.
- Each answer now makes three model calls, so replies take ~5–10 s. Replies arrive in one piece instead of streaming word by word.
- There are no file uploads in Alter yet, so "uploaded files" scenarios were tested through imported task text.
- Tasks already imported from Google stay as the user's own tasks after disconnect. Only access to the account stops.

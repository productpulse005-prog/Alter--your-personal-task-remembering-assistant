# Alter — Android Private Beta (APK)

## Project type
- Managed Expo project (SDK 58, expo-router). No `android/` folder is checked in; the native project is generated at build time.
- Runs in Expo Go for preview. The installable APK is produced by Emergent's **Publish** build (top-right), not in this container (no Java/Android SDK here).

## Android identity (app.json)
| Field | Value |
|---|---|
| Display name | Alter |
| Package / applicationId | `com.emergent.alterassist.nez34r` (keep stable: changing it means testers get a separate app and lose data) |
| versionName | `1.0.0` (`expo.version`) |
| versionCode | `1` (`expo.android.versionCode`) |
| Deep-link scheme | `alter://` |

**For every new beta APK:** increase `android.versionCode` (2, 3, …) and optionally `version` (1.0.1 …). Android won't install an update over an existing APK unless the versionCode is higher **and** the APK has the same signing key.

## Signing
- Emergent's build signs the APK with a managed release keystore. No keystore, passwords, or `.jks` files are in the repo.
- Keep using the same project for builds so the signing key stays the same (otherwise testers must uninstall first).

## Backend URL
- The frontend reads `EXPO_PUBLIC_BACKEND_URL` (src/api.ts, src/speech.ts). No URLs are hardcoded and no localhost URLs exist in app code.
- Preview value: `https://alter-assist.preview.emergentagent.com` (preview only, not for beta).
- After **Publish**, the release build uses the deployed HTTPS backend URL. Confirm it in the Publish screen, then open `https://<deployed-domain>/api/auth/me` (it should return 401 JSON, which means the backend is reachable).
- Secrets (EMERGENT_LLM_KEY, GOOGLE_CLIENT_SECRET, JWT_SECRET, MONGO_URL) live only in the backend env and are never bundled. The app only receives `EXPO_PUBLIC_*` values.

## Google OAuth (stays External → Testing)
Flow (same on Android and web): app → `POST /api/gmail/connect` → Google consent opened in system browser (expo-web-browser) → Google redirects to **backend** `https://<backend-domain>/api/gmail/callback` → backend exchanges the code server-side (secret never leaves the server; tokens are stored encrypted) → backend page redirects to `alter://profile?gmail=connected` → the app closes the browser.
- Google never redirects to the app directly, so **no Android OAuth client / SHA-1 is needed**. The existing Web client is used.
- **Required manual step:** in Google Cloud Console → Clients → (existing Web client) → Authorized redirect URIs, add
  `https://<deployed-domain>/api/gmail/callback` (in addition to the existing preview URI). The redirect URI is derived from the host that served the request, so it changes when the domain changes.
- Google Auth Platform → Audience → Test users: add each tester's Gmail (max 100). Non-listed accounts get "Access blocked", which is expected in Testing mode.
- Testing-mode refresh tokens expire after 7 days, so testers will need to reconnect Google weekly.
- Scopes unchanged: openid, email, gmail.readonly, calendar.readonly.
- "Sign in with Google" (app login) uses Emergent-managed auth with a redirect to `alter://`, which works in standalone builds via the scheme.

## Beta access (AI)
- AI features require a beta invite: Profile → Admin analytics → AI usage, limits & beta invites (admin: admin@example.com). Limits: 30 chats/day, 5 voice notes/day.
- Installing the APK does not grant AI access or Google authorization.

## Build & distribute
1. Click **Publish** (top-right in Emergent) → deploy the backend → choose the Android build → download the `.apk`.
2. Share the file privately (Google Drive link restricted to testers, email, or USB). Do not post it publicly.
3. Tester: open the APK on the phone → Android asks to allow "Install unknown apps" for that app (Chrome/Files/Drive) → allow → Install.
   - Play Protect may warn about an unknown developer: choose "Install anyway".
4. Updates: bump `versionCode`, rebuild, and send the new APK. Testers install it over the old one, and their data stays (it lives on the server).

## Verification done (preview backend)
`backend/tests/beta_apk_smoke.py` (BASE=<https url>): login/bad password/no-token, session, memory and task create/list, cross-user isolation (memories, tasks, conversations), chat recall from memory, general-knowledge guardrail, and Google connect returning the HTTPS backend callback. All pass.
Re-run against the deployed URL after publishing: `BASE=https://<deployed-domain> python backend/tests/beta_apk_smoke.py`

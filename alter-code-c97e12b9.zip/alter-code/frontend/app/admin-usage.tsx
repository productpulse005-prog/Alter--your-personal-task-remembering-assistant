import Feather from "@react-native-vector-icons/feather";
import { useQuery } from "@tanstack/react-query";
import { Redirect, useRouter } from "expo-router";
import React, { useState } from "react";
import { Pressable, RefreshControl, ScrollView, Switch, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/api";
import { useAuth } from "@/src/auth";
import { useToast } from "@/src/components/toast";
import { Button, ErrorState, Field, Skeleton } from "@/src/components/ui";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Settings = Record<string, number | boolean>;
type UsageData = {
  settings: Settings; timezone_policy: string; cost_note: string;
  global: { ai_calls_today: number; ai_calls_today_limit: number; ai_calls_month: number; ai_calls_month_limit: number; audio_ops_today: number; audio_ops_today_limit: number; est_cost_today_usd: number; est_cost_month_usd: number; spend_alert_day: boolean; spend_alert_month: boolean };
  beta: { invited: number; active: number; suspended_or_revoked: number; active_users_today: number };
  outcomes: Record<string, number>; internal_calls: Record<string, number>;
  by_feature: { feature: string; provider: string; requests: number; success: number; failed: number; rate_limited: number; ai_calls: number; est_tokens: number; est_cost_usd: number }[];
  by_day: { day: string; chat: number; voice: number; tts: number; inbox: number; ai_calls: number; est_cost_usd: number }[];
  users_today: { user_id: string; email: string; name: string; chat: number; voice: number; tts: number; inbox: number; ai_calls: number; status: string }[];
  config_history: { at: string; by: string; changes: Record<string, unknown> }[];
};

const LIMIT_FIELDS: [string, string][] = [
  ["ai_calls_per_day", "AI calls / day (all users)"], ["ai_calls_per_month", "AI calls / month (all users)"],
  ["audio_ops_per_day", "Voice notes / day (all users)"], ["spend_alert_day_usd", "Spend alert / day (USD, est.)"],
  ["spend_alert_month_usd", "Spend alert / month (USD, est.)"],
];

export default function UsageScreen() {
  const { user, status } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const s = useStyles();
  const { colors } = useTheme();
  const toast = useToast();
  const isAdmin = user?.role === "admin";
  const q = useQuery({ queryKey: ["admin-usage"], queryFn: () => api<UsageData>("/admin/usage"), enabled: isAdmin });
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  if (status === "signedOut") return <Redirect href="/auth" />;
  if (status === "signedIn" && !isAdmin) return <Redirect href="/home" />;

  const save = async (changes: Record<string, unknown>) => {
    setBusy(true);
    try {
      await api("/admin/usage/settings", { method: "PUT", body: changes });
      setDraft({});
      await q.refetch();
      toast("Settings saved");
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setBusy(false);
    }
  };
  const d = q.data;
  const meter = (label: string, used: number, limit: number, id: string) => (
    <View style={s.meter} key={id} testID={`usage-meter-${id}`}>
      <View style={s.rowBetween}><Text style={s.k}>{label}</Text><Text style={s.v}>{`${used} / ${limit}`}</Text></View>
      <View style={s.track}><View style={[s.fill, { width: `${Math.min(100, limit ? (used / limit) * 100 : 100)}%`, backgroundColor: used >= limit ? colors.error : colors.brandPrimary }]} /></View>
    </View>
  );

  return (
    <View style={s.root}>
      <View style={[s.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable onPress={() => router.back()} style={s.back} testID="usage-back" accessibilityLabel="Back"><Feather name="chevron-left" size={24} color={colors.onSurface} /></Pressable>
        <Text style={s.title}>Usage & beta</Text>
      </View>
      {q.isLoading ? <View style={{ padding: spacing.xl }}><Skeleton rows={6} height={60} /></View> : q.isError || !d ? (
        <ErrorState message={(q.error as Error)?.message ?? "Couldn't load"} onRetry={() => q.refetch()} testID="usage-error" />
      ) : (
        <ScrollView contentContainerStyle={s.body} refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => { q.refetch(); b.refetch(); }} />}>
          <View style={s.card} testID="usage-global">
            <Text style={s.cardTitle}>Today & this month</Text>
            {meter("AI calls today", d.global.ai_calls_today, d.global.ai_calls_today_limit, "day")}
            {meter("AI calls this month", d.global.ai_calls_month, d.global.ai_calls_month_limit, "month")}
            {meter("Voice notes today", d.global.audio_ops_today, d.global.audio_ops_today_limit, "audio")}
            <Text style={[s.k, (d.global.spend_alert_day || d.global.spend_alert_month) && { color: colors.error }]} testID="usage-cost">
              {`Estimated cost: $${d.global.est_cost_today_usd.toFixed(3)} today · $${d.global.est_cost_month_usd.toFixed(2)} this month${d.global.spend_alert_day || d.global.spend_alert_month ? " — above alert threshold" : ""}`}
            </Text>
            <Text style={s.note}>{`${d.cost_note} ${d.timezone_policy}`}</Text>
          </View>

          <View style={s.card}>
            <View style={s.rowBetween}>
              <View style={{ flex: 1 }}><Text style={s.cardTitle}>Emergency AI pause</Text><Text style={s.note}>Blocks all new AI requests. Tasks, memories and reminders keep working.</Text></View>
              <Switch testID="usage-ai-disabled-switch" value={!!d.settings.ai_disabled} onValueChange={(v) => save({ ai_disabled: v })} />
            </View>
            <Text style={s.note}>Every signed-in user can use all features. There is no invite list or per-user limit.</Text>
          </View>

          <View style={s.card} testID="usage-limits">
            <Text style={s.cardTitle}>Limits</Text>
            {LIMIT_FIELDS.map(([k, label]) => (
              <View key={k} style={s.rowBetween}>
                <Text style={[s.k, { flex: 1 }]}>{label}</Text>
                <View style={{ width: 110 }}><Field testID={`usage-limit-${k}`} value={draft[k] ?? String(d.settings[k])} onChangeText={(t) => setDraft({ ...draft, [k]: t })} keyboardType="numeric" /></View>
              </View>
            ))}
            <Button label="Save limits" onPress={() => save(Object.fromEntries(Object.entries(draft).map(([k, v]) => [k, Number(v)])))} loading={busy} disabled={!Object.keys(draft).length} testID="usage-save-limits" />
          </View>

          <View style={s.card} testID="usage-users">
            <Text style={s.cardTitle}>Users today</Text>
            {d.users_today.length ? d.users_today.map((u) => (
              <View key={u.user_id} style={s.rowBetween}>
                <Text style={[s.v, { flex: 1 }]} numberOfLines={1}>{u.name || u.email}</Text>
                <Text style={[s.k, u.status !== "ok" && { color: colors.error }]}>{`💬 ${u.chat}/${d.settings.chat_per_user_day || "∞"} · 🎙 ${u.voice}/${d.settings.voice_per_user_day || "∞"} · ${u.ai_calls} calls${u.status !== "ok" ? ` · ${u.status}` : ""}`}</Text>
              </View>
            )) : <Text style={s.note}>No AI usage yet today.</Text>}
          </View>

          <View style={s.card} testID="usage-features">
            <Text style={s.cardTitle}>By feature (last 14 days)</Text>
            {d.by_feature.map((f) => (
              <Text key={f.feature} style={s.k}>{`${f.feature} (${f.provider}): ${f.success} ok · ${f.failed} failed · ${f.rate_limited} limited · ${f.ai_calls} AI calls · ~${f.est_tokens} tokens · ~$${f.est_cost_usd.toFixed(3)}`}</Text>
            ))}
            <Text style={s.k}>{`Internal calls: ${Object.entries(d.internal_calls).map(([k, v]) => `${k} ${v}`).join(" · ") || "none"}`}</Text>
            <Text style={s.k}>{`Outcomes: ${Object.entries(d.outcomes).map(([k, v]) => `${k} ${v}`).join(" · ") || "none"}`}</Text>
            {d.by_day.slice(-7).map((r) => <Text key={r.day} style={s.note}>{`${r.day}: chat ${r.chat} · voice ${r.voice} · inbox ${r.inbox} · ${r.ai_calls} calls`}</Text>)}
          </View>

          <View style={s.card} testID="usage-history">
            <Text style={s.cardTitle}>Settings history</Text>
            {d.config_history.length ? d.config_history.map((h, i) => <Text key={i} style={s.note}>{`${h.at.slice(0, 16).replace("T", " ")} · ${h.by} · ${JSON.stringify(h.changes)}`}</Text>) : <Text style={s.note}>No changes yet.</Text>}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.lg, paddingBottom: spacing.sm },
  back: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  title: { fontFamily: fonts.display, fontSize: 24, color: c.onSurface },
  body: { padding: spacing.lg, gap: spacing.lg, paddingBottom: 64 },
  card: { borderWidth: 1, borderColor: c.border, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.sm, backgroundColor: c.surface },
  cardTitle: { fontFamily: fonts.textMedium, fontSize: 15, color: c.onSurface },
  rowBetween: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: spacing.sm, minHeight: 44 },
  meter: { gap: 4 },
  track: { height: 8, borderRadius: 4, backgroundColor: c.surfaceSecondary, overflow: "hidden" },
  fill: { height: 8, borderRadius: 4 },
  k: { fontFamily: fonts.text, fontSize: 13, color: c.onSurfaceSecondary },
  v: { fontFamily: fonts.textMedium, fontSize: 14, color: c.onSurface },
  note: { fontFamily: fonts.text, fontSize: 12, color: c.muted },
}));

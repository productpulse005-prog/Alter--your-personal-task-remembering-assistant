import Constants from "expo-constants";

import Feather from "@react-native-vector-icons/feather";
import { Redirect, useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import { Pressable, Text, View } from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, Profile } from "@/src/api";
import { useAuth } from "@/src/auth";
import { AIKeyCard } from "@/src/components/AIKeyCard";
import { FeedbackSheet } from "@/src/components/FeedbackSheet";
import { GmailConnect } from "@/src/components/GmailConnect";
import { useToast } from "@/src/components/toast";
import { Button, Chip, ConfirmSheet, Field, Segmented } from "@/src/components/ui";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

const STYLES = [
  { key: "concise" as const, label: "Concise" },
  { key: "balanced" as const, label: "Balanced" },
  { key: "detailed" as const, label: "Detailed" },
];

const VOICE_LANGS: Record<string, string> = {
  auto: "Auto-detect", en: "English", hi: "Hindi", bn: "Bengali", ta: "Tamil", te: "Telugu", mr: "Marathi",
  gu: "Gujarati", kn: "Kannada", ml: "Malayalam", pa: "Punjabi", ur: "Urdu",
};

export default function ProfileScreen() {
  const { profile, user, setProfile, signOut, status } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const s = useStyles();
  const { colors } = useTheme();
  const toast = useToast();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [preferences, setPreferences] = useState("");
  const [style, setStyle] = useState<Profile["response_style"]>("balanced");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [confirm, setConfirm] = useState<null | "signout">(null);
  const [busy, setBusy] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);

  useEffect(() => {
    api<Profile>("/profile").then(setProfile).catch(() => {});
  }, [setProfile]);

  useEffect(() => {
    if (!profile) return;
    setName(profile.display_name);
    setDescription(profile.description);
    setPreferences(profile.preferences);
    setStyle(profile.response_style);
  }, [profile]);

  const save = async () => {
    if (!name.trim()) return setErrors({ name: "Display name is required" });
    setErrors({});
    setSaving(true);
    try {
      const p = await api<Profile>("/profile", { method: "PUT", body: { display_name: name.trim(), description, preferences, response_style: style } });
      setProfile(p);
      toast("Profile saved");
    } catch (e: any) {
      setErrors({ form: e.message });
    } finally {
      setSaving(false);
    }
  };

  const onConfirm = async () => {
    setBusy(true);
    try {
      setConfirm(null);
      await signOut();
      router.replace("/auth");
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setBusy(false);
    }
  };

  if (status === "signedOut") return <Redirect href="/auth" />;

  return (
    <View style={s.root}>
      <View style={[s.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="profile-back-button" onPress={() => (router.canGoBack() ? router.back() : router.replace("/home"))} style={s.iconBtn} accessibilityLabel="Back">
          <Feather name="chevron-left" size={24} color={colors.onSurface} />
        </Pressable>
        <Text style={s.headerTitle}>Profile</Text>
        <View style={s.iconBtn} />
      </View>
      <KeyboardAwareScrollView bottomOffset={24} keyboardShouldPersistTaps="handled" contentContainerStyle={[s.content, { paddingBottom: insets.bottom + spacing["2xl"] }]}>
        <View style={s.identity}>
          <View style={s.avatar}><Text style={s.avatarText}>{(name[0] ?? "·").toUpperCase()}</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={s.name} numberOfLines={1}>{name || "Your profile"}</Text>
            <Text style={s.email} testID="profile-email">{user?.email}</Text>
          </View>
        </View>

        <SectionTitle icon="user" title="About you" />
        <Field testID="profile-name-input" label="Display name" value={name} onChangeText={setName} maxLength={60} error={errors.name} />
        <Field testID="profile-description-input" label="Description" placeholder="A line or two about you (optional)" value={description} onChangeText={setDescription} multiline maxLength={500} />

        <SectionTitle icon="sliders" title="How Alter responds" />
        <Field testID="profile-preferences-input" label="Preferences" placeholder="e.g. Use British English. Suggest practical next steps." value={preferences} onChangeText={setPreferences} multiline maxLength={1000} />
        <Text style={s.label}>Response style</Text>
        <Segmented options={STYLES} value={style} onChange={setStyle} testID="profile-style" />

        <Text style={s.label}>Voice language</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm }} testID="profile-voice-language">
          {Object.entries(VOICE_LANGS).map(([code, label]) => (
            <Chip
              key={code}
              label={label}
              selected={(profile?.voice_language ?? "auto") === code}
              onPress={() => api<Profile>("/profile", { method: "PUT", body: { voice_language: code } }).then(setProfile).catch((e) => toast(e.message, "error"))}
              testID={`profile-voice-lang-${code}`}
            />
          ))}
        </View>
        <Text style={s.link}>Speak Hindi and English mixed (Hinglish)? Keep Auto-detect. Pick one language only if you always speak just that language.</Text>

        <SectionTitle icon="key" title="AI key (Gemini)" />
        <AIKeyCard />

        <SectionTitle icon="settings" title="Settings" />
        <Button label="Time zone, AI usage & account" variant="secondary" icon="settings" onPress={() => router.push("/settings")} testID="profile-settings-button" />

        {errors.form ? <Text style={s.error} testID="profile-error">{errors.form}</Text> : null}
        <Button label="Save profile" onPress={save} loading={saving} testID="profile-save-button" />

        {user?.role === "admin" ? (
          <>
            <SectionTitle icon="bar-chart-2" title="Creator" />
            <Button label="Admin analytics" icon="bar-chart-2" onPress={() => router.push("/admin")} testID="profile-admin-button" />
            <Button label="Tester feedback inbox" variant="secondary" icon="inbox" onPress={() => router.push("/admin-feedback")} testID="profile-admin-feedback-button" />
          </>
        ) : null}

        <SectionTitle icon="link" title="Connected accounts" />
        <GmailConnect />

        <SectionTitle icon="users" title="Family" />
        <Button label="Manage family & invite code" variant="secondary" icon="users" onPress={() => router.push("/family")} testID="profile-family-button" />

        <SectionTitle icon="message-square" title="Send feedback" />
        <Button label="Send feedback or report a bug" variant="secondary" icon="send" onPress={() => setFeedbackOpen(true)} testID="profile-feedback-button" />

        <SectionTitle icon="lock" title="Account" />
        <Text style={s.note}>For tasks with a time, this device reminds you 2 h, 1 h and 5 min before, and rings exactly on time.</Text>
        <Button label="Sign out" variant="secondary" icon="log-out" onPress={() => setConfirm("signout")} testID="profile-signout-button" />
        <Text style={[s.link, { color: colors.muted, textAlign: "center" }]} testID="profile-app-version">{`Alter version ${Constants.expoConfig?.version ?? "?"}`}</Text>
      </KeyboardAwareScrollView>
      <ConfirmSheet
        visible={!!confirm}
        title="Sign out?"
        message="You can sign back in any time."
        confirmLabel="Sign out"
        loading={busy}
        onConfirm={onConfirm}
        onClose={() => setConfirm(null)}
        testID="profile-confirm"
      />
      <FeedbackSheet visible={feedbackOpen} onClose={() => setFeedbackOpen(false)} />
    </View>
  );

  function SectionTitle({ icon, title }: { icon: React.ComponentProps<typeof Feather>["name"]; title: string }) {
    return (
      <View style={s.sectionTitle}>
        <View style={s.sectionIcon}><Feather name={icon} size={16} color={colors.onBrandTertiary} /></View>
        <Text style={s.sectionText}>{title}</Text>
      </View>
    );
  }
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.sm, paddingBottom: spacing.sm, borderBottomWidth: 1, borderColor: c.divider },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  headerTitle: { flex: 1, textAlign: "center", fontFamily: fonts.display, fontSize: 20, color: c.onSurface },
  content: { padding: spacing.xl, gap: spacing.lg, maxWidth: 640, width: "100%", alignSelf: "center" },
  identity: { flexDirection: "row", alignItems: "center", gap: spacing.lg },
  avatar: { width: 64, height: 64, borderRadius: 32, backgroundColor: c.brandTertiary, alignItems: "center", justifyContent: "center" },
  avatarText: { fontFamily: fonts.display, fontSize: 28, color: c.onBrandTertiary },
  name: { fontFamily: fonts.display, fontSize: 24, color: c.onSurface },
  email: { fontFamily: fonts.text, fontSize: 14, color: c.muted },
  sectionTitle: { flexDirection: "row", alignItems: "center", gap: spacing.md, marginTop: spacing.lg },
  sectionIcon: { width: 32, height: 32, borderRadius: radius.md, backgroundColor: c.brandTertiary, alignItems: "center", justifyContent: "center" },
  sectionText: { fontFamily: fonts.display, fontSize: 20, color: c.onSurface },
  label: { fontFamily: fonts.textMedium, fontSize: 12, color: c.muted, textTransform: "uppercase", letterSpacing: 0.8 },
  link: { fontFamily: fonts.textMedium, fontSize: 13, color: c.brandPrimary },
  error: { fontFamily: fonts.text, fontSize: 14, color: c.error },
  note: { fontFamily: fonts.text, fontSize: 13, color: c.muted, lineHeight: 19 },
}));

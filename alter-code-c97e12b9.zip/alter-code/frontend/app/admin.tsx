import Feather from "@react-native-vector-icons/feather";
import { useQuery } from "@tanstack/react-query";
import dayjs from "dayjs";
import { Redirect, useRouter } from "expo-router";
import React, { useState } from "react";
import { Pressable, RefreshControl, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/api";
import { useAuth } from "@/src/auth";
import { ErrorState, SearchBar, Segmented, Skeleton } from "@/src/components/ui";
import { BUG_AREAS } from "@/src/components/FeedbackSheet";
import { relTime } from "@/src/labels";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Analytics = {
  days: number;
  generated_at: string;
  totals: { users: number; dau: number; wau: number; mau: number; stickiness_pct: number; new_users_7d: number; sessions: number; avg_session_min: number; median_session_min: number; sessions_per_active_day: number; families: number };
  series: { day: string; active_users: number; sessions: number; new_users: number; avg_session_min: number; actions: number }[];
  session_buckets: { label: string; count: number }[];
  hours: number[];
  churn: { inactive_days_threshold: number; churned_users: number; eligible_users: number; churn_rate_pct: number; avg_days_before_churn: number | null };
  retention: { d1_pct: number | null; d7_pct: number | null; d30_pct: number | null };
  features: Record<string, number>;
  bugs: { total: number; open: number; by_area: Record<string, number> };
  guardrails: {
    responses: number; grounding_rate: number | null; unsupported_removed: number; fabricated_sources_dropped: number; withheld: number;
    refusals_out_of_scope: number; insufficient_context: number; secret_blocks: number; clarifications: number; validator_errors: number;
    latency_p50_ms: number | null; latency_p90_ms: number | null;
  };
  users: {
    id: string; name: string; email: string; role: string; sign_in: "email" | "google"; joined: string; last_active: string | null;
    sessions: number; sessions_all_time: number; tasks: number; tasks_completed: number; memories: number; chats: number; gmail_connected: boolean;
  }[];
};

const PERIODS = [
  { key: "7" as const, label: "7 days" },
  { key: "30" as const, label: "30 days" },
  { key: "90" as const, label: "90 days" },
];
const FEATURE_LABELS: Record<string, string> = {
  chat_messages: "Chat messages",
  tasks_created: "Tasks created",
  tasks_by_voice: "Tasks by voice",
  tasks_from_google: "Tasks found from Google",
  tasks_completed: "Tasks completed",
  memories_saved: "Memories saved",
  grocery_items: "Grocery items",
};
const pct = (v: number | null) => (v == null ? "—" : `${v}%`);

export default function AdminScreen() {
  const { status, user } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const s = useStyles();
  const { colors } = useTheme();
  const [period, setPeriod] = useState<"7" | "30" | "90">("30");
  const [userSearch, setUserSearch] = useState("");
  const [showAll, setShowAll] = useState(false);
  const q = useQuery({ queryKey: ["admin-analytics", period], queryFn: () => api<Analytics>(`/admin/analytics?days=${period}`), enabled: user?.role === "admin" });

  if (status === "signedOut") return <Redirect href="/auth" />;
  if (status === "signedIn" && user?.role !== "admin") return <Redirect href="/home" />;

  const d = q.data;
  return (
    <View style={s.root}>
      <View style={[s.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="admin-back-button" onPress={() => (router.canGoBack() ? router.back() : router.replace("/home"))} style={s.iconBtn} accessibilityLabel="Back">
          <Feather name="chevron-left" size={24} color={colors.onSurface} />
        </Pressable>
        <Text style={s.headerTitle}>Analytics</Text>
        <View style={s.iconBtn} />
      </View>
      <ScrollView
        contentContainerStyle={[s.content, { paddingBottom: insets.bottom + spacing["2xl"] }]}
        refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={q.refetch} tintColor={colors.brandPrimary} />}
      >
        <Segmented options={PERIODS} value={period} onChange={setPeriod} testID="admin-period" />
        {q.isLoading ? (
          <Skeleton rows={5} height={90} />
        ) : q.isError ? (
          <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} testID="admin-error" />
        ) : d ? (
          <>
            <View style={s.grid} testID="admin-kpis">
              <Kpi label="Total users" value={d.totals.users} testID="kpi-users" />
              <Kpi label="Active today" value={d.totals.dau} testID="kpi-dau" />
              <Kpi label="Active 7 days" value={d.totals.wau} testID="kpi-wau" />
              <Kpi label="Active 30 days" value={d.totals.mau} testID="kpi-mau" />
              <Kpi label="New this week" value={d.totals.new_users_7d} testID="kpi-new" />
              <Kpi label="Stickiness" value={`${d.totals.stickiness_pct}%`} hint="daily ÷ monthly" testID="kpi-stickiness" />
            </View>

            <Card title="Daily active users" testID="chart-dau">
              <Bars values={d.series.map((x) => x.active_users)} labels={d.series.map((x) => x.day)} color={colors.brandPrimary} />
            </Card>
            <Card title="Usage per day" subtitle="Sessions (bars) and actions" testID="chart-usage">
              <Bars values={d.series.map((x) => x.sessions)} labels={d.series.map((x) => x.day)} color={colors.brandSecondary} />
              <Text style={s.note}>{`${d.series.reduce((a, x) => a + x.actions, 0)} actions · ${d.totals.sessions} sessions · ${d.totals.sessions_per_active_day} sessions per active user-day`}</Text>
            </Card>
            <Card title="New sign-ups" testID="chart-signups">
              <Bars values={d.series.map((x) => x.new_users)} labels={d.series.map((x) => x.day)} color={colors.warning} />
            </Card>

            <Card title="Engagement & drop-off" subtitle="How long people stay before leaving" testID="admin-dropoff">
              <View style={s.row2}>
                <Mini label="Avg session" value={`${d.totals.avg_session_min} min`} />
                <Mini label="Typical drop-off" value={`${d.totals.median_session_min} min`} />
              </View>
              {d.session_buckets.map((b) => {
                const max = Math.max(1, ...d.session_buckets.map((x) => x.count));
                return (
                  <View key={b.label} style={s.hRow}>
                    <Text style={s.hLabel}>{b.label}</Text>
                    <View style={s.hTrack}><View style={[s.hBar, { width: `${(b.count / max) * 100}%` }]} /></View>
                    <Text style={s.hVal}>{b.count}</Text>
                  </View>
                );
              })}
            </Card>

            <Card title="Busiest hours (UTC)" testID="chart-hours">
              <Bars values={d.hours} labels={d.hours.map((_, i) => `${i}:00`)} color={colors.brandPrimary} compact />
            </Card>

            <Card title="Retention & churn" subtitle={`Churned = no activity for ${d.churn.inactive_days_threshold}+ days`} testID="admin-churn">
              <View style={s.row2}>
                <Mini label="Day-1 retention" value={pct(d.retention.d1_pct)} />
                <Mini label="Day-7 retention" value={pct(d.retention.d7_pct)} />
              </View>
              <View style={s.row2}>
                <Mini label="Day-30 retention" value={pct(d.retention.d30_pct)} />
                <Mini label="Churn rate" value={`${d.churn.churn_rate_pct}%`} warn={d.churn.churn_rate_pct > 30} />
              </View>
              <Text style={s.note}>
                {`${d.churn.churned_users} of ${d.churn.eligible_users} eligible users churned · avg time before churn: ${d.churn.avg_days_before_churn == null ? "—" : `${d.churn.avg_days_before_churn} days`}`}
              </Text>
            </Card>

            <Card title="Feature usage" subtitle={`Last ${d.days} days · ${d.totals.families} families`} testID="admin-features">
              {Object.entries(d.features).map(([k, v]) => (
                <View key={k} style={s.featRow}>
                  <Text style={s.featLabel}>{FEATURE_LABELS[k] ?? k}</Text>
                  <Text style={s.featVal} testID={`feature-${k}`}>{v}</Text>
                </View>
              ))}
            </Card>

            <Card title="Bugs reported" subtitle={`Last ${d.days} days · ${d.bugs.open} still open`} testID="admin-bugs">
              <View style={s.featRow}>
                <Text style={s.featLabel}>Total bug reports</Text>
                <Text style={s.featVal} testID="bugs-total">{d.bugs.total}</Text>
              </View>
              {Object.entries(d.bugs.by_area).map(([k, v]) => (
                <View key={k} style={s.featRow}>
                  <Text style={s.featLabel}>{BUG_AREAS.find((a) => a.key === k)?.label ?? k}</Text>
                  <Text style={s.featVal} testID={`bugs-area-${k}`}>{v}</Text>
                </View>
              ))}
            </Card>

            <Pressable onPress={() => router.push("/admin-usage")} style={s.featRow} testID="admin-open-usage">
              <Text style={[s.featLabel, { color: colors.brandPrimary }]}>AI usage, limits & beta invites →</Text>
            </Pressable>
            <Pressable onPress={() => router.push("/admin-feedback")} style={s.featRow} testID="admin-open-feedback">
              <Text style={[s.featLabel, { color: colors.brandPrimary }]}>Tester feedback inbox →</Text>
            </Pressable>

            <Card title="AI guardrails" subtitle={`Last ${d.days} days · personal-context-only answers`} testID="admin-guardrails">
              {([
                ["AI replies", d.guardrails.responses],
                ["Grounding rate (claims backed by user data)", d.guardrails.grounding_rate === null ? "–" : `${d.guardrails.grounding_rate}%`],
                ["Unsupported claims removed", d.guardrails.unsupported_removed],
                ["Fake sources dropped", d.guardrails.fabricated_sources_dropped],
                ["Answers withheld", d.guardrails.withheld],
                ["Out-of-scope refusals", d.guardrails.refusals_out_of_scope],
                ["Not enough personal info", d.guardrails.insufficient_context],
                ["Secret requests blocked", d.guardrails.secret_blocks],
                ["Clarifying questions", d.guardrails.clarifications],
                ["Validator errors (answer withheld)", d.guardrails.validator_errors],
                ["Latency p50 / p90", d.guardrails.latency_p50_ms === null ? "–" : `${(d.guardrails.latency_p50_ms / 1000).toFixed(1)}s / ${((d.guardrails.latency_p90_ms ?? 0) / 1000).toFixed(1)}s`],
              ] as [string, string | number][]).map(([k, v]) => (
                <View key={k} style={s.featRow}>
                  <Text style={s.featLabel}>{k}</Text>
                  <Text style={s.featVal}>{v}</Text>
                </View>
              ))}
            </Card>

            <Card title={`All users (${d.users.length})`} subtitle={`Usage · sessions in last ${d.days} days`} testID="admin-users">
              <SearchBar value={userSearch} onChangeText={setUserSearch} placeholder="Search name or email" testID="admin-user-search" />
              {d.users
                .filter((u) => !userSearch.trim() || `${u.name} ${u.email}`.toLowerCase().includes(userSearch.trim().toLowerCase()))
                .slice(0, showAll ? undefined : 25)
                .map((u) => (
                  <View key={u.id} style={s.userRow} testID={`admin-user-${u.email}`}>
                    <View style={{ flexDirection: "row", gap: spacing.md, alignItems: "center" }}>
                      <View style={{ flex: 1 }}>
                        <Text style={s.userName} numberOfLines={1}>{u.name || u.email}{u.role === "admin" ? " · developer" : ""}</Text>
                        <Text style={s.userMeta} numberOfLines={1}>{`${u.email} · ${u.sign_in === "google" ? "Google" : "Email"} · joined ${dayjs(u.joined).format("D MMM YYYY")}`}</Text>
                      </View>
                      <View style={{ alignItems: "flex-end" }}>
                        <Text style={s.userVal}>{u.last_active ? relTime(u.last_active) : "never"}</Text>
                        <Text style={s.userMeta}>{`${u.sessions} sessions`}</Text>
                      </View>
                    </View>
                    <Text style={s.userStats}>
                      {`${u.sessions_all_time} sessions total · ${u.tasks} tasks (${u.tasks_completed} done) · ${u.memories} memories · ${u.chats} chats${u.gmail_connected ? " · Gmail ✓" : ""}`}
                    </Text>
                  </View>
                ))}
              {!showAll && d.users.length > 25 && !userSearch ? (
                <Pressable onPress={() => setShowAll(true)} style={{ minHeight: 44, justifyContent: "center" }} testID="admin-users-show-all">
                  <Text style={[s.userName, { color: colors.brandPrimary, textAlign: "center" }]}>{`Show all ${d.users.length} users`}</Text>
                </Pressable>
              ) : null}
            </Card>
            <Text style={s.note}>{`Updated ${relTime(d.generated_at)} · days shown in UTC · demo, developer and test accounts are excluded`}</Text>
          </>
        ) : null}
      </ScrollView>
    </View>
  );

  function Kpi({ label, value, hint, testID }: { label: string; value: number | string; hint?: string; testID: string }) {
    return (
      <View style={s.kpi} testID={testID}>
        <Text style={s.kpiValue}>{value}</Text>
        <Text style={s.kpiLabel}>{label}</Text>
        {hint ? <Text style={s.kpiHint}>{hint}</Text> : null}
      </View>
    );
  }
  function Mini({ label, value, warn }: { label: string; value: string; warn?: boolean }) {
    return (
      <View style={s.mini}>
        <Text style={[s.miniValue, warn && { color: colors.error }]}>{value}</Text>
        <Text style={s.kpiLabel}>{label}</Text>
      </View>
    );
  }
  function Card({ title, subtitle, children, testID }: { title: string; subtitle?: string; children: React.ReactNode; testID: string }) {
    return (
      <View style={s.card} testID={testID}>
        <Text style={s.cardTitle}>{title}</Text>
        {subtitle ? <Text style={s.cardSub}>{subtitle}</Text> : null}
        {children}
      </View>
    );
  }
  function Bars({ values, labels, color, compact }: { values: number[]; labels: string[]; color: string; compact?: boolean }) {
    const max = Math.max(1, ...values);
    const total = values.reduce((a, b) => a + b, 0);
    return (
      <View>
        <View style={s.bars}>
          {values.map((v, i) => (
            <View key={i} style={s.barCol}>
              <View style={[s.bar, { height: `${Math.max(v ? 4 : 1, (v / max) * 100)}%`, backgroundColor: v ? color : colors.border }]} />
            </View>
          ))}
        </View>
        <View style={s.axis}>
          <Text style={s.axisText}>{compact ? labels[0] : dayjs(labels[0]).format("D MMM")}</Text>
          <Text style={s.axisText}>{`peak ${max === 1 && !total ? 0 : max} · total ${total}`}</Text>
          <Text style={s.axisText}>{compact ? labels[labels.length - 1] : dayjs(labels[labels.length - 1]).format("D MMM")}</Text>
        </View>
      </View>
    );
  }
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.sm, paddingBottom: spacing.sm, borderBottomWidth: 1, borderColor: c.divider },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  headerTitle: { flex: 1, textAlign: "center", fontFamily: fonts.displayMedium, fontSize: 20, color: c.onSurface },
  content: { padding: spacing.lg, gap: spacing.lg, maxWidth: 820, width: "100%", alignSelf: "center" },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: spacing.md },
  kpi: { flexGrow: 1, flexBasis: "30%", minWidth: 100, backgroundColor: c.surfaceSecondary, borderRadius: radius.lg, padding: spacing.md, borderWidth: 1, borderColor: c.border },
  kpiValue: { fontFamily: fonts.displayMedium, fontSize: 26, color: c.onSurface },
  kpiLabel: { fontFamily: fonts.textMedium, fontSize: 12, color: c.onSurfaceSecondary },
  kpiHint: { fontFamily: fonts.text, fontSize: 11, color: c.muted },
  card: { backgroundColor: c.surface, borderRadius: radius.lg, padding: spacing.lg, borderWidth: 1, borderColor: c.border, gap: spacing.md },
  cardTitle: { fontFamily: fonts.displayMedium, fontSize: 18, color: c.onSurface },
  cardSub: { fontFamily: fonts.text, fontSize: 12, color: c.muted, marginTop: -spacing.sm },
  bars: { height: 110, flexDirection: "row", alignItems: "flex-end", gap: 2 },
  barCol: { flex: 1, height: "100%", justifyContent: "flex-end" },
  bar: { width: "100%", borderTopLeftRadius: 3, borderTopRightRadius: 3 },
  axis: { flexDirection: "row", justifyContent: "space-between", marginTop: spacing.xs },
  axisText: { fontFamily: fonts.text, fontSize: 11, color: c.muted },
  note: { fontFamily: fonts.text, fontSize: 12, color: c.muted, lineHeight: 18 },
  row2: { flexDirection: "row", gap: spacing.md },
  mini: { flex: 1, backgroundColor: c.surfaceSecondary, borderRadius: radius.md, padding: spacing.md },
  miniValue: { fontFamily: fonts.displayMedium, fontSize: 20, color: c.onSurface },
  hRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  hLabel: { width: 76, fontFamily: fonts.text, fontSize: 12, color: c.onSurfaceSecondary },
  hTrack: { flex: 1, height: 10, borderRadius: 5, backgroundColor: c.surfaceTertiary, overflow: "hidden" },
  hBar: { height: 10, borderRadius: 5, backgroundColor: c.brandSecondary },
  hVal: { width: 32, textAlign: "right", fontFamily: fonts.textMedium, fontSize: 12, color: c.onSurface },
  featRow: { flexDirection: "row", justifyContent: "space-between", minHeight: 36, alignItems: "center", borderBottomWidth: 1, borderColor: c.divider },
  featLabel: { fontFamily: fonts.text, fontSize: 14, color: c.onSurface },
  featVal: { fontFamily: fonts.textMedium, fontSize: 15, color: c.onSurface },
  userRow: { gap: spacing.xs, paddingVertical: spacing.sm, minHeight: 52, borderBottomWidth: 1, borderColor: c.divider },
  userStats: { fontFamily: fonts.text, fontSize: 12, color: c.onSurfaceSecondary },
  userName: { fontFamily: fonts.textMedium, fontSize: 14, color: c.onSurface },
  userMeta: { fontFamily: fonts.text, fontSize: 11, color: c.muted },
  userVal: { fontFamily: fonts.textMedium, fontSize: 12, color: c.onSurface },
}));

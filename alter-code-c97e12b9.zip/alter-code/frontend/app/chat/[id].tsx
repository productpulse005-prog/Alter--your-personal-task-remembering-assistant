import Feather from "@react-native-vector-icons/feather";
import { useQueryClient } from "@tanstack/react-query";
import { Redirect, useLocalSearchParams, useRouter } from "expo-router";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, FlatList, Linking, Platform, Pressable, Text, TextInput, View } from "react-native";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import Animated, { FadeIn } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, ChatAction, isKeyError, Message, streamChat } from "@/src/api";
import { useAuth } from "@/src/auth";
import { ChatMic, MicPhase } from "@/src/components/ChatMic";
import { useToast } from "@/src/components/toast";
import { celebrate } from "@/src/mascot";
import { ErrorState, Skeleton } from "@/src/components/ui";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type UIMessage = Message & { pending?: boolean };

const ACTION_ICON: Record<string, React.ComponentProps<typeof Feather>["name"]> = {
  save_memory: "book-open",
  update_memory: "edit-3",
  forget_memory: "trash-2",
  create_task: "check-square",
  update_task: "check-square",
  delete_task: "trash-2",
};

export default function ChatThread() {
  const params = useLocalSearchParams<{ id: string; prompt?: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const s = useStyles();
  const { colors } = useTheme();
  const qc = useQueryClient();
  const { status: authStatus } = useAuth();
  const [conversationId, setConversationId] = useState<string | null>(params.id && params.id !== "new" ? params.id : null);
  const [title, setTitle] = useState("New conversation");
  const [messages, setMessages] = useState<UIMessage[]>([]);
  const [loading, setLoading] = useState(params.id !== "new");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState<{ text: string; message: string; code?: string } | null>(null);
  const [micPhase, setMicPhase] = useState<MicPhase>("idle");
  const [micError, setMicError] = useState<{ message: string; blocked?: boolean } | null>(null);
  const listRef = useRef<FlatList<UIMessage>>(null);
  const autoSent = useRef(false);

  const load = useCallback(async () => {
    if (!conversationId) return;
    setLoading(true);
    setLoadError(null);
    try {
      const r = await api<{ conversation: { title: string }; messages: Message[] }>(`/conversations/${conversationId}/messages`);
      setTitle(r.conversation.title);
      setMessages(r.messages);
    } catch (e: any) {
      setLoadError(e.message);
    } finally {
      setLoading(false);
    }
  }, [conversationId]);

  useEffect(() => {
    if (params.id !== "new") load();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const invalidate = () => {
    ["dashboard", "tasks", "memories", "conversations"].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
  };

  const send = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text || sending) return;
      setInput("");
      setError(null);
      setSending(true);
      setThinking(true);
      const tempUser: UIMessage = { id: `tmp-u-${Date.now()}`, conversation_id: conversationId ?? "", role: "user", content: text, actions: [], created_at: new Date().toISOString(), pending: true };
      const streamId = `tmp-a-${Date.now()}`;
      setMessages((m) => [...m, tempUser]);
      let gotDone = false;
      let failed: string | null = null;
      let failedCode: string | undefined;
      try {
        const clientId = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
        await streamChat({ conversation_id: conversationId, message: text, client_id: clientId }, (ev) => {
          if (ev.type === "meta") {
            setConversationId(ev.conversation.id);
            setTitle(ev.conversation.title);
            setMessages((m) => m.map((x) => (x.id === tempUser.id ? ev.user_message : x)));
          } else if (ev.type === "actions") {
            if (ev.actions.some((a) => a.type === "update_task" && a.status === "success" && a.data?.status === "completed")) celebrate();
            setMessages((m) => [...m.filter((x) => x.id !== streamId), { id: streamId, conversation_id: "", role: "assistant", content: "", actions: ev.actions, created_at: new Date().toISOString(), pending: true }]);
          } else if (ev.type === "delta") {
            setThinking(false);
            setMessages((m) => {
              const has = m.some((x) => x.id === streamId);
              if (!has) return [...m, { id: streamId, conversation_id: "", role: "assistant", content: ev.content, actions: [], created_at: new Date().toISOString(), pending: true }];
              return m.map((x) => (x.id === streamId ? { ...x, content: x.content + ev.content } : x));
            });
          } else if (ev.type === "done") {
            gotDone = true;
            setMessages((m) => m.map((x) => (x.id === streamId ? ev.message : x)));
          } else if (ev.type === "error") {
            failed = ev.detail;
            failedCode = ev.code;
          }
        });
        if (!gotDone && !failed) failed = "The reply was interrupted. Please try again.";
      } catch (e: any) {
        failed = e.message;
        failedCode = e.code;
      }
      if (failed) {
        setMessages((m) => m.filter((x) => x.id !== tempUser.id && x.id !== streamId && !(x.role === "user" && x.content === text && x === m[m.length - 1])));
        setError({ text, message: failed, code: failedCode });
        setInput(text);
      }
      setThinking(false);
      setSending(false);
      invalidate();
    },
    [conversationId, sending], // eslint-disable-line react-hooks/exhaustive-deps
  );

  useEffect(() => {
    if (params.prompt && params.id === "new" && !autoSent.current) {
      autoSent.current = true;
      send(String(params.prompt));
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const updateAction = (messageId: string, index: number, action: ChatAction) => {
    setMessages((m) => m.map((x) => (x.id === messageId ? { ...x, actions: x.actions.map((a, i) => (i === index ? action : a)) } : x)));
  };

  const newChat = () => router.replace({ pathname: "/chat/[id]", params: { id: "new" } });

  if (authStatus === "signedOut") return <Redirect href="/auth" />;

  return (
    <View style={s.root}>
      <View style={[s.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="chat-back-button" onPress={() => (router.canGoBack() ? router.back() : router.replace("/chats"))} style={s.iconBtn} accessibilityLabel="Back">
          <Feather name="chevron-left" size={24} color={colors.onSurface} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={s.headerTitle} numberOfLines={1} testID="chat-title">{title}</Text>
          <Text style={s.headerSub}>Alter</Text>
        </View>
        <Pressable testID="chat-new-button" onPress={newChat} style={s.iconBtn} accessibilityLabel="New conversation">
          <Feather name="edit-3" size={20} color={colors.onSurface} />
        </Pressable>
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "translate-with-padding"} style={{ flex: 1 }}>
        {loading ? (
          <View style={{ padding: spacing.xl }}><Skeleton rows={4} height={56} /></View>
        ) : loadError ? (
          <ErrorState message={loadError} onRetry={load} testID="chat-load-error" />
        ) : (
          <FlatList
            ref={listRef}
            data={messages}
            keyExtractor={(m) => m.id}
            contentContainerStyle={{ padding: spacing.lg, gap: spacing.md, flexGrow: 1 }}
            onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
            keyboardShouldPersistTaps="handled"
            ListEmptyComponent={
              <View style={s.empty} testID="chat-empty">
                <Text style={s.emptyTitle}>What&apos;s on your mind?</Text>
                <Text style={s.emptyBody}>Alter can answer questions, remember things you tell it, and turn requests into tasks.</Text>
              </View>
            }
            ListFooterComponent={
              thinking ? (
                <View style={s.thinking} testID="chat-thinking">
                  <ActivityIndicator size="small" color={colors.brandPrimary} />
                  <Text style={s.thinkingText}>Alter is thinking…</Text>
                </View>
              ) : null
            }
            renderItem={({ item }) => <Bubble message={item} onActionUpdate={updateAction} />}
          />
        )}

        {error ? (
          <View style={s.errorBar} testID="chat-error">
            <Feather name="alert-circle" size={14} color={colors.error} />
            <Text style={s.errorText} numberOfLines={4}>{error.message}</Text>
            {isKeyError(error.code) && error.code !== "byok_unavailable" ? (
              <Pressable testID="chat-key-settings-button" onPress={() => router.push("/profile")} hitSlop={8}>
                <Text style={s.retry}>AI key settings</Text>
              </Pressable>
            ) : (
              <Pressable testID="chat-retry-button" onPress={() => send(error.text)} disabled={sending} hitSlop={8}>
                <Text style={s.retry}>Retry</Text>
              </Pressable>
            )}
          </View>
        ) : null}

        {micError ? (
          <View style={s.errorBar} testID="chat-mic-error">
            <Feather name="mic-off" size={14} color={colors.error} />
            <Text style={s.errorText} numberOfLines={2}>{micError.message}</Text>
            {micError.blocked ? (
              <Pressable testID="chat-mic-open-settings" onPress={() => Linking.openSettings()} hitSlop={8}>
                <Text style={s.retry}>Open Settings</Text>
              </Pressable>
            ) : (
              <Pressable testID="chat-mic-error-dismiss" onPress={() => setMicError(null)} hitSlop={8}>
                <Feather name="x" size={14} color={colors.muted} />
              </Pressable>
            )}
          </View>
        ) : null}

        <View style={[s.inputBar, { paddingBottom: insets.bottom + spacing.sm }]}>
          <ChatMic
            disabled={sending}
            onPhase={setMicPhase}
            onError={(message, blocked) => setMicError({ message, blocked })}
            onTranscript={(text) => {
              setMicError(null);
              send(input.trim() ? `${input.trim()} ${text}` : text);
            }}
          />
          <TextInput
            testID="chat-input"
            value={input}
            onChangeText={setInput}
            placeholder={micPhase === "listening" ? "Listening… tap stop to send" : micPhase === "transcribing" ? "Transcribing…" : "Message or tap the mic"}
            placeholderTextColor={micPhase === "idle" ? colors.muted : colors.brandPrimary}
            editable={micPhase === "idle"}
            style={s.input}
            multiline
            maxLength={4000}
          />
          <Pressable testID="chat-send-button" onPress={() => send(input)} disabled={!input.trim() || sending} style={[s.sendBtn, (!input.trim() || sending) && { opacity: 0.4 }]}>
            {sending ? <ActivityIndicator size="small" color={colors.onSurfaceInverse} /> : <Feather name="arrow-up" size={18} color={colors.onSurfaceInverse} />}
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

function Bubble({ message, onActionUpdate }: { message: UIMessage; onActionUpdate: (mid: string, i: number, a: ChatAction) => void }) {
  const s = useStyles();
  const { colors } = useTheme();
  const isUser = message.role === "user";
  return (
    <Animated.View entering={FadeIn.duration(250)} style={{ alignItems: isUser ? "flex-end" : "flex-start", gap: spacing.sm }}>
      {message.content ? (
        <View style={[s.bubble, isUser ? s.userBubble : s.botBubble]} testID={`chat-message-${message.role}`}>
          <Text style={[s.bubbleText, isUser && s.userText]} selectable>{message.content.replace(/\*\*(.+?)\*\*/g, "$1")}</Text>
        </View>
      ) : null}
      {!isUser && message.sources?.length ? (
        <View style={s.sources} testID={`chat-sources-${message.id}`}>
          <Text style={s.sourcesTitle}>Based on</Text>
          {message.sources.map((src) => (
            <View key={src.id} style={s.sourceRow}>
              <Feather name={src.type === "memory" ? "bookmark" : src.type === "calendar" ? "calendar" : src.type === "message" ? "message-circle" : src.type === "profile" ? "user" : "check-square"} size={12} color={colors.muted} />
              <Text style={s.sourceText} numberOfLines={1}>{`${src.label}: ${src.text}`}</Text>
            </View>
          ))}
        </View>
      ) : null}
      {message.actions.map((a, i) => (
        <ActionCard key={i} action={a} index={i} messageId={message.id} pending={!!message.pending} onUpdate={onActionUpdate} />
      ))}
    </Animated.View>
  );
}

function ActionCard({ action, index, messageId, pending, onUpdate }: { action: ChatAction; index: number; messageId: string; pending: boolean; onUpdate: (mid: string, i: number, a: ChatAction) => void }) {
  const s = useStyles();
  const { colors } = useTheme();
  const toast = useToast();
  const qc = useQueryClient();
  const [busy, setBusy] = useState<"approve" | "dismiss" | null>(null);
  const ok = action.status === "success" || action.status === "approved";
  const tint = ok ? colors.success : action.status === "pending" ? colors.warning : action.status === "dismissed" ? colors.muted : colors.error;
  const label = action.data?.content || action.data?.title || "";

  const decide = async (decision: "approve" | "dismiss") => {
    setBusy(decision);
    try {
      const r = await api<{ action: ChatAction }>(`/messages/${messageId}/actions/${index}`, { method: "POST", body: { decision } });
      onUpdate(messageId, index, r.action);
      qc.invalidateQueries({ queryKey: ["memories"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      toast(decision === "approve" ? "Saved to memory" : "Suggestion dismissed");
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setBusy(null);
    }
  };

  return (
    <View style={[s.action, { borderLeftColor: tint }]} testID={`chat-action-${action.type}-${action.status}`}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm }}>
        <Feather name={ACTION_ICON[action.type] ?? "zap"} size={14} color={tint} />
        <Text style={[s.actionDetail, { color: tint }]}>{action.detail}</Text>
      </View>
      {label ? <Text style={s.actionLabel}>{label}</Text> : null}
      {action.status === "pending" && !pending ? (
        <View style={{ flexDirection: "row", gap: spacing.sm, marginTop: spacing.xs }}>
          <Pressable testID={`chat-action-approve-${index}`} onPress={() => decide("approve")} style={[s.actBtn, { backgroundColor: colors.brandPrimary }]} disabled={!!busy}>
            {busy === "approve" ? <ActivityIndicator size="small" color={colors.onBrandPrimary} /> : <Text style={[s.actBtnText, { color: colors.onBrandPrimary }]}>Save</Text>}
          </Pressable>
          <Pressable testID={`chat-action-dismiss-${index}`} onPress={() => decide("dismiss")} style={[s.actBtn, { backgroundColor: colors.surfaceTertiary }]} disabled={!!busy}>
            {busy === "dismiss" ? <ActivityIndicator size="small" color={colors.onSurfaceTertiary} /> : <Text style={[s.actBtnText, { color: colors.onSurfaceTertiary }]}>Dismiss</Text>}
          </Pressable>
        </View>
      ) : null}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { flexDirection: "row", alignItems: "center", gap: spacing.xs, paddingHorizontal: spacing.sm, paddingBottom: spacing.sm, borderBottomWidth: 1, borderColor: c.divider, backgroundColor: c.surface },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  headerTitle: { fontFamily: fonts.display, fontSize: 18, color: c.onSurface },
  headerSub: { fontFamily: fonts.text, fontSize: 12, color: c.muted },
  empty: { flex: 1, justifyContent: "center", paddingHorizontal: spacing.lg, gap: spacing.sm },
  emptyTitle: { fontFamily: fonts.display, fontSize: 28, color: c.onSurface },
  emptyBody: { fontFamily: fonts.text, fontSize: 15, color: c.muted, lineHeight: 22 },
  bubble: { maxWidth: "86%", paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderRadius: 18 },
  userBubble: { backgroundColor: c.surfaceInverse, borderBottomRightRadius: radius.sm },
  botBubble: { backgroundColor: c.surfaceSecondary, borderBottomLeftRadius: radius.sm, borderWidth: 1, borderColor: c.border },
  bubbleText: { fontFamily: fonts.text, fontSize: 15, lineHeight: 22, color: c.onSurface },
  userText: { color: c.onSurfaceInverse },
  thinking: { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingVertical: spacing.sm },
  thinkingText: { fontFamily: fonts.text, fontSize: 13, color: c.muted },
  action: { maxWidth: "86%", borderLeftWidth: 3, backgroundColor: c.surface, borderWidth: 1, borderColor: c.border, borderRadius: radius.md, padding: spacing.md, gap: 4 },
  actionDetail: { fontFamily: fonts.textMedium, fontSize: 12, letterSpacing: 0.3 },
  actionLabel: { fontFamily: fonts.display, fontSize: 15, color: c.onSurface, lineHeight: 21 },
  actBtn: { minHeight: 36, paddingHorizontal: spacing.lg, borderRadius: radius.pill, alignItems: "center", justifyContent: "center" },
  actBtnText: { fontFamily: fonts.textMedium, fontSize: 13 },
  errorBar: { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginHorizontal: spacing.lg, marginBottom: spacing.sm, padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: c.error, backgroundColor: c.surface },
  errorText: { flex: 1, fontFamily: fonts.text, fontSize: 13, color: c.error },
  sources: { maxWidth: "85%", gap: 4, paddingHorizontal: spacing.sm, paddingVertical: spacing.xs, borderLeftWidth: 2, borderColor: c.border },
  sourcesTitle: { fontFamily: fonts.textMedium, fontSize: 11, color: c.muted, textTransform: "uppercase", letterSpacing: 0.5 },
  sourceRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  sourceText: { flex: 1, fontFamily: fonts.text, fontSize: 12, color: c.onSurfaceSecondary },
  retry: { fontFamily: fonts.textMedium, fontSize: 13, color: c.brandPrimary },
  inputBar: { flexDirection: "row", alignItems: "flex-end", gap: spacing.sm, paddingHorizontal: spacing.lg, paddingTop: spacing.sm, borderTopWidth: 1, borderColor: c.divider, backgroundColor: c.surface },
  input: { flex: 1, minHeight: 44, maxHeight: 140, borderRadius: 22, borderWidth: 1, borderColor: c.borderStrong, paddingHorizontal: spacing.lg, paddingTop: 12, paddingBottom: 12, fontFamily: fonts.text, fontSize: 15, color: c.onSurface, backgroundColor: c.surface },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: c.surfaceInverse, alignItems: "center", justifyContent: "center" },
}));

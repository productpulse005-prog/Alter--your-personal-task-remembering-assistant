import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Redirect, useRouter } from "expo-router";
import React, { useState } from "react";
import { FlatList, Pressable, RefreshControl, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/api";
import { useAuth } from "@/src/auth";
import { useToast } from "@/src/components/toast";
import { EmptyState, ErrorState, Segmented, Skeleton } from "@/src/components/ui";
import { BUG_AREAS } from "@/src/components/FeedbackSheet";
import { relTime } from "@/src/labels";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Status = "new" | "seen" | "resolved";
type Item = { id: string; kind: "bug" | "idea" | "other"; area?: string | null; message: string; screen: string; platform: string; app_version: string; email: string; name: string; status: Status; created_at: string };
const FILTERS: { key: Status | "all"; label: string }[] = [
  { key: "new", label: "New" },
  { key: "seen", label: "Seen" },
  { key: "resolved", label: "Resolved" },
  { key: "all", label: "All" },
];
const ICON = { bug: "alert-triangle", idea: "zap", other: "message-square" } as const;

export default function AdminFeedback() {
  const { user, status } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const s = useStyles();
  const { colors } = useTheme();
  const qc = useQueryClient();
  const toast = useToast();
  const [filter, setFilter] = useState<Status | "all">("new");
  const q = useQuery({
    queryKey: ["admin-feedback", filter],
    queryFn: () => api<{ items: Item[]; new: number }>(`/admin/feedback${filter === "all" ? "" : `?status=${filter}`}`),
    enabled: user?.role === "admin",
  });

  if (status === "signedOut") return <Redirect href="/auth" />;
  if (status === "signedIn" && user?.role !== "admin") return <Redirect href="/home" />;

  const mark = async (it: Item, next: Status) => {
    try {
      await api(`/admin/feedback/${it.id}`, { method: "PATCH", body: { status: next } });
      qc.invalidateQueries({ queryKey: ["admin-feedback"] });
    } catch (e: any) {
      toast(e.message, "error");
    }
  };

  return (
    <View style={s.root}>
      <View style={[s.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="admin-feedback-back" onPress={() => (router.canGoBack() ? router.back() : router.replace("/admin"))} style={s.iconBtn} accessibilityLabel="Back">
          <Feather name="chevron-left" size={24} color={colors.onSurface} />
        </Pressable>
        <Text style={s.headerTitle}>{`Tester feedback${q.data?.new ? ` · ${q.data.new} new` : ""}`}</Text>
        <View style={s.iconBtn} />
      </View>
      <View style={{ paddingHorizontal: spacing.xl, paddingBottom: spacing.md }}>
        <Segmented options={FILTERS} value={filter} onChange={setFilter} testID="admin-feedback-filter" />
      </View>
      {q.isLoading ? (
        <View style={{ padding: spacing.xl }}><Skeleton rows={4} height={90} /></View>
      ) : q.isError ? (
        <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} testID="admin-feedback-error" />
      ) : (
        <FlatList
          data={q.data?.items ?? []}
          keyExtractor={(it) => it.id}
          contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: insets.bottom + spacing.xl, gap: spacing.md, flexGrow: 1 }}
          refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => q.refetch()} tintColor={colors.brandPrimary} />}
          ListEmptyComponent={<EmptyState icon="inbox" title="No feedback here" body="Notes and bug reports from testers will show up here." testID="admin-feedback-empty" />}
          renderItem={({ item }) => (
            <View style={s.card} testID={`feedback-${item.id}`}>
              <View style={s.row}>
                <Feather name={ICON[item.kind]} size={16} color={item.kind === "bug" ? colors.error : colors.brandSecondary} />
                <Text style={s.who} numberOfLines={1}>{`${item.name || item.email} · ${item.kind}${item.area ? ` · ${BUG_AREAS.find((a) => a.key === item.area)?.label ?? item.area}` : ""}`}</Text>
                <Text style={s.meta}>{relTime(item.created_at)}</Text>
              </View>
              <Text style={s.msg}>{item.message}</Text>
              <Text style={s.meta}>{[item.email, item.screen, item.platform, item.app_version && `v${item.app_version}`].filter(Boolean).join(" · ")}</Text>
              <View style={s.row}>
                {item.status !== "seen" && item.status !== "resolved" ? (
                  <Pressable onPress={() => mark(item, "seen")} style={s.action} testID={`feedback-seen-${item.id}`}><Text style={s.actionText}>Mark seen</Text></Pressable>
                ) : null}
                {item.status !== "resolved" ? (
                  <Pressable onPress={() => mark(item, "resolved")} style={s.action} testID={`feedback-resolve-${item.id}`}><Text style={s.actionText}>Resolve</Text></Pressable>
                ) : (
                  <Pressable onPress={() => mark(item, "new")} style={s.action} testID={`feedback-reopen-${item.id}`}><Text style={s.actionText}>Reopen</Text></Pressable>
                )}
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: spacing.md, paddingBottom: spacing.md },
  headerTitle: { fontFamily: fonts.displayMedium, fontSize: 20, color: c.onSurface },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  card: { backgroundColor: c.surfaceSecondary, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.sm, borderWidth: 1, borderColor: c.border },
  row: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  who: { flex: 1, fontFamily: fonts.textMedium, fontSize: 14, color: c.onSurface },
  meta: { fontFamily: fonts.text, fontSize: 12, color: c.muted },
  msg: { fontFamily: fonts.text, fontSize: 15, lineHeight: 21, color: c.onSurfaceSecondary },
  action: { minHeight: 44, justifyContent: "center", paddingHorizontal: spacing.md, borderRadius: radius.pill, borderWidth: 1, borderColor: c.brandPrimary },
  actionText: { fontFamily: fonts.textMedium, fontSize: 13, color: c.brandPrimary },
}));

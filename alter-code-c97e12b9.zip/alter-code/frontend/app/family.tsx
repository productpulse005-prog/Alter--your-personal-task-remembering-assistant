import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import * as Clipboard from "expo-clipboard";
import { Redirect, useRouter } from "expo-router";
import React, { useState } from "react";
import { Pressable, Share, Text, View } from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, FamilyInfo } from "@/src/api";
import { useAuth } from "@/src/auth";
import { ChoreBoardCard } from "@/src/components/ChoreBoard";
import { useToast } from "@/src/components/toast";
import { Button, ConfirmSheet, ErrorState, Field, Skeleton } from "@/src/components/ui";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

export default function FamilyScreen() {
  const { status, user } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const s = useStyles();
  const { colors } = useTheme();
  const qc = useQueryClient();
  const toast = useToast();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState<null | "create" | "join" | "leave">(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [confirmLeave, setConfirmLeave] = useState(false);
  const q = useQuery({ queryKey: ["family"], queryFn: () => api<FamilyInfo>("/family") });

  if (status === "signedOut") return <Redirect href="/auth" />;

  const after = (data: FamilyInfo) => {
    qc.setQueryData(["family"], data);
    ["groceries", "tasks", "dashboard"].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
  };

  const create = async () => {
    if (!name.trim()) return setErrors({ name: "Give your family a name" });
    setBusy("create");
    setErrors({});
    try {
      after(await api<FamilyInfo>("/family", { method: "POST", body: { name: name.trim() } }));
      toast("Family created — share the code to invite");
    } catch (e: any) {
      setErrors({ name: e.message });
    } finally {
      setBusy(null);
    }
  };

  const join = async () => {
    if (code.trim().length < 4) return setErrors({ code: "Enter the 6-character code" });
    setBusy("join");
    setErrors({});
    try {
      after(await api<FamilyInfo>("/family/join", { method: "POST", body: { code: code.trim().toUpperCase() } }));
      toast("You joined the family");
    } catch (e: any) {
      setErrors({ code: e.message });
    } finally {
      setBusy(null);
    }
  };

  const leave = async () => {
    setBusy("leave");
    try {
      after(await api<FamilyInfo>("/family/leave", { method: "POST" }));
      setConfirmLeave(false);
      toast("You left the family");
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setBusy(null);
    }
  };

  const fam = q.data?.family;
  const share = async () => {
    if (!fam) return;
    try {
      await Share.share({ message: `Join our family "${fam.name}" on Alter to share the grocery list and tasks. Code: ${fam.code}` });
    } catch {
      // user dismissed
    }
  };
  const copy = async () => {
    if (!fam) return;
    await Clipboard.setStringAsync(fam.code);
    toast("Code copied");
  };

  return (
    <View style={s.root}>
      <View style={[s.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="family-back-button" onPress={() => (router.canGoBack() ? router.back() : router.replace("/home"))} style={s.iconBtn} accessibilityLabel="Back">
          <Feather name="chevron-left" size={24} color={colors.onSurface} />
        </Pressable>
        <Text style={s.headerTitle}>Family</Text>
        <View style={s.iconBtn} />
      </View>
      <KeyboardAwareScrollView bottomOffset={24} keyboardShouldPersistTaps="handled" contentContainerStyle={[s.content, { paddingBottom: insets.bottom + spacing["2xl"] }]}>
        {q.isLoading ? (
          <Skeleton rows={3} height={96} />
        ) : q.isError ? (
          <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} testID="family-error" />
        ) : fam ? (
          <>
            <Text style={s.title} testID="family-name">{fam.name}</Text>
            <Text style={s.body}>Members share the grocery list and can assign tasks to each other. Memories and chats stay private.</Text>
            <View style={s.codeCard}>
              <Text style={s.codeLabel}>INVITE CODE</Text>
              <Text style={s.code} testID="family-code" selectable>{fam.code}</Text>
              <View style={{ flexDirection: "row", gap: spacing.md }}>
                <Button label="Copy" variant="secondary" icon="copy" small onPress={copy} testID="family-copy-code" />
                <Button label="Share invite" icon="share-2" small onPress={share} testID="family-share-code" />
              </View>
            </View>
            <ChoreBoardCard />
            <Text style={s.section}>Members</Text>
            {q.data?.members.map((m) => (
              <View key={m.user_id} style={s.member} testID={`family-member-${m.user_id}`}>
                <View style={s.avatar}><Text style={s.avatarText}>{m.display_name[0]?.toUpperCase()}</Text></View>
                <Text style={s.memberName}>{m.display_name}{m.user_id === user?.id ? " (you)" : ""}</Text>
                {m.user_id === fam.owner_id ? <Text style={s.owner}>Owner</Text> : null}
              </View>
            ))}
            <Button label="Leave family" variant="ghost" icon="log-out" onPress={() => setConfirmLeave(true)} testID="family-leave-button" style={{ marginTop: spacing.lg }} />
          </>
        ) : (
          <>
            <Text style={s.title}>Plan together</Text>
            <Text style={s.body}>Create a family to share one grocery list and assign tasks to each other. Others join with your code.</Text>
            <View style={s.card}>
              <Text style={s.cardTitle}>Create a family</Text>
              <Field testID="family-name-input" placeholder="e.g. The Sharmas" value={name} onChangeText={setName} maxLength={60} error={errors.name} />
              <Button label="Create family" onPress={create} loading={busy === "create"} testID="family-create-button" />
            </View>
            <View style={s.card}>
              <Text style={s.cardTitle}>Join with a code</Text>
              <Field testID="family-code-input" placeholder="6-character code" value={code} onChangeText={(t) => setCode(t.toUpperCase())} autoCapitalize="characters" maxLength={12} error={errors.code} />
              <Button label="Join family" variant="secondary" onPress={join} loading={busy === "join"} testID="family-join-button" />
            </View>
          </>
        )}
      </KeyboardAwareScrollView>
      <ConfirmSheet
        visible={confirmLeave}
        title="Leave this family?"
        message="You'll stop seeing the shared grocery list, and tasks assigned between you and others will be unassigned."
        confirmLabel="Leave"
        loading={busy === "leave"}
        onConfirm={leave}
        onClose={() => setConfirmLeave(false)}
        testID="family-leave-confirm"
      />
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.sm, paddingBottom: spacing.sm, borderBottomWidth: 1, borderColor: c.divider },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  headerTitle: { flex: 1, textAlign: "center", fontFamily: fonts.display, fontSize: 20, color: c.onSurface },
  content: { padding: spacing.xl, gap: spacing.lg, maxWidth: 640, width: "100%", alignSelf: "center" },
  title: { fontFamily: fonts.display, fontSize: 30, color: c.onSurface },
  body: { fontFamily: fonts.text, fontSize: 15, color: c.muted, lineHeight: 22 },
  card: { borderWidth: 1, borderColor: c.border, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.md },
  cardTitle: { fontFamily: fonts.display, fontSize: 20, color: c.onSurface },
  codeCard: { backgroundColor: c.surfaceSecondary, borderWidth: 1, borderColor: c.border, borderRadius: radius.lg, padding: spacing.xl, gap: spacing.md, alignItems: "center" },
  codeLabel: { fontFamily: fonts.textMedium, fontSize: 11, letterSpacing: 1.5, color: c.muted },
  code: { fontFamily: fonts.displayMedium, fontSize: 40, letterSpacing: 8, color: c.onSurface },
  section: { fontFamily: fonts.display, fontSize: 20, color: c.onSurface, marginTop: spacing.md },
  member: { flexDirection: "row", alignItems: "center", gap: spacing.md, minHeight: 52, borderBottomWidth: 1, borderColor: c.divider },
  avatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: c.brandTertiary, alignItems: "center", justifyContent: "center" },
  avatarText: { fontFamily: fonts.displayMedium, fontSize: 16, color: c.onBrandTertiary },
  memberName: { flex: 1, fontFamily: fonts.text, fontSize: 16, color: c.onSurface },
  owner: { fontFamily: fonts.textMedium, fontSize: 12, color: c.brandPrimary },
}));

import { useQuery } from "@tanstack/react-query";
import React, { useEffect, useState } from "react";
import { FlatList, Pressable, RefreshControl, Text, View } from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, Memory, MemoryCategory } from "@/src/api";
import { MemorySheet } from "@/src/components/MemorySheet";
import { MemoryFolders } from "@/src/components/MemoryFolders";
import { EmptyState, ErrorState, Fab, SearchBar, Skeleton } from "@/src/components/ui";
import { categoryLabel, relTime } from "@/src/labels";
import { usesNativeTabs } from "@/src/navigation";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

const EMPTY_IMG = require("../../assets/images/alter-logo.png");

export default function MemoryScreen() {
  const insets = useSafeAreaInsets();
  const bottomChrome = usesNativeTabs ? insets.bottom : 0;
  const s = useStyles();
  const { colors } = useTheme();
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [category, setCategory] = useState<MemoryCategory | null>(null);
  const [sheet, setSheet] = useState<{ open: boolean; memory: Memory | null }>({ open: false, memory: null });

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  const params = new URLSearchParams();
  if (debounced) params.set("q", debounced);
  if (category) params.set("category", category);
  const q = useQuery({ queryKey: ["memories", debounced, category], queryFn: () => api<Memory[]>(`/memories?${params.toString()}`) });
  const filtered = !!debounced || !!category;

  return (
    <View style={s.root}>
      <View style={[s.header, { paddingTop: insets.top + spacing.lg }]}>
        <Text style={s.title}>Memory</Text>
        <Text style={s.subtitle}>What Alter knows about you — you decide what stays.</Text>
        <View style={{ marginTop: spacing.md }}>
          <SearchBar value={search} onChangeText={setSearch} placeholder="Search memories" testID="memory-search-input" />
        </View>
      </View>
      <View>
        <MemoryFolders selected={category} onSelect={setCategory} />
      </View>
      {category ? (
        <Text style={s.folderTitle} testID="memory-folder-title">{q.isLoading ? categoryLabel(category) : `${categoryLabel(category)} · ${q.data?.length ?? 0}`}</Text>
      ) : null}
      {q.isLoading ? (
        <View style={{ padding: spacing.xl }}><Skeleton rows={4} height={96} /></View>
      ) : q.isError ? (
        <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} testID="memory-error" />
      ) : (
        <FlatList
          data={q.data}
          keyExtractor={(m) => m.id}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingTop: spacing.sm, paddingBottom: bottomChrome + 96, gap: spacing.md, flexGrow: 1 }}
          refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={q.refetch} tintColor={colors.brandPrimary} />}
          ListEmptyComponent={
            filtered ? (
              <EmptyState icon="search" title="No matches" body="Try another word or category." testID="memory-empty-filtered" />
            ) : (
              <EmptyState image={EMPTY_IMG} title="Your journal is empty." body="Add things you want Alter to remember, or just mention them in chat." cta="Log a memory" onCta={() => setSheet({ open: true, memory: null })} testID="memory-empty" />
            )
          }
          renderItem={({ item, index }) => (
            <Animated.View entering={FadeInDown.delay(Math.min(index, 8) * 40).duration(300)}>
              <Pressable testID={`memory-card-${item.id}`} onPress={() => setSheet({ open: true, memory: item })} style={({ pressed }) => [s.card, pressed && { opacity: 0.8 }]}>
                <View style={s.cardTop}>
                  <Text style={s.cat}>{categoryLabel(item.category).toUpperCase()}</Text>
                  {item.certainty === "inferred" ? <Text style={s.inferred}>Inferred</Text> : null}
                </View>
                <Text style={s.content}>{item.content}</Text>
                <Text style={s.meta}>{`Updated ${relTime(item.updated_at)} · ${item.source === "chat" ? "from chat" : "added by you"}`}</Text>
              </Pressable>
            </Animated.View>
          )}
        />
      )}
      <Fab onPress={() => setSheet({ open: true, memory: null })} testID="memory-add-fab" bottom={bottomChrome + spacing.lg} />
      <MemorySheet visible={sheet.open} memory={sheet.memory} onClose={() => setSheet({ open: false, memory: null })} />
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { paddingHorizontal: spacing.xl, gap: spacing.xs },
  title: { fontFamily: fonts.display, fontSize: 32, color: c.onSurface },
  subtitle: { fontFamily: fonts.text, fontSize: 14, color: c.muted },
  card: { padding: spacing.lg, borderRadius: radius.lg, borderWidth: 1, borderColor: c.border, backgroundColor: c.surface, gap: spacing.sm },
  cardTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cat: { fontFamily: fonts.textMedium, fontSize: 11, letterSpacing: 1.2, color: c.brandPrimary },
  inferred: { fontFamily: fonts.textMedium, fontSize: 11, color: c.warning, borderWidth: 1, borderColor: c.warning, borderRadius: radius.pill, paddingHorizontal: spacing.sm, paddingVertical: 2 },
  content: { fontFamily: fonts.display, fontSize: 18, lineHeight: 26, color: c.onSurface },
  meta: { fontFamily: fonts.text, fontSize: 12, color: c.muted },
  folderTitle: { fontFamily: fonts.display, fontSize: 18, color: c.onSurface, paddingHorizontal: spacing.xl, paddingBottom: spacing.xs },
}));

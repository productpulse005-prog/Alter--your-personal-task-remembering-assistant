import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import dayjs from "dayjs";
import { useFocusEffect } from "expo-router";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Linking, Pressable, RefreshControl, SectionList, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, FamilyInfo, Priority, Task, TaskStatus } from "@/src/api";
import { useNow } from "@/src/clock";
import { ALERT_TASKS_KEY } from "@/src/components/AlertsSync";
import { exactAlarmsAllowed, openAlarmSettings } from "@/src/alarm";
import { GroceryList } from "@/src/components/GroceryList";
import { AssignSheet } from "@/src/components/AssignSheet";
import { TaskHistory } from "@/src/components/TaskHistory";
import { TaskSheet } from "@/src/components/TaskSheet";
import { VoiceSheet } from "@/src/components/VoiceSheet";
import { useAuth } from "@/src/auth";
import { alertsSupported, getNotifPermission, isWeb, PermState, requestNotifPermission, scheduleTestAlarm, syncTaskAlerts, TEST_DELAY_S } from "@/src/notifications";
import { celebrate, MASCOT_WAVE } from "@/src/mascot";
import { useToast } from "@/src/components/toast";
import { Button, Chip, ChipRow, EmptyState, ErrorState, Fab, SearchBar, Segmented, Skeleton } from "@/src/components/ui";
import { formatDue, PRIORITIES, STATUSES } from "@/src/labels";
import { usesNativeTabs } from "@/src/navigation";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Filter = "active" | TaskStatus | "all";
const FILTERS: { key: Filter; label: string }[] = [{ key: "active", label: "Active" }, ...STATUSES, { key: "all", label: "All" }];

export default function TasksScreen() {
  const insets = useSafeAreaInsets();
  const bottomChrome = usesNativeTabs ? insets.bottom : 0;
  const s = useStyles();
  const { colors } = useTheme();
  const qc = useQueryClient();
  const toast = useToast();
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [filter, setFilter] = useState<Filter>("active");
  const [priority, setPriority] = useState<Priority | null>(null);
  const [sheet, setSheet] = useState<{ open: boolean; task: Task | null }>({ open: false, task: null });
  const [view, setView] = useState<"tasks" | "history" | "groceries">("tasks");
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [assignTask, setAssignTask] = useState<Task | null>(null);
  const [mineAssigned, setMineAssigned] = useState(false);
  const { user } = useAuth();
  const family = useQuery({ queryKey: ["family"], queryFn: () => api<FamilyInfo>("/family") });
  const members = family.data?.members ?? [];
  const canAssign = members.some((m) => m.user_id !== user?.id);
  const [perm, setPerm] = useState<PermState>("unsupported");
  const [alarmsOk, setAlarmsOk] = useState(true);
  const prioColor = (p: Priority) => (p === "urgent" ? colors.error : p === "high" ? colors.warning : p === "medium" ? colors.brandSecondary : colors.muted);
  useNow(); // re-render as time passes so "Today"/"Overdue" labels stay correct

  useFocusEffect(useCallback(() => {
    getNotifPermission().then(setPerm).catch(() => {});
    exactAlarmsAllowed().then(setAlarmsOk).catch(() => {});
    // quietly pull new to-dos from the user's connected Gmail (server rate-limits this)
    api<{ added: number }>("/gmail/sync", { method: "POST" })
      .then((r) => {
        if (r.added) {
          qc.invalidateQueries({ queryKey: ["tasks"] });
          toast(`Added ${r.added} task${r.added === 1 ? "" : "s"} from Google`);
        }
      })
      .catch(() => {});
  }, [qc, toast]));

  const enableAlerts = async () => {
    if (perm === "blocked" && isWeb) return toast("Allow notifications for this site: click the lock icon in the address bar → Notifications → Allow", "error");
    if (perm === "blocked") return Linking.openSettings();
    const next = await requestNotifPermission();
    setPerm(next);
    if (next === "granted") {
      // alarms only for my own / assigned-to-me tasks, never other members' plans
      const mine = (q.data ?? []).filter((t) => t.user_id === user?.id || t.assigned_to === user?.id);
      const n = await syncTaskAlerts(qc.getQueryData<Task[]>(ALERT_TASKS_KEY) ?? mine, true);
      toast(`Alarms on${n ? ` · ${n} scheduled` : ""}`);
    }
  };

  const [testing, setTesting] = useState(false);
  const google = useQuery({ queryKey: ["gmail-status"], queryFn: () => api<{ connected: boolean }>("/gmail/status") });
  const [syncing, setSyncing] = useState(false);
  const syncNow = async () => {
    setSyncing(true);
    try {
      const r = await api<{ added: number; from_calendar?: number; skipped?: string; error?: string }>("/gmail/sync?force=true", { method: "POST" });
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      if (r.skipped === "recent" || r.skipped === "busy") toast("Just synced. Try again in a few seconds");
      else if (r.error) toast(r.error, "error");
      else toast(r.added ? `Added ${r.added} new task${r.added === 1 ? "" : "s"} from Google` : "You're up to date. No new events");
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setSyncing(false);
    }
  };
  const testAlarm = async () => {
    let p = perm;
    if (p === "undetermined" || p === "denied") {
      p = await requestNotifPermission();
      setPerm(p);
    }
    if (p !== "granted" && !isWeb) return Linking.openSettings();
    try {
      await scheduleTestAlarm();
      setTesting(true);
      setTimeout(() => setTesting(false), TEST_DELAY_S * 1000);
      toast(!isWeb
        ? `Alarm rings in ${TEST_DELAY_S} seconds. You can lock the phone or leave Alter.`
        : p === "granted"
          ? `Alarm rings in ${TEST_DELAY_S} seconds. Keep this tab open.`
          : `Alarm rings in ${TEST_DELAY_S} seconds in this tab. Allow browser notifications to also get a pop-up.`);
    } catch (e: any) {
      toast(e.message ?? "Couldn't set the test alarm", "error");
    }
  };

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  const params = new URLSearchParams();
  if (debounced) params.set("q", debounced);
  if (filter !== "active" && filter !== "all") params.set("status", filter);
  if (priority) params.set("priority", priority);
  params.set("include_family", "true"); // family members' upcoming, non-confidential plans (view only)
  const q = useQuery({ queryKey: ["tasks", debounced, filter, priority], queryFn: () => api<Task[]>(`/tasks?${params.toString()}`) });

  const sections = useMemo(() => {
    const list = (q.data ?? [])
      .filter((t) => (filter === "active" ? t.status !== "completed" : true))
      .filter((t) => !mineAssigned || (t.user_id === user?.id && !!t.assigned_to && t.assigned_to !== user?.id));
    const today = dayjs().format("YYYY-MM-DD");
    const tomorrow = dayjs().add(1, "day").format("YYYY-MM-DD");
    const rank = (p: Priority) => PRIORITIES.findIndex((x) => x.key === p);
    const byPriority = (a: Task, b: Task) => rank(a.priority) - rank(b.priority) || (a.due_time ?? "99:99").localeCompare(b.due_time ?? "99:99");
    const groups = [
      { key: "today", title: "Today", data: list.filter((t) => t.due_date && t.due_date <= today) }, // overdue stays in Today
      { key: "tomorrow", title: "Tomorrow", data: list.filter((t) => t.due_date === tomorrow) },
      { key: "later", title: "Later", data: list.filter((t) => !t.due_date || t.due_date > tomorrow) },
    ];
    return groups.map((g) => ({ ...g, data: [...g.data].sort(byPriority) })).filter((g) => g.data.length);
  }, [q.data, filter, mineAssigned, user?.id]);

  const toggle = async (t: Task) => {
    const next: TaskStatus = t.status === "completed" ? "todo" : "completed";
    try {
      await api(`/tasks/${t.id}`, { method: "PUT", body: { status: next } });
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      qc.invalidateQueries({ queryKey: ["summary"] });
      if (next === "completed") celebrate(t.due_date);
      toast(next === "completed" ? "Task completed" : "Task reopened");
    } catch (e: any) {
      toast(e.message, "error");
    }
  };

  const filtered = !!debounced || filter !== "active" || !!priority || mineAssigned;

  return (
    <View style={s.root}>
      <View style={[s.header, { paddingTop: insets.top + spacing.lg }]}>
        <View style={s.titleRow}>
          <Text style={s.title}>{view === "groceries" ? "Groceries" : view === "history" ? "History" : "Tasks"}</Text>
          <Button label="Speak" icon="mic" small onPress={() => setVoiceOpen(true)} testID="tasks-speak-button" />
        </View>
        <View style={{ marginTop: spacing.md }}>
          <Segmented options={[{ key: "tasks" as const, label: "Tasks" }, { key: "history" as const, label: "History" }, { key: "groceries" as const, label: "Groceries" }]} value={view} onChange={setView} testID="tasks-view" />
        </View>
        {view === "tasks" ? (
          <View style={{ marginTop: spacing.md }}>
            <SearchBar value={search} onChangeText={setSearch} placeholder="Search tasks" testID="tasks-search-input" />
          </View>
        ) : null}
        {view === "tasks" && (perm === "undetermined" || perm === "denied" || perm === "blocked") ? (
          <View style={s.alertCard} testID="tasks-alerts-banner">
            <Feather name="bell" size={16} color={colors.onBrandTertiary} />
            <Text style={s.alertText}>{perm === "blocked" ? (isWeb ? "Notifications are blocked for this site. Allow them in your browser to get reminders on your screen." : "Alerts are off. Enable notifications in Settings to get task reminders and alarms.") : isWeb ? "Turn on desktop notifications: reminders 2 h, 1 h and 5 min before, plus an alarm on time (keep Alter open in a tab)." : "Turn on reminders 2 h, 1 h and 5 min before, plus an alarm right on time."}</Text>
            <Pressable onPress={enableAlerts} testID="tasks-enable-alerts" hitSlop={8}>
              <Text style={s.alertBtn}>{perm === "blocked" ? (isWeb ? "How to allow" : "Open Settings") : "Turn on"}</Text>
            </Pressable>
          </View>
        ) : null}
        {view === "tasks" && perm === "granted" && !alarmsOk ? (
          <View style={s.alertCard} testID="tasks-exact-alarm-banner">
            <Feather name="alert-triangle" size={16} color={colors.onBrandTertiary} />
            <Text style={s.alertText}>{"Alarms are switched off for Alter on this phone, so they can ring late. Turn on \"Alarms & reminders\" for Alter."}</Text>
            <Pressable onPress={() => openAlarmSettings().catch(() => Linking.openSettings())} testID="tasks-open-alarm-settings" hitSlop={8}>
              <Text style={s.alertBtn}>Allow</Text>
            </Pressable>
          </View>
        ) : null}
        <View style={s.toolRow}>
        {view === "tasks" && google.data?.connected ? (
          <Pressable onPress={syncNow} disabled={syncing} testID="tasks-sync-calendar" style={({ pressed }) => [s.testBtn, (pressed || syncing) && { opacity: 0.6 }]} accessibilityRole="button">
            <Feather name="refresh-cw" size={15} color={colors.brandPrimary} />
            <Text style={s.testText}>{syncing ? "Syncing…" : "Sync calendar now"}</Text>
          </Pressable>
        ) : null}
        {view === "tasks" && alertsSupported ? (
          <Pressable onPress={testAlarm} disabled={testing} testID="tasks-test-alarm" style={({ pressed }) => [s.testBtn, (pressed || testing) && { opacity: 0.6 }]} accessibilityRole="button">
            <Feather name="bell" size={15} color={colors.brandPrimary} />
            <Text style={s.testText}>{testing ? `Ringing in ${TEST_DELAY_S} seconds…` : "Test my alarm"}</Text>
          </Pressable>
        ) : null}
        </View>
      </View>
      {view === "history" ? (
        <TaskHistory bottomPadding={bottomChrome + spacing.xl} onOpen={(t) => setSheet({ open: true, task: t })} />
      ) : view === "groceries" ? (
        <View style={{ flex: 1, paddingTop: spacing.lg }}>
          <GroceryList bottomPadding={bottomChrome + spacing.xl} onSpeak={() => setVoiceOpen(true)} />
        </View>
      ) : (
      <>
      <ChipRow>
        {FILTERS.map((f) => (
          <Chip key={f.key} label={f.label} selected={filter === f.key} onPress={() => setFilter(f.key)} testID={`tasks-filter-${f.key}`} />
        ))}
        {canAssign ? (
          <Chip label="I assigned" icon="send" selected={mineAssigned} onPress={() => setMineAssigned(!mineAssigned)} testID="tasks-filter-assigned-by-me" />
        ) : null}
        <View style={s.sep} />
        {PRIORITIES.map((p) => (
          <Chip key={p.key} label={p.label} icon="flag" selected={priority === p.key} onPress={() => setPriority(priority === p.key ? null : p.key)} testID={`tasks-priority-${p.key}`} />
        ))}
      </ChipRow>
      {q.isLoading ? (
        <View style={{ padding: spacing.xl }}><Skeleton rows={5} height={56} /></View>
      ) : q.isError ? (
        <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} testID="tasks-error" />
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(t) => t.id}
          stickySectionHeadersEnabled={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: bottomChrome + 96, flexGrow: 1 }}
          refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={q.refetch} tintColor={colors.brandPrimary} />}
          ListEmptyComponent={
            filtered ? (
              <EmptyState icon="search" title="No matching tasks" body="Try a different filter or search." testID="tasks-empty-filtered" />
            ) : (
              <EmptyState image={MASCOT_WAVE} title="No tasks at the moment." body="Add one here, or ask Alter in chat to track something for you." cta="Add a task" onCta={() => setSheet({ open: true, task: null })} testID="tasks-empty" />
            )
          }
          renderSectionHeader={({ section }) => <Text style={s.sectionTitle}>{section.title}</Text>}
          renderItem={({ item }) => {
            const due = formatDue(item);
            const done = item.status === "completed";
            return (
              <Pressable testID={`task-row-${item.id}`} onPress={() => setSheet({ open: true, task: item })} style={({ pressed }) => [s.row, pressed && { opacity: 0.7 }]}>
                {item.user_id !== user?.id && item.assigned_to !== user?.id ? (
                  <View style={[s.check, { borderStyle: "dashed" }]} testID={`task-family-${item.id}`}>
                    <Feather name="users" size={12} color={colors.muted} />
                  </View>
                ) : (
                <Pressable testID={`task-toggle-${item.id}`} onPress={() => toggle(item)} hitSlop={8} style={[s.check, done && { backgroundColor: colors.brandPrimary, borderColor: colors.brandPrimary }]} accessibilityRole="checkbox" accessibilityState={{ checked: done }}>
                  {done ? <Feather name="check" size={14} color={colors.onBrandPrimary} /> : null}
                </Pressable>
                )}
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={[s.rowTitle, done && s.done]} numberOfLines={2}>{item.title}</Text>
                  <View style={{ flexDirection: "row", gap: spacing.sm, alignItems: "center", flexWrap: "wrap" }}>
                    <View style={[s.prio, { backgroundColor: prioColor(item.priority) }]} testID={`task-priority-tag-${item.id}`}>
                      <Text style={[s.prioText, item.priority !== "urgent" && { color: colors.onSurface }]}>{PRIORITIES.find((p) => p.key === item.priority)?.label}</Text>
                    </View>
                    {item.alarm ? (
                      <View style={s.alarmTag} testID={`task-alarm-tag-${item.id}`}>
                        <Feather name="bell" size={11} color={colors.brandPrimary} />
                        <Text style={s.alarmText}>{item.recurrence ? `Alarm · ${item.recurrence === "weekdays" ? "weekdays" : item.recurrence}` : "Alarm"}</Text>
                      </View>
                    ) : null}
                    {due ? <Text style={[s.due, due.overdue && !done && { color: colors.error }]}>{due.label}</Text> : null}
                    {item.source === "chat" ? <Feather name="message-circle" size={12} color={colors.muted} /> : null}
                    {item.source === "voice" ? <Feather name="mic" size={12} color={colors.muted} /> : null}
                    {item.source === "gmail" ? <Feather name="inbox" size={12} color={colors.muted} testID={`task-gmail-badge-${item.id}`} /> : null}
                    {item.source === "calendar" ? <Feather name="calendar" size={12} color={colors.muted} testID={`task-calendar-badge-${item.id}`} /> : null}
                    {item.assigned_to && item.assigned_to !== user?.id ? <Text style={s.assignee}>{`→ ${item.assigned_to_name}`}</Text> : null}
                    {item.assigned_to === user?.id && item.user_id !== user?.id ? <Text style={s.assignee}>{`From ${item.owner_name}`}</Text> : null}
                    {item.user_id !== user?.id && item.assigned_to !== user?.id ? <Text style={s.assignee}>{`${item.owner_name}'s plan`}</Text> : null}
                    {item.confidential ? <Feather name="lock" size={12} color={colors.muted} testID={`task-confidential-${item.id}`} /> : null}
                  </View>
                </View>
                {canAssign && item.user_id === user?.id && !done ? (
                  <Pressable
                    testID={`task-assign-${item.id}`}
                    onPress={() => setAssignTask(item)}
                    hitSlop={6}
                    style={({ pressed }) => [s.assignBtn, !!item.assigned_to && s.assignBtnActive, pressed && { opacity: 0.7 }]}
                    accessibilityLabel={item.assigned_to ? `Assigned to ${item.assigned_to_name}. Change` : "Assign to a family member"}
                  >
                    <Feather name="user-plus" size={14} color={item.assigned_to ? colors.onBrandPrimary : colors.brandPrimary} />
                    <Text style={[s.assignText, !!item.assigned_to && { color: colors.onBrandPrimary }]} numberOfLines={1}>
                      {item.assigned_to ? item.assigned_to_name?.split(" ")[0] : "Assign"}
                    </Text>
                  </Pressable>
                ) : (
                  <Feather name="chevron-right" size={18} color={colors.borderStrong} />
                )}
              </Pressable>
            );
          }}
        />
      )}
      <Fab onPress={() => setSheet({ open: true, task: null })} testID="tasks-add-fab" bottom={bottomChrome + spacing.lg} />
      </>
      )}
      <VoiceSheet visible={voiceOpen} onClose={() => setVoiceOpen(false)} />
      <AssignSheet task={assignTask} members={members} meId={user?.id ?? ""} onClose={() => setAssignTask(null)} />
      <TaskSheet visible={sheet.open} task={sheet.task} onClose={() => setSheet({ open: false, task: null })} />
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { paddingHorizontal: spacing.xl },
  title: { fontFamily: fonts.display, fontSize: 32, color: c.onSurface },
  titleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  alertCard: { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginTop: spacing.md, padding: spacing.md, borderRadius: radius.md, backgroundColor: c.brandTertiary },
  alertText: { flex: 1, fontFamily: fonts.text, fontSize: 13, color: c.onBrandTertiary, lineHeight: 18 },
  testBtn: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 6, minHeight: 44, marginTop: spacing.sm, paddingHorizontal: spacing.md, borderRadius: radius.pill, borderWidth: 1, borderColor: c.brandPrimary },
  toolRow: { flexDirection: "row", flexWrap: "wrap", columnGap: spacing.sm },
  testText: { fontFamily: fonts.textMedium, fontSize: 13, color: c.brandPrimary },
  alertBtn: { fontFamily: fonts.textMedium, fontSize: 13, color: c.brandPrimary },
  assignBtn: { flexDirection: "row", alignItems: "center", gap: 4, minHeight: 32, maxWidth: 110, paddingHorizontal: spacing.sm, borderRadius: radius.pill, borderWidth: 1, borderColor: c.brandPrimary },
  assignBtnActive: { backgroundColor: c.brandPrimary },
  assignText: { fontFamily: fonts.textMedium, fontSize: 12, color: c.brandPrimary },
  assignee: { fontFamily: fonts.textMedium, fontSize: 12, color: c.brandSecondary },
  sep: { width: 1, height: 20, backgroundColor: c.borderStrong, marginHorizontal: spacing.xs },
  sectionTitle: { fontFamily: fonts.display, fontSize: 18, color: c.onSurfaceSecondary, marginTop: spacing.xl, marginBottom: spacing.xs },
  row: { minHeight: 60, flexDirection: "row", alignItems: "center", gap: spacing.md, paddingVertical: spacing.md, borderBottomWidth: 1, borderColor: c.divider },
  check: { width: 24, height: 24, borderRadius: 12, borderWidth: 1.5, borderColor: c.borderStrong, alignItems: "center", justifyContent: "center" },
  rowTitle: { fontFamily: fonts.text, fontSize: 16, color: c.onSurface },
  done: { textDecorationLine: "line-through", color: c.muted },
  due: { fontFamily: fonts.textMedium, fontSize: 12, color: c.muted },
  prio: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: radius.pill },
  prioText: { fontFamily: fonts.textMedium, fontSize: 11, color: c.onBrandPrimary },
  alarmTag: { flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 8, paddingVertical: 2, borderRadius: radius.pill, borderWidth: 1, borderColor: c.brandPrimary },
  alarmText: { fontFamily: fonts.textMedium, fontSize: 11, color: c.brandPrimary },
}));

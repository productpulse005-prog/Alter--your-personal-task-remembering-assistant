import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Image } from "expo-image";
import { useFocusEffect, useRouter } from "expo-router";
import React, { useCallback, useState } from "react";
import { Pressable, RefreshControl, ScrollView, Text, View } from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, Dashboard, Memory, Task } from "@/src/api";
import { useNow } from "@/src/clock";
import dayjs from "dayjs";
import { DailySummary } from "@/src/components/DailySummary";
import { FeedbackSheet } from "@/src/components/FeedbackSheet";
import { MemorySheet } from "@/src/components/MemorySheet";
import { QuickTask } from "@/src/components/QuickTask";
import { TaskSheet } from "@/src/components/TaskSheet";
import { VoiceSheet } from "@/src/components/VoiceSheet";
import { MASCOT_WAVE } from "@/src/mascot";
import { ErrorState, Skeleton } from "@/src/components/ui";
import { formatDue } from "@/src/labels";
import { usesNativeTabs } from "@/src/navigation";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

const LOGO = require("../../assets/images/alter-logo.png");

function hello(now: Date) {
  const h = now.getHours();
  return h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

export default function Home() {
  const insets = useSafeAreaInsets();
  const bottomChrome = usesNativeTabs ? insets.bottom : 0;
  const s = useStyles();
  const { colors } = useTheme();
  const router = useRouter();
  const [taskSheet, setTaskSheet] = useState<{ open: boolean; task: Task | null; title?: string }>({ open: false, task: null });
  const [memSheet, setMemSheet] = useState<{ open: boolean; memory: Memory | null }>({ open: false, memory: null });
  const [voiceOpen, setVoiceOpen] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);

  const q = useQuery({ queryKey: ["dashboard"], queryFn: () => api<Dashboard>("/dashboard") });
  const qc = useQueryClient();
  // tasks change from chat, voice, the Tasks tab or alarms -> refresh counts and the day summary on return
  useFocusEffect(useCallback(() => { q.refetch(); qc.invalidateQueries({ queryKey: ["summary"] }); }, [q.refetch, qc])); // eslint-disable-line react-hooks/exhaustive-deps
  const now = useNow();
  const dayKey = dayjs(now).format("YYYY-MM-DD");
  // a new day (e.g. past midnight, or app reopened) -> refresh "today"
  React.useEffect(() => { if (q.data && q.data.today !== dayKey) q.refetch(); }, [dayKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const d = q.data;
  const name = d?.profile.display_name ?? "";
  const todays = (d?.upcoming ?? []).filter((t) => t.due_date && t.due_date <= d!.today);
  const list = todays.length ? todays : d?.upcoming ?? [];

  return (
    <View style={s.root}>
      <ScrollView
        contentContainerStyle={{ paddingTop: insets.top + spacing.md, paddingBottom: bottomChrome + spacing.xl, paddingHorizontal: spacing.xl, gap: spacing.xl }}
        keyboardShouldPersistTaps="handled"
        refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={q.refetch} tintColor={colors.brandPrimary} />}
      >
        <View style={s.topRow}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm }}>
            <Image source={LOGO} style={s.logo} contentFit="cover" testID="home-logo" />
            <Text style={s.brand}>Alter</Text>
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm }}>
          <Pressable testID="home-feedback-button" onPress={() => setFeedbackOpen(true)} style={s.feedbackBtn} accessibilityLabel="Send feedback">
            <Feather name="message-square" size={16} color={colors.brandPrimary} />
            <Text style={s.feedbackText}>Feedback</Text>
          </Pressable>
          <Pressable testID="home-profile-button" onPress={() => router.push("/profile")} style={s.avatar} accessibilityLabel="Profile">
            <Text style={s.avatarText}>{(name[0] ?? "·").toUpperCase()}</Text>
          </Pressable>
          </View>
        </View>

        <View style={{ gap: 4 }}>
          <Text style={s.greeting} testID="home-greeting">{d ? `${hello(now)}, ${name}!` : " "}</Text>
          <Text style={s.sub} testID="home-datetime">{dayjs(now).format("dddd, D MMMM · h:mm A")}</Text>
          <Text style={s.sub}>What can I help you with today?</Text>
        </View>

        <QuickTask onSpeak={() => setVoiceOpen(true)} />

        <View style={s.actions}>
          <QuickAction icon="clock" label="Task with time" onPress={() => setTaskSheet({ open: true, task: null })} testID="home-add-task" />
          <QuickAction icon="heart" label="Memory" onPress={() => setMemSheet({ open: true, memory: null })} testID="home-add-memory" />
          <QuickAction icon="message-circle" label="Chat" onPress={() => router.push({ pathname: "/chat/[id]", params: { id: "new" } })} testID="home-new-chat" />
        </View>

        {q.isLoading ? (
          <Skeleton rows={3} />
        ) : q.isError ? (
          <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} testID="home-error" />
        ) : d ? (
          <Animated.View entering={FadeInDown.duration(400)} style={{ gap: spacing.xl }}>
            <DailySummary />
            <View style={s.card} testID="home-today">
              <View style={s.sectionHead}>
                <Text style={s.sectionTitle}>{todays.length ? "Today" : "Coming up"}</Text>
                <Pressable onPress={() => router.push("/tasks")} hitSlop={12} testID="home-today-link">
                  <Text style={s.sectionLink}>All tasks</Text>
                </Pressable>
              </View>
              {list.length ? (
                list.map((t) => <TaskLine key={t.id} task={t} today={d.today} onPress={() => setTaskSheet({ open: true, task: t })} />)
              ) : (
                <View style={{ alignItems: "center", gap: spacing.sm, paddingVertical: spacing.sm }} testID="home-all-clear">
                  <Image source={MASCOT_WAVE} style={{ width: 120, height: 120, borderRadius: 28 }} contentFit="cover" />
                  <Text style={s.hintText}>All clear! Tap the mic to add something.</Text>
                </View>
              )}
            </View>

            {d.family_upcoming?.length ? (
              <View style={s.card} testID="home-family-plans">
                <View style={s.sectionHead}>
                  <Text style={s.sectionTitle}>Family plans</Text>
                  <Feather name="users" size={18} color={colors.brandSecondary} />
                </View>
                {d.family_upcoming.map((t) => (
                  <Pressable key={t.id} testID={`home-family-task-${t.id}`} onPress={() => setTaskSheet({ open: true, task: t })} style={s.taskLine}>
                    <Text style={s.owner} numberOfLines={1}>{t.owner_name.split(" ")[0]}</Text>
                    <Text style={s.taskTitle} numberOfLines={1}>{t.title}</Text>
                    <Text style={s.taskDue}>{formatDue(t, d.today)?.label}</Text>
                  </Pressable>
                ))}
              </View>
            ) : null}

            <View style={{ flexDirection: "row", gap: spacing.md }}>
              <Pressable testID="home-grocery-card" onPress={() => router.push("/tasks")} style={[s.miniCard, { backgroundColor: colors.peach }]}>
                <Feather name="shopping-cart" size={20} color={colors.onSurface} />
                <Text style={s.miniValue}>{d.counts.groceries}</Text>
                <Text style={s.miniLabel}>{d.counts.groceries === 1 ? "grocery item" : "grocery items"}</Text>
              </Pressable>
              <Pressable testID="home-family-card" onPress={() => router.push("/family")} style={[s.miniCard, { backgroundColor: colors.brandTertiary }]}>
                <Feather name="users" size={20} color={colors.onBrandTertiary} />
                <Text style={s.miniValue} numberOfLines={1}>{d.family ? d.family.name : "Family"}</Text>
                <Text style={s.miniLabel}>{d.family ? "Shared list & chores" : "Invite with a code"}</Text>
              </Pressable>
            </View>
          </Animated.View>
        ) : null}
      </ScrollView>
      <FeedbackSheet visible={feedbackOpen} onClose={() => setFeedbackOpen(false)} />
      <VoiceSheet visible={voiceOpen} onClose={() => setVoiceOpen(false)} />
      <TaskSheet visible={taskSheet.open} task={taskSheet.task} initialTitle={taskSheet.title} onClose={() => setTaskSheet({ open: false, task: null })} />
      <MemorySheet visible={memSheet.open} memory={memSheet.memory} onClose={() => setMemSheet({ open: false, memory: null })} />
    </View>
  );
}

function QuickAction({ icon, label, onPress, testID }: { icon: React.ComponentProps<typeof Feather>["name"]; label: string; onPress: () => void; testID: string }) {
  const s = useStyles();
  const { colors } = useTheme();
  return (
    <Pressable testID={testID} onPress={onPress} style={({ pressed }) => [s.qa, pressed && { opacity: 0.7 }]}>
      <Feather name={icon} size={16} color={colors.onBrandTertiary} />
      <Text style={s.qaText}>{label}</Text>
    </Pressable>
  );
}

function TaskLine({ task, today, onPress }: { task: Task; today: string; onPress: () => void }) {
  const s = useStyles();
  const { colors } = useTheme();
  const due = formatDue(task, today);
  return (
    <Pressable testID={`home-task-${task.id}`} onPress={onPress} style={s.taskLine}>
      <View style={[s.dot, { backgroundColor: task.priority === "urgent" ? colors.error : task.priority === "high" ? colors.warning : task.priority === "medium" ? colors.brandSecondary : colors.borderStrong }]} />
      <Text style={s.taskTitle} numberOfLines={1}>{task.title}</Text>
      {due ? <Text style={[s.taskDue, due.overdue && { color: colors.error }]}>{due.label}</Text> : null}
    </Pressable>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  logo: { width: 44, height: 44, borderRadius: 14 },
  brand: { fontFamily: fonts.displayMedium, fontSize: 24, color: c.onSurface },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: c.brandTertiary, alignItems: "center", justifyContent: "center" },
  feedbackBtn: { flexDirection: "row", alignItems: "center", gap: 6, height: 44, paddingHorizontal: spacing.md, borderRadius: radius.pill, borderWidth: 1, borderColor: c.border, backgroundColor: c.surfaceSecondary },
  feedbackText: { fontFamily: fonts.textMedium, fontSize: 13, color: c.brandPrimary },
  avatarText: { fontFamily: fonts.displayMedium, fontSize: 18, color: c.onBrandTertiary },
  greeting: { fontFamily: fonts.displayMedium, fontSize: 30, lineHeight: 38, color: c.onSurface },
  sub: { fontFamily: fonts.text, fontSize: 16, color: c.muted },
  actions: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm, justifyContent: "center" },
  qa: { flexDirection: "row", alignItems: "center", gap: 6, height: 44, paddingHorizontal: spacing.md, borderRadius: radius.pill, backgroundColor: c.brandTertiary },
  qaText: { fontFamily: fonts.textMedium, fontSize: 14, color: c.onBrandTertiary },
  card: { backgroundColor: c.surfaceSecondary, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.xs, borderWidth: 1, borderColor: c.border },
  sectionHead: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: spacing.xs },
  sectionTitle: { fontFamily: fonts.displayMedium, fontSize: 20, color: c.onSurface },
  sectionLink: { fontFamily: fonts.textMedium, fontSize: 13, color: c.brandPrimary },
  taskLine: { minHeight: 48, flexDirection: "row", alignItems: "center", gap: spacing.md },
  dot: { width: 10, height: 10, borderRadius: 5 },
  taskTitle: { flex: 1, fontFamily: fonts.text, fontSize: 15, color: c.onSurface },
  owner: { minWidth: 56, maxWidth: 80, fontFamily: fonts.textMedium, fontSize: 12, color: c.brandSecondary },
  taskDue: { fontFamily: fonts.textMedium, fontSize: 12, color: c.muted },
  miniCard: { flex: 1, padding: spacing.lg, borderRadius: radius.lg, gap: 4 },
  miniValue: { fontFamily: fonts.displayMedium, fontSize: 22, color: c.onSurface, marginTop: spacing.xs },
  miniLabel: { fontFamily: fonts.text, fontSize: 12, color: c.onSurfaceSecondary },
  hint: { paddingVertical: spacing.sm, gap: spacing.sm },
  hintText: { fontFamily: fonts.text, fontSize: 14, color: c.muted, lineHeight: 20 },
}));

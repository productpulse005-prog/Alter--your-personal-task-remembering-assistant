import Feather from "@react-native-vector-icons/feather";
import { Redirect, Tabs } from "expo-router";
import { NativeTabs } from "expo-router/native-tabs";
import { ActivityIndicator, Platform, View } from "react-native";

import { useAuth } from "@/src/auth";
import { AlertsSync } from "@/src/components/AlertsSync";
import { usesNativeTabs } from "@/src/navigation";
import { fonts, useTheme } from "@/src/theme";

export default function TabsLayout() {
  const { status } = useAuth();
  const { colors } = useTheme();

  if (status === "loading") {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface }}>
        <ActivityIndicator color={colors.brandPrimary} />
      </View>
    );
  }
  if (status === "signedOut") return <Redirect href="/auth" />;

  if (usesNativeTabs) {
    return (
      <>
      <AlertsSync />
      <NativeTabs tintColor={colors.brandPrimary}>
        <NativeTabs.Trigger name="home">
          <NativeTabs.Trigger.Icon sf="house.fill" />
          <NativeTabs.Trigger.Label>Home</NativeTabs.Trigger.Label>
        </NativeTabs.Trigger>
        <NativeTabs.Trigger name="chats">
          <NativeTabs.Trigger.Icon sf="bubble.left.and.bubble.right.fill" />
          <NativeTabs.Trigger.Label>Chat</NativeTabs.Trigger.Label>
        </NativeTabs.Trigger>
        <NativeTabs.Trigger name="memory">
          <NativeTabs.Trigger.Icon sf="book.closed.fill" />
          <NativeTabs.Trigger.Label>Memory</NativeTabs.Trigger.Label>
        </NativeTabs.Trigger>
        <NativeTabs.Trigger name="tasks">
          <NativeTabs.Trigger.Icon sf="checklist" />
          <NativeTabs.Trigger.Label>Tasks</NativeTabs.Trigger.Label>
        </NativeTabs.Trigger>
      </NativeTabs>
      </>
    );
  }

  const icon = (name: React.ComponentProps<typeof Feather>["name"]) =>
    function TabIcon({ color }: { color: string }) {
      return <Feather name={name} size={22} color={color} />;
    };

  return (
    <>
    <AlertsSync />
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.brandPrimary,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          ...(Platform.OS === "web" ? { height: 64 } : {}),
        },
        tabBarItemStyle: { alignSelf: "center" },
        tabBarLabelStyle: { fontFamily: fonts.textMedium, fontSize: 11 },
      }}
    >
      <Tabs.Screen name="home" options={{ title: "Home", tabBarIcon: icon("home"), tabBarButtonTestID: "tab-home" }} />
      <Tabs.Screen name="chats" options={{ title: "Chat", tabBarIcon: icon("message-circle"), tabBarButtonTestID: "tab-chat" }} />
      <Tabs.Screen name="memory" options={{ title: "Memory", tabBarIcon: icon("book-open"), tabBarButtonTestID: "tab-memory" }} />
      <Tabs.Screen name="tasks" options={{ title: "Tasks", tabBarIcon: icon("check-square"), tabBarButtonTestID: "tab-tasks" }} />
    </Tabs>
    </>
  );
}

import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useFocusEffect, useRouter } from "expo-router";
import React, { useCallback, useState } from "react";
import { FlatList, Pressable, RefreshControl, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, Conversation } from "@/src/api";
import { useToast } from "@/src/components/toast";
import { Button, ConfirmSheet, EmptyState, ErrorState, Skeleton } from "@/src/components/ui";
import { relTime } from "@/src/labels";
import { usesNativeTabs } from "@/src/navigation";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

const EMPTY_IMG = require("../../assets/images/alter-logo.png");
const STARTERS = ["Help me plan my week", "Remember that I prefer short answers", "What do you know about me?"];

export default function Chats() {
  const insets = useSafeAreaInsets();
  const bottomChrome = usesNativeTabs ? insets.bottom : 0;
  const s = useStyles();
  const { colors } = useTheme();
  const router = useRouter();
  const qc = useQueryClient();
  const toast = useToast();
  const [toDelete, setToDelete] = useState<Conversation | null>(null);
  const [deleting, setDeleting] = useState(false);

  const q = useQuery({ queryKey: ["conversations"], queryFn: () => api<Conversation[]>("/conversations") });
  useFocusEffect(useCallback(() => { q.refetch(); }, [q.refetch])); // eslint-disable-line react-hooks/exhaustive-deps

  const open = (id: string, prompt?: string) => router.push({ pathname: "/chat/[id]", params: prompt ? { id, prompt } : { id } });

  const remove = async () => {
    if (!toDelete) return;
    setDeleting(true);
    try {
      await api(`/conversations/${toDelete.id}`, { method: "DELETE" });
      qc.invalidateQueries({ queryKey: ["conversations"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      toast("Conversation deleted");
      setToDelete(null);
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <View style={s.root}>
      <View style={[s.header, { paddingTop: insets.top + spacing.lg }]}>
        <Text style={s.title}>Conversations</Text>
        <Button label="New" icon="edit-3" small onPress={() => open("new")} testID="chats-new-button" />
      </View>
      {q.isLoading ? (
        <View style={{ padding: spacing.xl }}><Skeleton rows={5} /></View>
      ) : q.isError ? (
        <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} testID="chats-error" />
      ) : (
        <FlatList
          data={q.data}
          keyExtractor={(c) => c.id}
          contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: bottomChrome + spacing.xl, flexGrow: 1 }}
          refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={q.refetch} tintColor={colors.brandPrimary} />}
          ListEmptyComponent={
            <View>
              <EmptyState image={EMPTY_IMG} title="Start a conversation" body="Ask a question, think out loud, or tell Alter what to remember and do." testID="chats-empty" />
              <View style={{ gap: spacing.sm }}>
                {STARTERS.map((st, i) => (
                  <Pressable key={st} testID={`chats-starter-${i}`} onPress={() => open("new", st)} style={s.starter}>
                    <Text style={s.starterText}>{st}</Text>
                    <Feather name="arrow-up-right" size={16} color={colors.brandPrimary} />
                  </Pressable>
                ))}
              </View>
            </View>
          }
          renderItem={({ item }) => (
            <Pressable testID={`conversation-${item.id}`} onPress={() => open(item.id)} style={({ pressed }) => [s.row, pressed && { opacity: 0.7 }]}>
              <View style={{ flex: 1, gap: 4 }}>
                <View style={{ flexDirection: "row", justifyContent: "space-between", gap: spacing.md }}>
                  <Text style={s.rowTitle} numberOfLines={1}>{item.title}</Text>
                  <Text style={s.time}>{relTime(item.updated_at)}</Text>
                </View>
                <Text style={s.preview} numberOfLines={2}>{item.last_message || "No reply yet"}</Text>
              </View>
              <Pressable testID={`conversation-delete-${item.id}`} onPress={() => setToDelete(item)} hitSlop={8} style={s.del}>
                <Feather name="trash-2" size={16} color={colors.muted} />
              </Pressable>
            </Pressable>
          )}
        />
      )}
      <ConfirmSheet
        visible={!!toDelete}
        title="Delete conversation?"
        message="All messages in this conversation will be removed. Memories and tasks it created are kept."
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={remove}
        onClose={() => setToDelete(null)}
        testID="conversation-delete-confirm"
      />
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: spacing.xl, paddingBottom: spacing.lg, borderBottomWidth: 1, borderColor: c.divider },
  title: { fontFamily: fonts.display, fontSize: 32, color: c.onSurface },
  row: { flexDirection: "row", alignItems: "center", gap: spacing.md, paddingVertical: spacing.lg, borderBottomWidth: 1, borderColor: c.divider },
  rowTitle: { flex: 1, fontFamily: fonts.textMedium, fontSize: 16, color: c.onSurface },
  time: { fontFamily: fonts.text, fontSize: 12, color: c.muted },
  preview: { fontFamily: fonts.text, fontSize: 14, color: c.muted, lineHeight: 20 },
  del: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  starter: { minHeight: 52, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: spacing.lg, borderWidth: 1, borderColor: c.border, borderRadius: radius.lg, backgroundColor: c.surfaceSecondary },
  starterText: { fontFamily: fonts.text, fontSize: 15, color: c.onSurface, flex: 1 },
}));

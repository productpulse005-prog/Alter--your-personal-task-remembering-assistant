import Feather from "@react-native-vector-icons/feather";
import { useQuery } from "@tanstack/react-query";
import { Image } from "expo-image";
import { Redirect, useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import { ActivityIndicator, Text, View } from "react-native";
import Animated, { FadeInDown } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api } from "@/src/api";
import { useAuth } from "@/src/auth";
import { useToast } from "@/src/components/toast";
import { Button } from "@/src/components/ui";
import { startGoogleConnect } from "@/src/google-connect";
import { MASCOT_WAVE } from "@/src/mascot";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

const POINTS: { icon: React.ComponentProps<typeof Feather>["name"]; text: string }[] = [
  { icon: "calendar", text: "Turns your plans for the next 7 days into tasks with reminders" },
  { icon: "check-circle", text: "Spots to-dos people ask of you and adds them for you" },
  { icon: "shield", text: "View-only — Alter never sends, changes or deletes anything" },
];

export default function ConnectGoogleScreen() {
  const { status, finishOnboarding } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const s = useStyles();
  const { colors } = useTheme();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const q = useQuery({ queryKey: ["gmail-status"], queryFn: () => api<{ configured: boolean; connected: boolean }>("/gmail/status"), enabled: status === "signedIn" });

  const done = () => {
    finishOnboarding();
    router.replace("/home");
  };

  // nothing to ask if Google isn't set up yet or the account is already linked
  useEffect(() => {
    if (q.data && (!q.data.configured || q.data.connected)) done();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q.data]);

  if (status === "signedOut") return <Redirect href="/auth" />;

  const connect = async () => {
    setBusy(true);
    try {
      const result = await startGoogleConnect();
      if (result === undefined) return; // web: navigating to Google
      if (result === "connected") toast("All set! Alter will find your to-dos");
      done();
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setBusy(false);
    }
  };

  if (q.isLoading || !q.data || !q.data.configured || q.data.connected) {
    return (
      <View style={[s.root, { alignItems: "center", justifyContent: "center" }]}>
        <ActivityIndicator color={colors.brandPrimary} testID="connect-google-loading" />
      </View>
    );
  }

  return (
    <View style={[s.root, { paddingTop: insets.top + spacing.xl, paddingBottom: insets.bottom + spacing.xl }]} testID="connect-google-screen">
      <View style={s.body}>
        <Animated.View entering={FadeInDown.duration(400)} style={s.mascotWrap}>
          <Image source={MASCOT_WAVE} style={s.mascot} contentFit="contain" />
        </Animated.View>
        <Animated.Text entering={FadeInDown.delay(100).duration(400)} style={s.title} testID="connect-google-title">
          Let Alter find your to-dos from your Google account
        </Animated.Text>
        <Animated.View entering={FadeInDown.delay(200).duration(400)} style={s.points}>
          {POINTS.map((p) => (
            <View key={p.icon} style={s.point}>
              <View style={s.pointIcon}><Feather name={p.icon} size={16} color={colors.brandSecondary} /></View>
              <Text style={s.pointText}>{p.text}</Text>
            </View>
          ))}
        </Animated.View>
      </View>
      <View style={s.actions}>
        <Button label="Connect Google account" icon="link" onPress={connect} loading={busy} testID="connect-google-button" />
        <Button label="Maybe later" variant="ghost" onPress={done} testID="connect-google-later" />
        <Text style={s.fine}>You can change this anytime in Profile.</Text>
      </View>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface, paddingHorizontal: spacing.xl },
  body: { flex: 1, justifyContent: "center", gap: spacing.xl, maxWidth: 520, width: "100%", alignSelf: "center" },
  mascotWrap: { alignSelf: "center", backgroundColor: c.peach, borderRadius: 999, padding: spacing.lg, overflow: "hidden" },
  mascot: { width: 160, height: 160, borderRadius: 80 },
  title: { fontFamily: fonts.displayMedium, fontSize: 26, lineHeight: 34, color: c.onSurface, textAlign: "center" },
  points: { gap: spacing.md },
  point: { flexDirection: "row", gap: spacing.md, alignItems: "center", backgroundColor: c.surfaceSecondary, borderRadius: radius.lg, padding: spacing.md },
  pointIcon: { width: 32, height: 32, borderRadius: radius.md, backgroundColor: c.brandTertiary, alignItems: "center", justifyContent: "center" },
  pointText: { flex: 1, fontFamily: fonts.text, fontSize: 14, lineHeight: 20, color: c.onSurface },
  actions: { gap: spacing.sm, maxWidth: 520, width: "100%", alignSelf: "center" },
  fine: { fontFamily: fonts.text, fontSize: 12, color: c.muted, textAlign: "center" },
}));

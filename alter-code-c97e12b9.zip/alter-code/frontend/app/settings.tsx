import Feather from "@react-native-vector-icons/feather";
import { useQuery } from "@tanstack/react-query";
import dayjs from "dayjs";
import { Redirect, useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { api, Profile } from "@/src/api";
import { deviceTimeZone, useAuth } from "@/src/auth";
import { useToast } from "@/src/components/toast";
import { Button, Chip, ConfirmSheet, Field } from "@/src/components/ui";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

const COMMON_ZONES = ["Asia/Kolkata", "Asia/Dubai", "Asia/Singapore", "Europe/London", "Europe/Berlin", "America/New_York", "America/Los_Angeles", "Australia/Sydney"];

type Usage = { own_key: boolean; my_calls_today: number; my_limit: number; shared_used: number; shared_limit: number; resets_at: string };

export default function SettingsScreen() {
  const { profile, setProfile, signOut, status } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const s = useStyles();
  const { colors } = useTheme();
  const toast = useToast();
  const [tz, setTz] = useState("");
  const [tzError, setTzError] = useState<string | null>(null);
  const [savingTz, setSavingTz] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const usage = useQuery({ queryKey: ["me-usage"], queryFn: () => api<Usage>("/me/usage") });
  const device = deviceTimeZone();

  useEffect(() => {
    if (profile) setTz(profile.timezone);
  }, [profile]);

  const saveTz = async (zone: string) => {
    const z = zone.trim();
    if (!z) return setTzError("Pick or type a time zone");
    setTz(z);
    setTzError(null);
    setSavingTz(true);
    try {
      setProfile(await api<Profile>("/profile", { method: "PUT", body: { timezone: z } }));
      toast(`Time zone set to ${z}`);
    } catch (e: any) {
      setTzError(String(e.message).replace(/^\w+:\s*/, ""));
    } finally {
      setSavingTz(false);
    }
  };

  const deleteAccount = async () => {
    setDeleting(true);
    try {
      await api("/account", { method: "DELETE" });
      setConfirmDelete(false);
      await signOut();
      router.replace("/auth");
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setDeleting(false);
    }
  };

  if (status === "signedOut") return <Redirect href="/auth" />;

  const u = usage.data;
  const limit = u ? (u.own_key ? u.my_limit : u.my_limit || u.shared_limit) : 0;
  const used = u ? (u.own_key || u.my_limit ? u.my_calls_today : u.shared_used) : 0;
  const pct = limit ? Math.min(100, Math.round((used / limit) * 100)) : 0;
  const barColor = pct >= 90 ? colors.error : pct >= 70 ? colors.warning : colors.brandSecondary;

  return (
    <View style={s.root}>
      <View style={[s.header, { paddingTop: insets.top + spacing.sm }]}>
        <Pressable testID="settings-back-button" onPress={() => (router.canGoBack() ? router.back() : router.replace("/home"))} style={s.iconBtn} accessibilityLabel="Back">
          <Feather name="chevron-left" size={24} color={colors.onSurface} />
        </Pressable>
        <Text style={s.headerTitle}>Settings</Text>
        <View style={s.iconBtn} />
      </View>
      <ScrollView contentContainerStyle={[s.content, { paddingBottom: insets.bottom + spacing["2xl"] }]} keyboardShouldPersistTaps="handled">
        <View style={s.card} testID="settings-usage">
          <Text style={s.cardTitle}>AI usage today</Text>
          {usage.isLoading ? (
            <Text style={s.note}>Loading…</Text>
          ) : !u ? (
            <Text style={s.note}>{"Couldn't load usage right now."}</Text>
          ) : limit ? (
            <>
              <View style={s.barTrack}>
                <View style={[s.barFill, { width: `${pct}%`, backgroundColor: barColor }]} testID="settings-usage-bar" />
              </View>
              <Text style={s.note} testID="settings-usage-text">
                {u.own_key || u.my_limit
                  ? `${used} of ${limit} AI requests used (${pct}%)`
                  : `Alter's shared AI is ${pct}% used today (${used} of ${limit}). You made ${u.my_calls_today}.`}
              </Text>
            </>
          ) : (
            <Text style={s.note} testID="settings-usage-text">{`${u.my_calls_today} AI requests today. No daily limit${u.own_key ? " on your own key" : ""}.`}</Text>
          )}
          {u ? <Text style={s.small}>{`Resets ${dayjs(u.resets_at).format("h:mm A")} · ${u.own_key ? "Using your own Gemini key" : "Using Alter's shared AI"}`}</Text> : null}
        </View>

        <View style={s.card} testID="settings-timezone">
          <Text style={s.cardTitle}>Time zone</Text>
          <Text style={s.note}>{"Alarms, \"today\" and \"tomorrow\" follow this time zone."}</Text>
          <Button label={`Use this phone's time zone (${device})`} variant="secondary" icon="smartphone" onPress={() => saveTz(device)} loading={savingTz && tz === device} testID="settings-use-device-tz" />
          <View style={s.chips}>
            {COMMON_ZONES.map((z) => (
              <Chip key={z} label={z.split("/")[1].replace("_", " ")} selected={profile?.timezone === z || (z === "Asia/Kolkata" && profile?.timezone === "Asia/Calcutta")} onPress={() => saveTz(z)} testID={`settings-tz-${z}`} />
            ))}
          </View>
          <Field testID="settings-timezone-input" label="Or type one" placeholder="Europe/London" value={tz} onChangeText={setTz} autoCapitalize="none" error={tzError} />
          <Button label="Save time zone" onPress={() => saveTz(tz)} loading={savingTz} disabled={tz.trim() === profile?.timezone} testID="settings-save-tz" />
        </View>

        <View style={s.card} testID="settings-account">
          <Text style={s.cardTitle}>Account</Text>
          <Text style={s.note}>{"Deleting removes your profile, tasks, groceries, memories, chats and saved AI key. This can't be undone."}</Text>
          <Button label="Delete account and all data" variant="ghost" icon="trash-2" onPress={() => setConfirmDelete(true)} testID="settings-delete-account" />
        </View>
      </ScrollView>
      <ConfirmSheet
        visible={confirmDelete}
        title="Delete your account?"
        message="Everything will be permanently deleted. You'll be signed out."
        confirmLabel="Delete everything"
        loading={deleting}
        onConfirm={deleteAccount}
        onClose={() => setConfirmDelete(false)}
        testID="settings-confirm-delete"
      />
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.sm, paddingBottom: spacing.sm, borderBottomWidth: 1, borderColor: c.divider },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  headerTitle: { flex: 1, textAlign: "center", fontFamily: fonts.display, fontSize: 20, color: c.onSurface },
  content: { padding: spacing.xl, gap: spacing.lg, maxWidth: 640, width: "100%", alignSelf: "center" },
  card: { backgroundColor: c.surfaceSecondary, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.md, borderWidth: 1, borderColor: c.border },
  cardTitle: { fontFamily: fonts.displayMedium, fontSize: 18, color: c.onSurface },
  note: { fontFamily: fonts.text, fontSize: 14, lineHeight: 20, color: c.onSurfaceSecondary },
  small: { fontFamily: fonts.text, fontSize: 12, color: c.muted },
  barTrack: { height: 12, borderRadius: 6, backgroundColor: c.border, overflow: "hidden" },
  barFill: { height: 12, borderRadius: 6 },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
}));

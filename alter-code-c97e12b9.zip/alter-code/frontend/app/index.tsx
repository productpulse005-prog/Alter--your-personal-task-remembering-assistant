import { Redirect } from "expo-router";
import { ActivityIndicator, View } from "react-native";

import { useAuth } from "@/src/auth";
import { colors } from "@/src/theme";

export default function Index() {
  const { status, onboardGoogle } = useAuth();
  if (status === "loading") {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.surface }}>
        <ActivityIndicator color={colors.brandPrimary} testID="app-loading" />
      </View>
    );
  }
  if (status === "signedIn" && onboardGoogle) return <Redirect href="/connect-google" />;
  return <Redirect href={status === "signedIn" ? "/home" : "/auth"} />;
}

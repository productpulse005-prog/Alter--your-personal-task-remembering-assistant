import { Image } from "expo-image";
import { Redirect } from "expo-router";
import React, { useState } from "react";
import { Pressable, Text, View } from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/src/auth";
import { Button, Field } from "@/src/components/ui";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

const LOGO = require("../assets/images/alter-logo.png");

export default function AuthScreen() {
  const { status, signIn, signUp, signInWithGoogle } = useAuth();
  const [gLoading, setGLoading] = useState(false);
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const insets = useSafeAreaInsets();
  const s = useStyles();
  const { colors } = useTheme();

  if (status === "signedIn") return <Redirect href="/" />;

  const submit = async () => {
    const e: Record<string, string> = {};
    if (mode === "signup" && !name.trim()) e.name = "Tell Alter what to call you";
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())) e.email = "Enter a valid email address";
    if (password.length < 8) e.password = "Password must be at least 8 characters";
    setErrors(e);
    if (Object.keys(e).length) return;
    setLoading(true);
    try {
      if (mode === "signin") await signIn(email.trim(), password);
      else await signUp(name.trim(), email.trim(), password);
    } catch (err: any) {
      setErrors({ form: err.message });
    } finally {
      setLoading(false);
    }
  };

  const google = async () => {
    setErrors({});
    setGLoading(true);
    try {
      await signInWithGoogle();
    } catch (err: any) {
      setErrors({ form: err.message });
    } finally {
      setGLoading(false);
    }
  };

  return (
    <View style={s.root}>
      <KeyboardAwareScrollView bottomOffset={24} keyboardShouldPersistTaps="handled" contentContainerStyle={[s.content, { paddingTop: insets.top + spacing.xl, paddingBottom: insets.bottom + spacing.xl }]}>
        <Image source={LOGO} style={s.logo} contentFit="contain" testID="auth-logo" />
        <Text style={s.brand} testID="auth-brand">Alter</Text>
        <Text style={s.tagline}>Your friendly helper for tasks, groceries and the little things.</Text>

        <View style={s.card}>
          <Text style={s.title}>{mode === "signin" ? "Welcome back" : "Create your Alter"}</Text>
          {mode === "signup" ? (
            <Field testID="auth-name-input" label="Your name" placeholder="Alex" value={name} onChangeText={setName} error={errors.name} autoComplete="name" />
          ) : null}
          <Field testID="auth-email-input" label="Email" placeholder="you@example.com" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" autoComplete="email" error={errors.email} />
          <Field testID="auth-password-input" label="Password" placeholder="At least 8 characters" value={password} onChangeText={setPassword} secureTextEntry autoComplete={mode === "signin" ? "password" : "new-password"} error={errors.password} onSubmitEditing={submit} />
          {errors.form ? <Text style={s.formError} testID="auth-error">{errors.form}</Text> : null}
          <Button label={mode === "signin" ? "Sign in" : "Create account"} onPress={submit} loading={loading} testID="auth-submit-button" />
          <View style={s.orRow}>
            <View style={s.orLine} />
            <Text style={s.orText}>or</Text>
            <View style={s.orLine} />
          </View>
          <Button label="Continue with Google" variant="secondary" icon="log-in" onPress={google} loading={gLoading} testID="auth-google-button" />
          <Pressable
            testID="auth-toggle-mode"
            onPress={() => { setMode(mode === "signin" ? "signup" : "signin"); setErrors({}); }}
            style={s.toggle}
          >
            <Text style={s.toggleText}>
              {mode === "signin" ? "New here? " : "Already have an account? "}
              <Text style={{ color: colors.brandPrimary, fontFamily: fonts.textMedium }}>{mode === "signin" ? "Create an account" : "Sign in"}</Text>
            </Text>
          </Pressable>
        </View>
      </KeyboardAwareScrollView>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  root: { flex: 1, backgroundColor: c.surface },
  logo: { width: 150, height: 150, alignSelf: "center", borderRadius: 40 },
  content: { paddingHorizontal: spacing.xl, gap: spacing.md, flexGrow: 1, maxWidth: 520, width: "100%", alignSelf: "center" },
  brand: { fontFamily: fonts.displayMedium, fontSize: 44, color: c.onSurface, textAlign: "center" },
  tagline: { fontFamily: fonts.text, fontSize: 16, color: c.onSurfaceSecondary, lineHeight: 24, marginBottom: spacing.lg, textAlign: "center" },
  card: { backgroundColor: c.surface, borderWidth: 1, borderColor: c.border, borderRadius: radius.lg, padding: spacing.xl, gap: spacing.lg },
  title: { fontFamily: fonts.display, fontSize: 24, color: c.onSurface },
  formError: { fontFamily: fonts.text, fontSize: 14, color: c.error },
  orRow: { flexDirection: "row", alignItems: "center", gap: spacing.md },
  orLine: { flex: 1, height: 1, backgroundColor: c.divider },
  orText: { fontFamily: fonts.text, fontSize: 13, color: c.muted },
  toggle: { minHeight: 44, alignItems: "center", justifyContent: "center" },
  toggleText: { fontFamily: fonts.text, fontSize: 14, color: c.muted },
}));

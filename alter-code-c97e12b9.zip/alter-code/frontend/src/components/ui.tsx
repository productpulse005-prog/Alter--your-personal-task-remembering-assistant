import Feather from "@react-native-vector-icons/feather";
import { Image } from "expo-image";
import React, { useEffect, useRef } from "react";
import {
  ActivityIndicator,
  Animated,
  Modal,
  Pressable,
  ScrollView,
  StyleProp,
  Text,
  TextInput,
  TextInputProps,
  View,
  ViewStyle,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

export type IconName = React.ComponentProps<typeof Feather>["name"];

// ---------------- Button ----------------
type ButtonProps = {
  label: string;
  onPress: () => void;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  icon?: IconName;
  loading?: boolean;
  disabled?: boolean;
  testID?: string;
  style?: StyleProp<ViewStyle>;
  small?: boolean;
};
export function Button({ label, onPress, variant = "primary", icon, loading, disabled, testID, style, small }: ButtonProps) {
  const s = useStyles();
  const { colors } = useTheme();
  const fg =
    variant === "primary" ? colors.onBrandPrimary : variant === "danger" ? colors.onError : variant === "secondary" ? colors.onBrandTertiary : colors.brandPrimary;
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        s.btn,
        small && s.btnSmall,
        variant === "primary" && { backgroundColor: colors.brandPrimary },
        variant === "secondary" && { backgroundColor: colors.brandTertiary },
        variant === "danger" && { backgroundColor: colors.error },
        (disabled || loading) && { opacity: 0.5 },
        pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <>
          {icon ? <Feather name={icon} size={small ? 14 : 16} color={fg} /> : null}
          <Text style={[s.btnText, small && { fontSize: 13 }, { color: fg }]}>{label}</Text>
        </>
      )}
    </Pressable>
  );
}

// ---------------- Field ----------------
export function Field({ label, error, style, ...props }: TextInputProps & { label?: string; error?: string | null }) {
  const s = useStyles();
  const { colors } = useTheme();
  return (
    <View style={{ gap: spacing.xs }}>
      {label ? <Text style={s.label}>{label}</Text> : null}
      <TextInput
        placeholderTextColor={colors.muted}
        style={[s.input, props.multiline && { minHeight: 88, textAlignVertical: "top", paddingTop: spacing.md }, error ? { borderColor: colors.error } : null, style]}
        {...props}
      />
      {error ? <Text style={s.errorText}>{error}</Text> : null}
    </View>
  );
}

// ---------------- Search ----------------
export function SearchBar({ value, onChangeText, placeholder, testID }: { value: string; onChangeText: (t: string) => void; placeholder: string; testID: string }) {
  const s = useStyles();
  const { colors } = useTheme();
  return (
    <View style={s.search}>
      <Feather name="search" size={16} color={colors.muted} />
      <TextInput
        testID={testID}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        style={s.searchInput}
        returnKeyType="search"
      />
      {value ? (
        <Pressable testID={`${testID}-clear`} onPress={() => onChangeText("")} hitSlop={12}>
          <Feather name="x" size={16} color={colors.muted} />
        </Pressable>
      ) : null}
    </View>
  );
}

// ---------------- Chips ----------------
export function Chip({ label, selected, onPress, testID, icon }: { label: string; selected?: boolean; onPress: () => void; testID?: string; icon?: IconName }) {
  const s = useStyles();
  const { colors } = useTheme();
  return (
    <Pressable
      testID={testID}
      onPress={onPress}
      style={[s.chip, selected ? { backgroundColor: colors.brandPrimary, borderColor: colors.brandPrimary } : null]}
    >
      {icon ? <Feather name={icon} size={13} color={selected ? colors.onBrandPrimary : colors.onSurfaceTertiary} /> : null}
      <Text style={[s.chipText, { color: selected ? colors.onBrandPrimary : colors.onSurfaceTertiary }]}>{label}</Text>
    </Pressable>
  );
}

export function ChipRow({ children }: { children: React.ReactNode }) {
  const s = useStyles();
  return (
    <View style={s.chipRowWrap}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.chipRow} keyboardShouldPersistTaps="handled">
        {children}
      </ScrollView>
    </View>
  );
}

// ---------------- States ----------------
export function EmptyState({ image, icon, title, body, cta, onCta, testID }: { image?: string | number; icon?: IconName; title: string; body?: string; cta?: string; onCta?: () => void; testID?: string }) {
  const s = useStyles();
  const { colors } = useTheme();
  return (
    <View style={s.empty} testID={testID}>
      {image ? <Image source={typeof image === "string" ? { uri: image } : image} style={s.emptyImage} contentFit="cover" transition={300} /> : null}
      {icon && !image ? (
        <View style={s.emptyIcon}>
          <Feather name={icon} size={22} color={colors.brandPrimary} />
        </View>
      ) : null}
      <Text style={s.emptyTitle}>{title}</Text>
      {body ? <Text style={s.emptyBody}>{body}</Text> : null}
      {cta && onCta ? <Button label={cta} onPress={onCta} testID={testID ? `${testID}-cta` : undefined} style={{ marginTop: spacing.sm }} /> : null}
    </View>
  );
}

export function ErrorState({ message, onRetry, testID }: { message: string; onRetry: () => void; testID?: string }) {
  const s = useStyles();
  return (
    <View style={s.empty} testID={testID}>
      <Text style={s.emptyTitle}>Something went wrong</Text>
      <Text style={s.emptyBody}>{message}</Text>
      <Button label="Try again" variant="secondary" onPress={onRetry} testID={testID ? `${testID}-retry` : undefined} />
    </View>
  );
}

export function Skeleton({ rows = 4, height = 72 }: { rows?: number; height?: number }) {
  const s = useStyles();
  const pulse = useRef(new Animated.Value(0.5)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 700, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0.5, duration: 700, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [pulse]);
  return (
    <View style={{ gap: spacing.md }} testID="skeleton">
      {Array.from({ length: rows }).map((_, i) => (
        <Animated.View key={i} style={[s.skeleton, { height, opacity: pulse }]} />
      ))}
    </View>
  );
}

// ---------------- Sheet ----------------
export function Sheet({ visible, onClose, title, children, testID }: { visible: boolean; onClose: () => void; title: string; children: React.ReactNode; testID?: string }) {
  const s = useStyles();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <View style={s.backdrop}>
        <Pressable style={{ flex: 1 }} onPress={onClose} testID={testID ? `${testID}-backdrop` : undefined} />
        <View style={[s.sheet, { paddingBottom: insets.bottom + spacing.lg, maxHeight: "92%" }]} testID={testID}>
          <View style={s.grabber} />
          <View style={s.sheetHeader}>
            <Text style={s.sheetTitle}>{title}</Text>
            <Pressable onPress={onClose} hitSlop={12} testID={testID ? `${testID}-close` : undefined} style={s.iconBtn}>
              <Feather name="x" size={20} color={colors.onSurface} />
            </Pressable>
          </View>
          <KeyboardAwareScrollView bottomOffset={24} keyboardShouldPersistTaps="handled" contentContainerStyle={{ gap: spacing.lg, paddingBottom: spacing.sm }}>
            {children}
          </KeyboardAwareScrollView>
        </View>
      </View>
    </Modal>
  );
}

export function ConfirmSheet({ visible, title, message, confirmLabel, onConfirm, onClose, loading, testID }: { visible: boolean; title: string; message: string; confirmLabel: string; onConfirm: () => void; onClose: () => void; loading?: boolean; testID?: string }) {
  const s = useStyles();
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <View style={s.backdrop}>
        <Pressable style={{ flex: 1 }} onPress={onClose} />
        <View style={[s.sheet, { paddingBottom: insets.bottom + spacing.lg }]} testID={testID}>
          <Text style={s.sheetTitle}>{title}</Text>
          <Text style={[s.emptyBody, { textAlign: "left", marginTop: spacing.sm }]}>{message}</Text>
          <View style={{ flexDirection: "row", gap: spacing.md, marginTop: spacing.xl }}>
            <Button label="Cancel" variant="secondary" onPress={onClose} style={{ flex: 1 }} testID={testID ? `${testID}-cancel` : undefined} />
            <Button label={confirmLabel} variant="danger" onPress={onConfirm} loading={loading} style={{ flex: 1 }} testID={testID ? `${testID}-confirm` : undefined} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

export function Segmented<T extends string>({ options, value, onChange, testID }: { options: { key: T; label: string }[]; value: T; onChange: (v: T) => void; testID: string }) {
  const s = useStyles();
  const { colors } = useTheme();
  return (
    <View style={s.segment}>
      {options.map((o) => {
        const sel = o.key === value;
        return (
          <Pressable key={o.key} testID={`${testID}-${o.key}`} onPress={() => onChange(o.key)} style={[s.segmentItem, sel && { backgroundColor: colors.surface, borderColor: colors.borderStrong }]}>
            <Text style={[s.segmentText, { color: sel ? colors.onSurface : colors.muted }]}>{o.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function Fab({ onPress, testID, bottom, icon = "plus" }: { onPress: () => void; testID: string; bottom: number; icon?: IconName }) {
  const s = useStyles();
  const { colors } = useTheme();
  return (
    <Pressable testID={testID} onPress={onPress} accessibilityRole="button" style={({ pressed }) => [s.fab, { bottom }, pressed && { transform: [{ scale: 0.95 }] }]}>
      <Feather name={icon} size={24} color={colors.onBrandPrimary} />
    </Pressable>
  );
}

const useStyles = makeStyles((c) => ({
  btn: { minHeight: 48, borderRadius: radius.pill, paddingHorizontal: spacing.xl, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: spacing.sm },
  btnSmall: { minHeight: 36, paddingHorizontal: spacing.lg },
  btnText: { fontFamily: fonts.textMedium, fontSize: 15 },
  label: { fontFamily: fonts.textMedium, fontSize: 12, color: c.muted, textTransform: "uppercase", letterSpacing: 0.8 },
  input: { minHeight: 48, borderWidth: 1, borderColor: c.border, backgroundColor: c.surface, borderRadius: radius.lg, paddingHorizontal: spacing.lg, fontFamily: fonts.text, fontSize: 15, color: c.onSurface },
  errorText: { fontFamily: fonts.text, fontSize: 12, color: c.error },
  search: { height: 44, flexDirection: "row", alignItems: "center", gap: spacing.sm, backgroundColor: c.surfaceSecondary, borderRadius: radius.pill, paddingHorizontal: spacing.lg, borderWidth: 1, borderColor: c.border },
  searchInput: { flex: 1, fontFamily: fonts.text, fontSize: 15, color: c.onSurface, height: 44 },
  chipRowWrap: { height: 56, justifyContent: "center" },
  chipRow: { gap: spacing.sm, paddingHorizontal: spacing.xl, alignItems: "center" },
  chip: { height: 36, flexShrink: 0, flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: spacing.lg, borderRadius: radius.pill, borderWidth: 1, borderColor: c.border, backgroundColor: c.surfaceSecondary },
  chipText: { fontFamily: fonts.textMedium, fontSize: 13 },
  empty: { alignItems: "center", paddingVertical: spacing["2xl"], paddingHorizontal: spacing.xl, gap: spacing.sm },
  emptyImage: { width: 160, height: 160, borderRadius: 40, marginBottom: spacing.md },
  emptyIcon: { width: 56, height: 56, borderRadius: radius.lg, backgroundColor: c.brandTertiary, alignItems: "center", justifyContent: "center", marginBottom: spacing.sm },
  emptyTitle: { fontFamily: fonts.displayMedium, fontSize: 22, color: c.onSurface, textAlign: "center" },
  emptyBody: { fontFamily: fonts.text, fontSize: 14, color: c.muted, textAlign: "center", lineHeight: 21 },
  skeleton: { borderRadius: radius.lg, backgroundColor: c.surfaceTertiary },
  backdrop: { flex: 1, backgroundColor: c.backdrop, justifyContent: "flex-end" },
  sheet: { backgroundColor: c.surface, borderTopLeftRadius: 20, borderTopRightRadius: 20, paddingHorizontal: spacing.xl, paddingTop: spacing.sm },
  grabber: { alignSelf: "center", width: 36, height: 4, borderRadius: 2, backgroundColor: c.borderStrong, marginBottom: spacing.md },
  sheetHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.lg },
  sheetTitle: { fontFamily: fonts.display, fontSize: 24, color: c.onSurface },
  iconBtn: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  segment: { flexDirection: "row", backgroundColor: c.surfaceTertiary, borderRadius: radius.lg, padding: 3 },
  segmentItem: { flex: 1, minHeight: 40, alignItems: "center", justifyContent: "center", borderRadius: radius.md, borderWidth: 1, borderColor: "transparent" },
  segmentText: { fontFamily: fonts.textMedium, fontSize: 13 },
  fab: { position: "absolute", right: spacing.xl, width: 56, height: 56, borderRadius: 28, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
}));

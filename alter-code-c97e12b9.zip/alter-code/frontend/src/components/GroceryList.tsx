import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import { FlatList, Pressable, RefreshControl, Text, TextInput, View } from "react-native";

import { api, FamilyInfo, Grocery } from "@/src/api";
import { useToast } from "@/src/components/toast";
import { MASCOT_WAVE } from "@/src/mascot";
import { EmptyState, ErrorState, Skeleton } from "@/src/components/ui";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

export function GroceryList({ bottomPadding, onSpeak }: { bottomPadding: number; onSpeak: () => void }) {
  const s = useStyles();
  const { colors } = useTheme();
  const qc = useQueryClient();
  const toast = useToast();
  const router = useRouter();
  const [name, setName] = useState("");
  const [adding, setAdding] = useState(false);
  const q = useQuery({ queryKey: ["groceries"], queryFn: () => api<Grocery[]>("/groceries"), refetchInterval: 15000 });
  const family = useQuery({ queryKey: ["family"], queryFn: () => api<FamilyInfo>("/family") });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["groceries"] });
    qc.invalidateQueries({ queryKey: ["dashboard"] });
  };

  const add = async () => {
    const raw = name.trim();
    if (!raw) return;
    setAdding(true);
    try {
      await api("/groceries", { method: "POST", body: { name: raw } });
      setName("");
      refresh();
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setAdding(false);
    }
  };

  const toggle = async (g: Grocery) => {
    qc.setQueryData<Grocery[]>(["groceries"], (old) => old?.map((x) => (x.id === g.id ? { ...x, checked: !x.checked } : x)));
    try {
      await api(`/groceries/${g.id}`, { method: "PUT", body: { checked: !g.checked } });
      refresh();
    } catch (e: any) {
      toast(e.message, "error");
      refresh();
    }
  };

  const remove = async (g: Grocery) => {
    try {
      await api(`/groceries/${g.id}`, { method: "DELETE" });
      refresh();
    } catch (e: any) {
      toast(e.message, "error");
    }
  };

  const clearChecked = async () => {
    try {
      const r = await api<{ deleted: number }>("/groceries/clear-checked", { method: "POST" });
      toast(`Cleared ${r.deleted} item${r.deleted === 1 ? "" : "s"}`);
      refresh();
    } catch (e: any) {
      toast(e.message, "error");
    }
  };

  const items = q.data ?? [];
  const checkedCount = items.filter((i) => i.checked).length;
  const fam = family.data?.family;

  return (
    <View style={{ flex: 1 }}>
      <View style={s.addRow}>
        <TextInput
          testID="grocery-add-input"
          value={name}
          onChangeText={setName}
          placeholder="Add an item, e.g. Oat milk"
          placeholderTextColor={colors.muted}
          style={s.addInput}
          onSubmitEditing={add}
          returnKeyType="done"
          maxLength={120}
        />
        <Pressable testID="grocery-add-button" onPress={add} disabled={!name.trim() || adding} style={[s.addBtn, (!name.trim() || adding) && { opacity: 0.4 }]}>
          <Feather name="plus" size={20} color={colors.onBrandPrimary} />
        </Pressable>
        <Pressable testID="grocery-speak-button" onPress={onSpeak} style={s.micBtn} accessibilityLabel="Speak grocery items">
          <Feather name="mic" size={18} color={colors.onBrandTertiary} />
        </Pressable>
      </View>
      <Pressable testID="grocery-family-banner" onPress={() => router.push("/family")} style={s.banner}>
        <Feather name="users" size={14} color={colors.brandPrimary} />
        <Text style={s.bannerText} numberOfLines={1}>
          {fam ? `Shared with ${fam.name} · ${family.data?.members.length ?? 1} member${(family.data?.members.length ?? 1) === 1 ? "" : "s"}` : "Only you see this list — invite family to share it"}
        </Text>
        <Feather name="chevron-right" size={14} color={colors.muted} />
      </Pressable>
      {q.isLoading ? (
        <View style={{ paddingHorizontal: spacing.xl }}><Skeleton rows={5} height={52} /></View>
      ) : q.isError ? (
        <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} testID="grocery-error" />
      ) : (
        <FlatList
          data={items}
          keyExtractor={(g) => g.id}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: bottomPadding, flexGrow: 1 }}
          refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={q.refetch} tintColor={colors.brandPrimary} />}
          ListEmptyComponent={<EmptyState image={MASCOT_WAVE} title="Your grocery list is empty." body="Type an item above, or tap the mic and say what you need." testID="grocery-empty" />}
          ListFooterComponent={
            checkedCount ? (
              <Pressable testID="grocery-clear-checked" onPress={clearChecked} style={s.clear}>
                <Text style={s.clearText}>{`Clear ${checkedCount} checked`}</Text>
              </Pressable>
            ) : null
          }
          renderItem={({ item }) => (
            <View style={s.row} testID={`grocery-item-${item.id}`}>
              <Pressable testID={`grocery-toggle-${item.id}`} onPress={() => toggle(item)} hitSlop={8} style={[s.check, item.checked && { backgroundColor: colors.brandPrimary, borderColor: colors.brandPrimary }]} accessibilityRole="checkbox" accessibilityState={{ checked: item.checked }}>
                {item.checked ? <Feather name="check" size={14} color={colors.onBrandPrimary} /> : null}
              </Pressable>
              <View style={{ flex: 1 }}>
                <Text style={[s.name, item.checked && s.done]}>{item.name}{item.quantity ? <Text style={s.qty}>{`  ${item.quantity}`}</Text> : null}</Text>
                <Text style={s.meta}>{`${item.source === "voice" ? "Spoken" : "Added"} by ${item.added_by_name || "someone"}`}</Text>
              </View>
              <Pressable testID={`grocery-delete-${item.id}`} onPress={() => remove(item)} hitSlop={8} style={s.del}>
                <Feather name="x" size={16} color={colors.muted} />
              </Pressable>
            </View>
          )}
        />
      )}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  addRow: { flexDirection: "row", gap: spacing.sm, paddingHorizontal: spacing.xl, alignItems: "center" },
  addInput: { flex: 1, height: 48, borderWidth: 1, borderColor: c.borderStrong, borderRadius: radius.pill, paddingHorizontal: spacing.lg, fontFamily: fonts.text, fontSize: 15, color: c.onSurface, backgroundColor: c.surface },
  addBtn: { width: 48, height: 48, borderRadius: 24, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
  micBtn: { width: 48, height: 48, borderRadius: 24, backgroundColor: c.brandTertiary, alignItems: "center", justifyContent: "center" },
  banner: { flexDirection: "row", alignItems: "center", gap: spacing.sm, marginHorizontal: spacing.xl, marginTop: spacing.md, marginBottom: spacing.sm, paddingHorizontal: spacing.md, height: 40, borderRadius: radius.md, backgroundColor: c.brandTertiary },
  bannerText: { flex: 1, fontFamily: fonts.textMedium, fontSize: 13, color: c.onBrandTertiary },
  row: { minHeight: 56, flexDirection: "row", alignItems: "center", gap: spacing.md, borderBottomWidth: 1, borderColor: c.divider },
  check: { width: 24, height: 24, borderRadius: 6, borderWidth: 1.5, borderColor: c.borderStrong, alignItems: "center", justifyContent: "center" },
  name: { fontFamily: fonts.text, fontSize: 16, color: c.onSurface },
  qty: { fontFamily: fonts.text, fontSize: 13, color: c.muted },
  done: { textDecorationLine: "line-through", color: c.muted },
  meta: { fontFamily: fonts.text, fontSize: 11, color: c.muted, marginTop: 2 },
  del: { width: 44, height: 44, alignItems: "center", justifyContent: "center" },
  clear: { alignSelf: "center", minHeight: 44, justifyContent: "center", paddingHorizontal: spacing.lg, marginTop: spacing.md },
  clearText: { fontFamily: fonts.textMedium, fontSize: 14, color: c.error },
}));

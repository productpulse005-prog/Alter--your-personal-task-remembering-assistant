import Feather from "@react-native-vector-icons/feather";
import {
  getRecordingPermissionsAsync,
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from "expo-audio";
import React, { useEffect, useRef, useState } from "react";
import { ActivityIndicator, Pressable, Text, View } from "react-native";

import { transcribeAudio } from "@/src/api";
import { fonts, makeStyles, spacing, useTheme } from "@/src/theme";

export type MicPhase = "idle" | "listening" | "transcribing";
const MAX_MS = 90_000;

// Tap to talk, tap again to send: records, transcribes, and hands the text back.
export function ChatMic({
  disabled,
  onTranscript,
  onError,
  onPhase,
}: {
  disabled?: boolean;
  onTranscript: (text: string) => void;
  onError: (message: string, blocked?: boolean) => void;
  onPhase: (p: MicPhase) => void;
}) {
  const s = useStyles();
  const { colors } = useTheme();
  const recorder = useAudioRecorder({ ...RecordingPresets.HIGH_QUALITY, isMeteringEnabled: true });
  const rec = useAudioRecorderState(recorder, 200);
  const [phase, setPhaseState] = useState<MicPhase>("idle");
  const busy = useRef(false);
  const watchdog = useRef<ReturnType<typeof setTimeout> | null>(null);
  const turn = useRef(0);

  const setPhase = (p: MicPhase) => {
    setPhaseState(p);
    onPhase(p);
  };

  useEffect(
    () => () => {
      if (watchdog.current) clearTimeout(watchdog.current);
      turn.current++;
      try {
        if (recorder.isRecording) recorder.stop().catch(() => {});
      } catch {
        // recorder already released on unmount
      }
    },
    [recorder],
  );

  const start = async () => {
    if (busy.current) return;
    busy.current = true;
    try {
      const current = await getRecordingPermissionsAsync();
      if (!current.granted) {
        const req = await requestRecordingPermissionsAsync();
        if (!req.granted) {
          onError("Microphone access is needed to talk to Alter.", !req.canAskAgain);
          return;
        }
      }
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
      setPhase("listening");
      watchdog.current = setTimeout(() => stop(), MAX_MS);
    } catch (e: any) {
      onError(`Couldn't start the microphone. ${e?.message ?? ""}`.trim());
      setPhase("idle");
    } finally {
      busy.current = false;
    }
  };

  const stop = async () => {
    if (watchdog.current) clearTimeout(watchdog.current);
    const myTurn = ++turn.current;
    const duration = rec.durationMillis;
    try {
      await recorder.stop();
    } catch {
      // already stopped
    }
    await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true }).catch(() => {});
    const uri = recorder.uri;
    if (!uri || duration < 600) {
      setPhase("idle");
      onError("That was too short — tap the mic, speak, then tap again to send.");
      return;
    }
    setPhase("transcribing");
    try {
      const r = await transcribeAudio(uri);
      if (myTurn !== turn.current) return;
      setPhase("idle");
      onTranscript(r.transcript);
    } catch (e: any) {
      if (myTurn !== turn.current) return;
      setPhase("idle");
      onError(e.message);
    }
  };

  const secs = Math.floor((rec.durationMillis ?? 0) / 1000);

  if (phase === "transcribing") {
    return (
      <View style={[s.btn, { backgroundColor: colors.brandTertiary }]} testID="chat-mic-transcribing">
        <ActivityIndicator size="small" color={colors.brandPrimary} />
      </View>
    );
  }
  return (
    <View style={{ alignItems: "center" }}>
      <Pressable
        testID={phase === "listening" ? "chat-mic-stop" : "chat-mic-button"}
        onPress={phase === "listening" ? stop : start}
        disabled={disabled && phase === "idle"}
        accessibilityLabel={phase === "listening" ? "Stop and send voice message" : "Talk to Alter"}
        style={[s.btn, phase === "listening" ? { backgroundColor: colors.error } : { backgroundColor: colors.brandTertiary }, disabled && phase === "idle" && { opacity: 0.4 }]}
      >
        <Feather name={phase === "listening" ? "square" : "mic"} size={18} color={phase === "listening" ? colors.onError : colors.onBrandTertiary} />
      </Pressable>
      {phase === "listening" ? <Text style={s.timer} testID="chat-mic-timer">{`0:${String(secs).padStart(2, "0")}`}</Text> : null}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  btn: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" },
  timer: { position: "absolute", top: -16, fontFamily: fonts.textMedium, fontSize: 11, color: c.error, paddingHorizontal: spacing.xs },
}));

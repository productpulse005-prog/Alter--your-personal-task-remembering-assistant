import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import { Text, View } from "react-native";

import { api } from "@/src/api";
import { useToast } from "@/src/components/toast";
import { startGoogleConnect } from "@/src/google-connect";
import { Button } from "@/src/components/ui";
import { relTime } from "@/src/labels";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Status = { configured: boolean; connected: boolean; email: string | null; last_sync_at: string | null; last_added: number; error: string | null };

const RESULT_MSG: Record<string, string> = {
  connected: "Connected — Alter is finding your to-dos",
  cancelled: "Google account wasn't connected",
  expired: "That took too long — please try again",
  error: "Couldn't connect. Please try again.",
};

export function GmailConnect() {
  const s = useStyles();
  const { colors } = useTheme();
  const toast = useToast();
  const qc = useQueryClient();
  const router = useRouter();
  const params = useLocalSearchParams<{ gmail?: string }>();
  const [busy, setBusy] = useState<null | "connect" | "sync" | "disconnect">(null);
  const q = useQuery({ queryKey: ["gmail-status"], queryFn: () => api<Status>("/gmail/status") });

  const afterConnect = (result?: string) => {
    if (result && RESULT_MSG[result]) toast(RESULT_MSG[result], result === "connected" ? undefined : "error");
    q.refetch();
    if (result === "connected") setTimeout(() => { q.refetch(); qc.invalidateQueries({ queryKey: ["tasks"] }); }, 8000);
  };

  // web returns here with ?gmail=<result>
  useEffect(() => {
    if (params.gmail) {
      afterConnect(params.gmail);
      router.setParams({ gmail: undefined });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.gmail]);

  const connect = async () => {
    setBusy("connect");
    try {
      const result = await startGoogleConnect();
      if (result === undefined) return;
      afterConnect(result);
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setBusy(null);
    }
  };

  const sync = async () => {
    setBusy("sync");
    try {
      const r = await api<{ added: number; skipped?: string; error?: string }>("/gmail/sync?force=true", { method: "POST" });
      if (r.skipped === "auth") toast("Google access expired — please reconnect", "error");
      else if (r.error && !r.added) toast(r.error, "error");
      else toast(r.added ? `Added ${r.added} task${r.added === 1 ? "" : "s"} from Google` : "You're all caught up");
      qc.invalidateQueries({ queryKey: ["tasks"] });
      q.refetch();
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setBusy(null);
    }
  };

  const disconnect = async () => {
    setBusy("disconnect");
    try {
      await api("/gmail/disconnect", { method: "POST" });
      toast("Google account disconnected");
      q.refetch();
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setBusy(null);
    }
  };

  const d = q.data;
  return (
    <View style={s.card} testID="gmail-card">
      <View style={s.row}>
        <View style={s.icon}><Feather name="link" size={18} color={colors.brandPrimary} /></View>
        <View style={{ flex: 1 }}>
          <Text style={s.title}>Google account</Text>
          <Text style={s.sub} testID="gmail-status-text">
            {!d ? "Checking…" : d.connected ? `Connected · ${d.email ?? "your Google account"}` : "Let Alter find your to-dos and upcoming plans and add them to Tasks with reminders."}
          </Text>
        </View>
      </View>
      {d?.error ? <Text style={s.error}>{d.error}</Text> : null}
      {d?.connected ? (
        <>
          <Text style={s.sub}>{d.last_sync_at ? `Last checked ${relTime(d.last_sync_at)} · checks every 30 min` : "First check in progress…"}</Text>
          <Button label="Find to-dos now" icon="refresh-cw" onPress={sync} loading={busy === "sync"} testID="gmail-sync-button" />
          <Button label="Disconnect Google account" variant="ghost" icon="x-circle" onPress={disconnect} loading={busy === "disconnect"} testID="gmail-disconnect-button" />
        </>
      ) : d && !d.configured ? (
        <Text style={s.sub} testID="gmail-not-configured">Google connection is being set up and will be available soon.</Text>
      ) : (
        <Button label="Connect Google account" icon="link" onPress={connect} loading={busy === "connect"} disabled={!d} testID="gmail-connect-button" />
      )}
      <Text style={s.fine}>View-only access to your own account. Alter never sends, changes or deletes anything. Disconnect any time.</Text>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  card: { borderWidth: 1, borderColor: c.border, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.md, backgroundColor: c.surface },
  row: { flexDirection: "row", gap: spacing.md, alignItems: "center" },
  icon: { width: 40, height: 40, borderRadius: radius.md, backgroundColor: c.peach, alignItems: "center", justifyContent: "center" },
  title: { fontFamily: fonts.textMedium, fontSize: 16, color: c.onSurface },
  sub: { fontFamily: fonts.text, fontSize: 13, color: c.onSurfaceSecondary, lineHeight: 18 },
  error: { fontFamily: fonts.text, fontSize: 13, color: c.error },
  fine: { fontFamily: fonts.text, fontSize: 11, color: c.muted, lineHeight: 16 },
}));

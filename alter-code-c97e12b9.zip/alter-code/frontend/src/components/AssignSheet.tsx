import { useQueryClient } from "@tanstack/react-query";
import React, { useState } from "react";
import { View } from "react-native";

import { api, Task } from "@/src/api";
import { useToast } from "@/src/components/toast";
import { Chip, Sheet } from "@/src/components/ui";
import { spacing } from "@/src/theme";

type Member = { user_id: string; display_name: string };

/** Quick picker to hand one of my tasks to a family member (or take it back). */
export function AssignSheet({ task, members, meId, onClose }: { task: Task | null; members: Member[]; meId: string; onClose: () => void }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  const current = task?.assigned_to ?? null;

  const assign = async (to: string | null) => {
    if (!task || to === current) return onClose();
    setBusy(to ?? "me");
    try {
      await api(`/tasks/${task.id}`, { method: "PUT", body: { assigned_to: to } });
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      toast(to ? `Assigned to ${members.find((m) => m.user_id === to)?.display_name ?? "family member"}` : "Assigned back to you");
      onClose();
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setBusy(null);
    }
  };

  return (
    <Sheet visible={!!task} onClose={onClose} title={task ? `Assign "${task.title}"` : "Assign"} testID="assign-sheet">
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm }}>
        <Chip label="Me" icon="user" selected={!current} onPress={() => assign(null)} testID="assign-option-me" />
        {members.filter((m) => m.user_id !== meId).map((m) => (
          <Chip
            key={m.user_id}
            label={busy === m.user_id ? "Assigning…" : m.display_name}
            selected={current === m.user_id}
            onPress={() => assign(m.user_id)}
            testID={`assign-option-${m.user_id}`}
          />
        ))}
      </View>
    </Sheet>
  );
}

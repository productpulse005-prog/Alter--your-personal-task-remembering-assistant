import Feather from "@react-native-vector-icons/feather";
import { useQuery } from "@tanstack/react-query";
import React from "react";
import { Pressable, ScrollView, Text, View } from "react-native";

import { api, MemoryCategory } from "@/src/api";
import { IconName } from "@/src/components/ui";
import { CATEGORIES } from "@/src/labels";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Counts = { total: number; counts: Record<MemoryCategory, number> };

export function MemoryFolders({ selected, onSelect }: { selected: MemoryCategory | null; onSelect: (c: MemoryCategory | null) => void }) {
  const s = useStyles();
  const { colors } = useTheme();
  const q = useQuery({ queryKey: ["memories", "categories"], queryFn: () => api<Counts>("/memories/categories") });
  const folders: { key: MemoryCategory | null; label: string; icon: IconName; count?: number }[] = [
    { key: null, label: "All", icon: "layers", count: q.data?.total },
    ...CATEGORIES.map((c) => ({ key: c.key, label: c.label, icon: c.icon as IconName, count: q.data?.counts[c.key] })),
  ];

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.row}>
      {folders.map((f) => {
        const active = selected === f.key;
        const empty = f.count === 0 && f.key !== null;
        return (
          <Pressable
            key={f.key ?? "all"}
            testID={`memory-folder-${f.key ?? "all"}`}
            accessibilityRole="button"
            accessibilityState={{ selected: active }}
            onPress={() => onSelect(active && f.key !== null ? null : f.key)}
            style={({ pressed }) => [s.folder, active && s.folderActive, empty && !active && { opacity: 0.55 }, pressed && { opacity: 0.8 }]}
          >
            <View style={[s.iconWrap, active && { backgroundColor: colors.onBrandPrimary }]}>
              <Feather name={f.icon} size={18} color={colors.brandPrimary} />
            </View>
            <Text style={[s.label, active && { color: colors.onBrandPrimary }]} numberOfLines={1}>{f.label}</Text>
            <Text testID={`memory-folder-count-${f.key ?? "all"}`} style={[s.count, active && { color: colors.onBrandPrimary }]}>
              {f.count === undefined ? "–" : `${f.count} ${f.count === 1 ? "item" : "items"}`}
            </Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

const useStyles = makeStyles((c) => ({
  row: { paddingHorizontal: spacing.xl, paddingVertical: spacing.md, gap: spacing.md },
  folder: { width: 104, padding: spacing.md, borderRadius: radius.lg, backgroundColor: c.surface, borderWidth: 1, borderColor: c.border, gap: spacing.xs },
  folderActive: { backgroundColor: c.brandPrimary, borderColor: c.brandPrimary },
  iconWrap: { width: 36, height: 36, borderRadius: radius.md, backgroundColor: c.peach, alignItems: "center", justifyContent: "center", marginBottom: spacing.xs },
  label: { fontFamily: fonts.textMedium, fontSize: 14, color: c.onSurface },
  count: { fontFamily: fonts.text, fontSize: 12, color: c.muted },
}));

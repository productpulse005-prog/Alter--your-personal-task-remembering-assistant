import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import dayjs from "dayjs";
import React, { useState } from "react";
import { Pressable, RefreshControl, SectionList, Text, View } from "react-native";

import { api, Task } from "@/src/api";
import { useToast } from "@/src/components/toast";
import { EmptyState, ErrorState, Skeleton } from "@/src/components/ui";
import { celebrate, MASCOT_WAVE } from "@/src/mascot";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type History = { date: string; today: string; completed: Task[]; not_done: Task[] };

function dayTitle(date: string, today: string) {
  const diff = dayjs(today).diff(dayjs(date), "day");
  if (diff === 0) return "Today";
  if (diff === 1) return "Yesterday";
  return dayjs(date).format("dddd");
}

export function TaskHistory({ bottomPadding, onOpen }: { bottomPadding: number; onOpen: (t: Task) => void }) {
  const s = useStyles();
  const { colors } = useTheme();
  const qc = useQueryClient();
  const toast = useToast();
  const [date, setDate] = useState(() => dayjs().format("YYYY-MM-DD"));
  const q = useQuery({ queryKey: ["tasks", "history", date], queryFn: () => api<History>(`/tasks/history?date=${date}`) });
  const today = q.data?.today ?? dayjs().format("YYYY-MM-DD");
  const isToday = date >= today;
  const shift = (n: number) => setDate((d) => dayjs(d).add(n, "day").format("YYYY-MM-DD"));

  const toggle = async (t: Task) => {
    const next = t.status === "completed" ? "todo" : "completed";
    try {
      await api(`/tasks/${t.id}`, { method: "PUT", body: { status: next } });
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      if (next === "completed") celebrate(t.due_date);
      toast(next === "completed" ? "Task completed" : "Task reopened");
    } catch (e: any) {
      toast(e.message, "error");
    }
  };

  const sections = q.data
    ? [
        { key: "done", title: `Completed · ${q.data.completed.length}`, data: q.data.completed },
        { key: "not", title: `${isToday ? "Still to do" : "Not done"} · ${q.data.not_done.length}`, data: q.data.not_done },
      ].filter((x) => x.data.length)
    : [];

  return (
    <View style={{ flex: 1 }}>
      <View style={s.nav}>
        <Pressable onPress={() => shift(-1)} style={s.arrow} hitSlop={8} accessibilityLabel="Previous day" testID="history-prev-day">
          <Feather name="chevron-left" size={22} color={colors.onSurface} />
        </Pressable>
        <View style={{ alignItems: "center", flex: 1 }}>
          <Text style={s.dayTitle} testID="history-day-title">{dayTitle(date, today)}</Text>
          <Text style={s.daySub} testID="history-date">{dayjs(date).format("D MMMM YYYY")}</Text>
        </View>
        <Pressable
          onPress={() => shift(1)}
          disabled={isToday}
          style={[s.arrow, isToday && { opacity: 0.3 }]}
          hitSlop={8}
          accessibilityLabel="Next day"
          accessibilityState={{ disabled: isToday }}
          testID="history-next-day"
        >
          <Feather name="chevron-right" size={22} color={colors.onSurface} />
        </Pressable>
      </View>
      {!isToday ? (
        <Pressable onPress={() => setDate(today)} style={s.todayBtn} testID="history-jump-today">
          <Text style={s.todayText}>Jump to today</Text>
        </Pressable>
      ) : null}
      {q.isLoading ? (
        <View style={{ padding: spacing.xl }}><Skeleton rows={4} height={56} /></View>
      ) : q.isError ? (
        <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} testID="history-error" />
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(t) => t.id}
          stickySectionHeadersEnabled={false}
          contentContainerStyle={{ paddingHorizontal: spacing.xl, paddingBottom: bottomPadding, flexGrow: 1 }}
          refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={q.refetch} tintColor={colors.brandPrimary} />}
          ListEmptyComponent={
            <EmptyState image={MASCOT_WAVE} title="Nothing on this day" body="Completed tasks and tasks due this day show up here." testID="history-empty" />
          }
          renderSectionHeader={({ section }) => <Text style={s.sectionTitle}>{section.title}</Text>}
          renderItem={({ item }) => {
            const done = item.status === "completed";
            const when = done && item.completed_at ? `Done at ${dayjs(item.completed_at).format("h:mm A")}` : item.due_time ? `Due ${dayjs(`2000-01-01T${item.due_time}`).format("h:mm A")}` : "Due this day";
            return (
              <Pressable testID={`history-row-${item.id}`} onPress={() => onOpen(item)} style={({ pressed }) => [s.row, pressed && { opacity: 0.7 }]}>
                <Pressable testID={`history-toggle-${item.id}`} onPress={() => toggle(item)} hitSlop={8} style={[s.check, done && { backgroundColor: colors.brandPrimary, borderColor: colors.brandPrimary }]} accessibilityRole="checkbox" accessibilityState={{ checked: done }}>
                  {done ? <Feather name="check" size={14} color={colors.onBrandPrimary} /> : null}
                </Pressable>
                <View style={{ flex: 1, gap: 2 }}>
                  <Text style={[s.rowTitle, done && s.done]} numberOfLines={2}>{item.title}</Text>
                  <Text style={[s.meta, !done && !isToday && { color: colors.error }]}>{when}</Text>
                </View>
              </Pressable>
            );
          }}
        />
      )}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  nav: { flexDirection: "row", alignItems: "center", marginHorizontal: spacing.xl, marginTop: spacing.lg, padding: spacing.sm, borderRadius: radius.lg, backgroundColor: c.surfaceSecondary },
  arrow: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center", backgroundColor: c.surface },
  dayTitle: { fontFamily: fonts.display, fontSize: 20, color: c.onSurface },
  daySub: { fontFamily: fonts.text, fontSize: 13, color: c.muted },
  todayBtn: { alignSelf: "center", minHeight: 36, justifyContent: "center", paddingHorizontal: spacing.lg, marginTop: spacing.sm },
  todayText: { fontFamily: fonts.textMedium, fontSize: 14, color: c.brandPrimary },
  sectionTitle: { fontFamily: fonts.display, fontSize: 18, color: c.onSurfaceSecondary, marginTop: spacing.xl, marginBottom: spacing.xs },
  row: { minHeight: 60, flexDirection: "row", alignItems: "center", gap: spacing.md, paddingVertical: spacing.md, borderBottomWidth: 1, borderColor: c.divider },
  check: { width: 24, height: 24, borderRadius: 12, borderWidth: 1.5, borderColor: c.borderStrong, alignItems: "center", justifyContent: "center" },
  rowTitle: { fontFamily: fonts.text, fontSize: 16, color: c.onSurface },
  done: { textDecorationLine: "line-through", color: c.muted },
  meta: { fontFamily: fonts.textMedium, fontSize: 12, color: c.muted },
}));

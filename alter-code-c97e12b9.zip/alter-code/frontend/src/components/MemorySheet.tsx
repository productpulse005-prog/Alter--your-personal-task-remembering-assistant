import { useQueryClient } from "@tanstack/react-query";
import React, { useEffect, useState } from "react";
import { Text } from "react-native";

import { api, Memory, MemoryCategory } from "@/src/api";
import { useToast } from "@/src/components/toast";
import { Button, Chip, ChipRow, ConfirmSheet, Field, Sheet } from "@/src/components/ui";
import { CATEGORIES } from "@/src/labels";
import { fonts, spacing, useTheme } from "@/src/theme";

export function MemorySheet({ visible, memory, onClose }: { visible: boolean; memory: Memory | null; onClose: () => void }) {
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<MemoryCategory>("other");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const qc = useQueryClient();
  const toast = useToast();
  const { colors } = useTheme();

  useEffect(() => {
    if (visible) {
      setContent(memory?.content ?? "");
      setCategory(memory?.category ?? "other");
      setError(null);
    }
  }, [visible, memory]);

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["memories"] });
    qc.invalidateQueries({ queryKey: ["dashboard"] });
  };

  const save = async (confirmInferred = false) => {
    if (!content.trim()) return setError("Write something to remember");
    setSaving(true);
    setError(null);
    try {
      if (memory) {
        await api(`/memories/${memory.id}`, { method: "PUT", body: { content: content.trim(), category, ...(confirmInferred ? { certainty: "confirmed" } : {}) } });
        toast("Memory updated");
      } else {
        await api("/memories", { method: "POST", body: { content: content.trim(), category } });
        toast("Memory saved");
      }
      refresh();
      onClose();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!memory) return;
    setDeleting(true);
    try {
      await api(`/memories/${memory.id}`, { method: "DELETE" });
      toast("Memory deleted");
      refresh();
      setConfirm(false);
      onClose();
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <>
      <Sheet visible={visible && !confirm} onClose={onClose} title={memory ? "Edit memory" : "New memory"} testID="memory-sheet">
        <Field
          testID="memory-content-input"
          label="What should Alter remember?"
          placeholder="e.g. Prefers morning meetings before 10am"
          value={content}
          onChangeText={setContent}
          multiline
          maxLength={1000}
          error={error}
        />
        <Text style={{ fontFamily: fonts.textMedium, fontSize: 12, color: colors.muted, textTransform: "uppercase", letterSpacing: 0.8 }}>Category</Text>
        <ChipRow>
          {CATEGORIES.map((c) => (
            <Chip key={c.key} label={c.label} icon={c.icon as any} selected={category === c.key} onPress={() => setCategory(c.key)} testID={`memory-category-${c.key}`} />
          ))}
        </ChipRow>
        {memory?.certainty === "inferred" ? (
          <Text style={{ fontFamily: fonts.text, fontSize: 13, color: colors.warning }}>Alter inferred this. Confirm it if it is accurate.</Text>
        ) : null}
        <Button label={memory ? "Save changes" : "Save memory"} onPress={() => save()} loading={saving} testID="memory-save-button" />
        {memory?.certainty === "inferred" ? (
          <Button label="Save & mark as confirmed" variant="secondary" onPress={() => save(true)} testID="memory-confirm-button" />
        ) : null}
        {memory ? <Button label="Delete memory" variant="ghost" icon="trash-2" onPress={() => setConfirm(true)} testID="memory-delete-button" /> : null}
      </Sheet>
      <ConfirmSheet
        visible={confirm}
        title="Delete this memory?"
        message="Alter will no longer use it. This can't be undone."
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={remove}
        onClose={() => setConfirm(false)}
        testID="memory-delete-confirm"
      />
    </>
  );
}

export { spacing };

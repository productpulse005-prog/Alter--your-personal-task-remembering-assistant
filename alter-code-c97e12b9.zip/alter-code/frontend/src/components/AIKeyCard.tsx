import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import * as WebBrowser from "expo-web-browser";
import React, { useState } from "react";
import { ActivityIndicator, Pressable, Text, TextInput, View } from "react-native";

import { AIKeyStatus, api } from "@/src/api";
import { useToast } from "@/src/components/toast";
import { Button } from "@/src/components/ui";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

export const AI_KEY_QUERY = ["ai-key"];

/** Bring-your-own Gemini key. The key goes to the server once (HTTPS), is stored encrypted, and is never shown again. */
export function AIKeyCard() {
  const s = useStyles();
  const { colors } = useTheme();
  const qc = useQueryClient();
  const toast = useToast();
  const [key, setKey] = useState("");
  const [busy, setBusy] = useState<"save" | "test" | "remove" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const q = useQuery({ queryKey: AI_KEY_QUERY, queryFn: () => api<AIKeyStatus>("/ai/key") });
  const d = q.data;

  const run = async (kind: "save" | "test" | "remove") => {
    setBusy(kind);
    setError(null);
    try {
      const r =
        kind === "save"
          ? await api<AIKeyStatus>("/ai/key", { method: "PUT", body: { api_key: key.trim() } })
          : kind === "test"
            ? await api<AIKeyStatus>("/ai/key/test", { method: "POST" })
            : await api<AIKeyStatus>("/ai/key", { method: "DELETE" });
      qc.setQueryData(AI_KEY_QUERY, r);
      setKey("");
      if (kind === "save") toast("Gemini key verified and saved");
      if (kind === "test") toast(r.status === "valid" && !r.last_error ? "Your key works" : r.last_error ?? "Key checked", r.status === "valid" && !r.last_error ? "success" : "error");
      if (kind === "remove") toast("Key removed");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(null);
    }
  };

  if (q.isLoading) return <ActivityIndicator color={colors.brandPrimary} />;
  const ok = d?.configured && d.status === "valid";
  return (
    <View style={s.card} testID="ai-key-card">
      <View style={s.row}>
        <Feather name={ok ? "check-circle" : d?.configured ? "alert-triangle" : "key"} size={18} color={ok ? colors.success : d?.configured ? colors.error : colors.muted} />
        <Text style={s.title} testID="ai-key-status">
          {d?.configured ? `Your key ${d.masked} · ${d.status === "valid" ? "working" : "not working"}`
            : d?.route === "app" ? "Using Alter's built-in Gemini AI. Your own key is optional"
            : d?.route === "universal" ? "Using the developer's shared key (admin only)" : "AI isn't set up on the server yet"}
        </Text>
      </View>
      {d?.configured && d.last_error ? <Text style={s.err}>{d.last_error}</Text> : null}
      <Text style={s.body}>{d?.disclosure}</Text>
      <TextInput
        testID="ai-key-input"
        value={key}
        onChangeText={setKey}
        placeholder={d?.configured ? "Paste a new key to replace it" : "Paste your Gemini API key"}
        placeholderTextColor={colors.muted}
        secureTextEntry
        autoCapitalize="none"
        autoCorrect={false}
        style={s.input}
      />
      {error ? <Text style={s.err} testID="ai-key-error">{error}</Text> : null}
      <Button label={d?.configured ? "Verify & replace key" : "Verify & save key"} icon="shield" onPress={() => run("save")} loading={busy === "save"} disabled={key.trim().length < 20 || !!busy} testID="ai-key-save" />
      {d?.configured ? (
        <View style={s.row}>
          <View style={{ flex: 1 }}><Button label="Test key" variant="secondary" onPress={() => run("test")} loading={busy === "test"} disabled={!!busy} testID="ai-key-test" /></View>
          <View style={{ flex: 1 }}><Button label="Remove" variant="secondary" onPress={() => run("remove")} loading={busy === "remove"} disabled={!!busy} testID="ai-key-remove" /></View>
        </View>
      ) : null}
      <Pressable onPress={() => WebBrowser.openBrowserAsync("https://aistudio.google.com/apikey")} style={s.link} testID="ai-key-get-link">
        <Feather name="external-link" size={14} color={colors.brandPrimary} />
        <Text style={s.linkText}>Get a key in Google AI Studio</Text>
      </Pressable>
      <Text style={s.small}>{`Model: ${d?.model ?? ""}. Tip: in Google Cloud, restrict the key to the Generative Language API.`}</Text>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  card: { gap: spacing.sm, padding: spacing.lg, borderRadius: radius.lg, borderWidth: 1, borderColor: c.border, backgroundColor: c.surfaceSecondary },
  row: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  title: { flex: 1, fontFamily: fonts.textMedium, fontSize: 15, color: c.onSurface },
  body: { fontFamily: fonts.text, fontSize: 13, lineHeight: 19, color: c.onSurfaceSecondary },
  small: { fontFamily: fonts.text, fontSize: 12, color: c.muted },
  err: { fontFamily: fonts.text, fontSize: 13, color: c.error },
  input: { minHeight: 48, paddingHorizontal: spacing.lg, borderRadius: radius.md, borderWidth: 1, borderColor: c.border, backgroundColor: c.surface, fontFamily: fonts.text, fontSize: 15, color: c.onSurface },
  link: { flexDirection: "row", alignItems: "center", gap: 6, minHeight: 44 },
  linkText: { fontFamily: fonts.textMedium, fontSize: 14, color: c.brandPrimary },
}));

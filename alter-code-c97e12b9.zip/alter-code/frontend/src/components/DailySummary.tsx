import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import React, { useState } from "react";
import { ActivityIndicator, Pressable, Text, View } from "react-native";

import { api, DaySummary } from "@/src/api";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

export const SUMMARY_KEY = ["summary"];

/** AI-written recap of today (done / still to do / overdue). Updating counts as 1 chat. */
export function DailySummary() {
  const s = useStyles();
  const { colors } = useTheme();
  const qc = useQueryClient();
  const [updating, setUpdating] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const q = useQuery({ queryKey: SUMMARY_KEY, queryFn: () => api<DaySummary>("/summary/today"), retry: false });

  const update = async () => {
    setUpdating(true);
    setErr(null);
    try {
      qc.setQueryData(SUMMARY_KEY, await api<DaySummary>("/summary/today?refresh=true"));
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setUpdating(false);
    }
  };

  const d = q.data;
  return (
    <View style={s.card} testID="home-daily-summary">
      <View style={s.head}>
        <Feather name="sun" size={18} color={colors.warning} />
        <Text style={s.title}>Your day</Text>
        {d?.stale ? (
          <Pressable onPress={update} disabled={updating} hitSlop={10} testID="home-summary-update" style={s.update}>
            {updating ? <ActivityIndicator size="small" color={colors.brandPrimary} /> : <Feather name="refresh-cw" size={14} color={colors.brandPrimary} />}
            <Text style={s.updateText}>Update</Text>
          </Pressable>
        ) : null}
      </View>
      {q.isLoading ? (
        <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm }}>
          <ActivityIndicator size="small" color={colors.brandPrimary} />
          <Text style={s.muted}>Writing your summary…</Text>
        </View>
      ) : q.isError ? (
        <Text style={s.muted} testID="home-summary-error">{(q.error as Error).message}</Text>
      ) : d ? (
        <>
          <Text style={s.body} testID="home-summary-text">{d.text}</Text>
          <View style={s.stats}>
            <Stat icon="check-circle" n={d.counts.done} label="done" color={colors.success} />
            <Stat icon="circle" n={d.counts.pending} label="to do" color={colors.brandPrimary} />
            {d.counts.overdue ? <Stat icon="alert-circle" n={d.counts.overdue} label="overdue" color={colors.error} /> : null}
          </View>
        </>
      ) : null}
      {err ? <Text style={[s.muted, { color: colors.error }]}>{err}</Text> : null}
    </View>
  );
}

function Stat({ icon, n, label, color }: { icon: React.ComponentProps<typeof Feather>["name"]; n: number; label: string; color: string }) {
  const s = useStyles();
  return (
    <View style={s.stat}>
      <Feather name={icon} size={14} color={color} />
      <Text style={s.statText}>{`${n} ${label}`}</Text>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  card: { backgroundColor: c.surfaceSecondary, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.sm, borderWidth: 1, borderColor: c.border },
  head: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  title: { flex: 1, fontFamily: fonts.displayMedium, fontSize: 20, color: c.onSurface },
  update: { flexDirection: "row", alignItems: "center", gap: 4, minHeight: 44, paddingHorizontal: spacing.xs },
  updateText: { fontFamily: fonts.textMedium, fontSize: 13, color: c.brandPrimary },
  body: { fontFamily: fonts.text, fontSize: 15, lineHeight: 22, color: c.onSurfaceSecondary },
  muted: { fontFamily: fonts.text, fontSize: 14, color: c.muted },
  stats: { flexDirection: "row", gap: spacing.lg, marginTop: spacing.xs },
  stat: { flexDirection: "row", alignItems: "center", gap: 4 },
  statText: { fontFamily: fonts.textMedium, fontSize: 13, color: c.onSurfaceSecondary },
}));

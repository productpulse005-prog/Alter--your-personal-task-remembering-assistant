import Feather from "@react-native-vector-icons/feather";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import * as Notifications from "expo-notifications";
import React, { useEffect, useRef, useState } from "react";
import { AppState, Modal, Text, View } from "react-native";

import { dismissFullScreenAlarm, listenFullScreenAlarms } from "@/src/alarm";
import { api, Task } from "@/src/api";
import { useToast } from "@/src/components/toast";
import { Button } from "@/src/components/ui";
import { useAuth } from "@/src/auth";
import { celebrate, welcomeBack } from "@/src/mascot";
import { storage } from "@/src/utils/storage";
import {
  alertsSupported, FiredAlert, getNotifPermission, hasUpcomingTimedTask, notificationsSupported, requestNotifPermission,
  cancelSnooze, scheduleComebackNudge, scheduleSnooze, setAlertHandler, SNOOZE_OPTIONS, syncTaskAlerts, TEST_TASK_ID,
} from "@/src/notifications";
import { playAlarm, playReminder, stopAlarm } from "@/src/sounds";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

export const ALERT_TASKS_KEY = ["tasks", "alerts"];
const RING_MS = 60_000;

// Keeps this device's alarms and reminders in sync with the user's tasks (phone: OS-scheduled
// notifications; web: browser notifications + in-page timers) and rings in the foreground.
export function AlertsSync() {
  const toast = useToast();
  const qc = useQueryClient();
  const { profile } = useAuth();
  const s = useStyles();
  const { colors } = useTheme();
  const [ringing, setRinging] = useState<FiredAlert | null>(null);
  const stopTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const onOpen = async () => {
    const last = await storage.getItem<string | null>("last_open_at", null);
    if (last && Date.now() - new Date(last).getTime() >= 3 * 24 * 3600 * 1000) welcomeBack(profile?.display_name);
    await storage.setItem("last_open_at", new Date().toISOString());
    await scheduleComebackNudge(profile?.display_name).catch((e) => console.warn("nudge failed", e));
  };
  const q = useQuery({
    queryKey: ALERT_TASKS_KEY,
    queryFn: () => api<Task[]>("/tasks"),
    refetchInterval: 5 * 60 * 1000,
    enabled: alertsSupported,
  });

  const stop = () => {
    stopAlarm();
    dismissFullScreenAlarm().catch(() => {});
    if (stopTimer.current) clearTimeout(stopTimer.current);
    setRinging(null);
  };

  const onAlert = (a: FiredAlert) => {
    if (a.kind === "alarm") {
      setRinging(a);
      playAlarm();
      if (stopTimer.current) clearTimeout(stopTimer.current);
      stopTimer.current = setTimeout(stop, RING_MS);
    } else {
      playReminder();
      toast(a.heading);
    }
  };

  const snooze = async (mins: number) => {
    const a = ringing;
    stop();
    if (!a) return;
    try {
      await scheduleSnooze(a.taskId, a.title, mins);
      toast(`Snoozed. Rings again in ${mins} minutes`);
    } catch (e: any) {
      toast(e.message ?? "Couldn't snooze", "error");
    }
  };

  const markDone = async () => {
    const a = ringing;
    stop();
    if (!a || a.taskId === TEST_TASK_ID) return;
    cancelSnooze(a.taskId).catch(() => {});
    try {
      await api(`/tasks/${a.taskId}`, { method: "PUT", body: { status: "completed" } });
      qc.invalidateQueries({ queryKey: ["tasks"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      qc.invalidateQueries({ queryKey: ["summary"] });
      celebrate(null);
      toast("Task completed");
    } catch (e: any) {
      toast(e.message, "error");
    }
  };

  useEffect(() => {
    (async () => {
      // Ask when the user has a timed task; "denied" may still be askable once more on Android.
      const p = notificationsSupported && hasUpcomingTimedTask(q.data) ? await getNotifPermission() : null;
      if ((p === "undetermined" || p === "denied") && !(await storage.getItem<boolean>("notif_asked", false))) {
        await storage.setItem("notif_asked", true);
        await requestNotifPermission();
      }
      await syncTaskAlerts(q.data);
    })().catch((e) => console.warn("alert sync failed", e));
  }, [q.data]);

  useEffect(() => {
    onOpen();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setAlertHandler(onAlert);
    const offFull = listenFullScreenAlarms((a) => onAlert({ kind: "alarm", taskId: a.taskId, title: a.title, mins: 0, heading: a.heading }));
    const sub = notificationsSupported
      ? Notifications.addNotificationReceivedListener((n) => {
          const d = n.request.content.data as { kind?: string; title?: string; mins?: number; taskId?: string };
          if (d?.kind === "alarm" || d?.kind === "pre") {
            onAlert({ kind: d.kind, taskId: d.taskId ?? "", title: d.title ?? "task", mins: d.mins ?? 0, heading: n.request.content.title ?? `Reminder: ${d.title}` });
          }
        })
      : null;
    const app = AppState.addEventListener("change", (st) => {
      if (st === "active") {
        q.refetch();
        onOpen();
      }
    });
    return () => {
      setAlertHandler(null);
      offFull();
      sub?.remove();
      app.remove();
      stopAlarm();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Modal visible={!!ringing} transparent animationType="fade" onRequestClose={stop}>
      <View style={s.backdrop}>
        <View style={s.card} testID="alarm-overlay">
          <View style={s.bell}><Feather name="bell" size={30} color={colors.onBrandPrimary} /></View>
          <Text style={s.kicker}>{"It's time"}</Text>
          <Text style={s.title} testID="alarm-title">{ringing?.title}</Text>
          <Button label="Mark as done" icon="check" onPress={markDone} testID="alarm-done" />
          <Text style={s.snoozeLabel}>Snooze for</Text>
          <View style={s.snoozeRow}>
            {SNOOZE_OPTIONS.map((m) => (
              <Button key={m} label={`${m} min`} variant="secondary" onPress={() => snooze(m)} style={{ flex: 1 }} testID={`alarm-snooze-${m}`} />
            ))}
          </View>
          <Button label="Stop alarm" variant="ghost" icon="bell-off" onPress={stop} testID="alarm-stop" />
        </View>
      </View>
    </Modal>
  );
}

const useStyles = makeStyles((c) => ({
  backdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.45)", alignItems: "center", justifyContent: "center", padding: spacing.xl },
  card: { width: "100%", maxWidth: 380, backgroundColor: c.surface, borderRadius: radius.lg, padding: spacing.xl, gap: spacing.md, alignItems: "stretch" },
  bell: { alignSelf: "center", width: 64, height: 64, borderRadius: 32, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
  kicker: { fontFamily: fonts.textMedium, fontSize: 13, color: c.muted, textAlign: "center", textTransform: "uppercase", letterSpacing: 1 },
  title: { fontFamily: fonts.display, fontSize: 24, color: c.onSurface, textAlign: "center", marginBottom: spacing.sm },
  snoozeLabel: { fontFamily: fonts.textMedium, fontSize: 13, color: c.muted, textAlign: "center" },
  snoozeRow: { flexDirection: "row", gap: spacing.sm },
}));

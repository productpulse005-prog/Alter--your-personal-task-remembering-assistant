import Feather from "@react-native-vector-icons/feather";
import { useQueryClient } from "@tanstack/react-query";
import React, { useState } from "react";
import { ActivityIndicator, Pressable, Text, TextInput, View } from "react-native";

import { api, ChatAction } from "@/src/api";
import { useToast } from "@/src/components/toast";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

/** The one place to add things: type a task / groceries / alarm, or tap the mic to say it. */
export function QuickTask({ onSpeak }: { onSpeak: () => void }) {
  const s = useStyles();
  const { colors } = useTheme();
  const qc = useQueryClient();
  const toast = useToast();
  const [title, setTitle] = useState("");
  const [saving, setSaving] = useState(false);
  const [question, setQuestion] = useState<string | null>(null);
  const attempt = React.useRef<{ text: string; id: string } | null>(null);
  const hasText = !!title.trim();

  const add = async () => {
    const t = title.trim();
    if (!t || saving) return;
    setSaving(true);
    try {
      // same text retried after a failure reuses the id, so nothing is created twice
      if (attempt.current?.text !== t) attempt.current = { text: t, id: `cap${Date.now()}${Math.random().toString(36).slice(2, 8)}` };
      const r = await api<{ results: ChatAction[]; ai: boolean; note?: string | null; clarify?: string }>("/capture", {
        method: "POST", body: { text: t, client_id: attempt.current.id },
      });
      attempt.current = null;
      if (r.clarify) {
        setQuestion(r.clarify); // keep the text so the user can add the missing detail
        return;
      }
      setQuestion(null);
      setTitle("");
      const ok = r.results.filter((a) => a.status === "success");
      const g = ok.some((a) => a.type === "add_grocery" && (a.data?.items?.length ?? 0) > 0);
      const tasks = ok.filter((a) => a.type === "create_task");
      const alarm = tasks.find((a) => a.data?.alarm);
      toast(alarm ? `Alarm set for ${alarm.data?.due_time}` : g && tasks.length ? "Added to your tasks and grocery list" : g ? "Added to your grocery list" : tasks.length ? "Task added" : r.results[0]?.detail ?? "Nothing to add");
      ["groceries", "tasks", "dashboard", "summary"].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
    } catch (e: any) {
      toast(e.message, "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={{ gap: spacing.xs }} testID="home-quick-task">
      <View style={s.bar}>
        <TextInput
          testID="home-quick-task-input"
          value={title}
          onChangeText={setTitle}
          placeholder="Task, groceries or alarm…"
          placeholderTextColor={colors.muted}
          style={s.input}
          maxLength={200}
          onSubmitEditing={add}
          returnKeyType="done"
        />
        <Pressable
          testID={hasText ? "home-quick-task-add" : "home-voice-button"}
          onPress={hasText ? add : onSpeak}
          disabled={saving}
          style={s.btn}
          accessibilityLabel={hasText ? "Add" : "Speak instead"}
        >
          {saving ? <ActivityIndicator size="small" color={colors.onBrandPrimary} /> : <Feather name={hasText ? "arrow-up" : "mic"} size={22} color={colors.onBrandPrimary} />}
        </Pressable>
      </View>
      {question ? <Text style={s.question} testID="home-quick-task-question">{`Alter asks: ${question}`}</Text> : null}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  bar: { flexDirection: "row", alignItems: "center", backgroundColor: c.surfaceSecondary, borderWidth: 1, borderColor: c.border, borderRadius: radius.pill, paddingLeft: spacing.lg, paddingRight: 6, minHeight: 60 },
  input: { flex: 1, minHeight: 56, fontFamily: fonts.text, fontSize: 16, color: c.onSurface },
  btn: { width: 48, height: 48, borderRadius: 24, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
  question: { fontFamily: fonts.textMedium, fontSize: 14, color: c.warning, paddingHorizontal: spacing.lg },
}));

import Constants from "expo-constants";
import { usePathname } from "expo-router";
import React, { useEffect, useState } from "react";
import { Platform, Text, View } from "react-native";

import { api } from "@/src/api";
import { useToast } from "@/src/components/toast";
import { Button, Chip, Field, Segmented, Sheet } from "@/src/components/ui";
import { fonts, useTheme } from "@/src/theme";

type Kind = "bug" | "idea" | "other";
const KINDS: { key: Kind; label: string }[] = [
  { key: "bug", label: "Bug" },
  { key: "idea", label: "Idea" },
  { key: "other", label: "Other" },
];
export const BUG_AREAS = [
  { key: "alarms", label: "Alarms" },
  { key: "voice", label: "Voice" },
  { key: "tasks", label: "Tasks" },
  { key: "groceries", label: "Groceries" },
  { key: "chat", label: "Chat" },
  { key: "sign_in", label: "Sign-in" },
  { key: "other", label: "Other" },
];

/** Beta testers send a quick note or bug report; it lands in the admin's Feedback inbox. */
export function FeedbackSheet({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const [kind, setKind] = useState<Kind>("bug");
  const [area, setArea] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const toast = useToast();
  const { colors } = useTheme();
  const screen = usePathname();

  useEffect(() => {
    if (visible) setError(null);
  }, [visible]);

  const send = async () => {
    if (kind === "bug" && !area) return setError("Pick which part of the app broke");
    if (message.trim().length < 3) return setError("Tell us a little more (at least 3 characters)");
    setSending(true);
    setError(null);
    try {
      const v = Constants.expoConfig;
      await api("/feedback", {
        method: "POST",
        body: {
          kind,
          ...(kind === "bug" ? { area } : {}),
          message: message.trim(),
          screen: screen.slice(0, 80),
          platform: `${Platform.OS} ${Platform.Version ?? ""}`.trim().slice(0, 40),
          app_version: `${v?.version ?? ""} (${v?.android?.versionCode ?? "-"})`,
        },
      });
      setMessage("");
      setKind("bug");
      setArea(null);
      toast("Thanks! Your feedback was sent");
      onClose();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <Sheet visible={visible} onClose={onClose} title="Send feedback" testID="feedback-sheet">
      <Text style={{ fontFamily: fonts.text, fontSize: 14, color: colors.onSurfaceSecondary }}>
        {"Found a bug or have an idea? Tell us what happened. We'll see which screen you were on and your app version."}
      </Text>
      <Segmented options={KINDS} value={kind} onChange={setKind} testID="feedback-kind" />
      {kind === "bug" && (
        <>
          <Text style={{ fontFamily: fonts.text, fontSize: 14, color: colors.onSurface }}>Which part of the app broke?</Text>
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
            {BUG_AREAS.map((a) => (
              <Chip key={a.key} label={a.label} selected={area === a.key} onPress={() => { setArea(a.key); setError(null); }} testID={`feedback-area-${a.key}`} />
            ))}
          </View>
          {error && !area && <Text style={{ fontFamily: fonts.text, fontSize: 13, color: colors.error }} testID="feedback-area-error">{error}</Text>}
        </>
      )}
      <Field
        testID="feedback-message-input"
        label={kind === "bug" ? "What went wrong?" : kind === "idea" ? "Your idea" : "Your message"}
        placeholder={kind === "bug" ? "e.g. The alarm didn't ring at 9:00 when the phone was locked" : "Type here…"}
        value={message}
        onChangeText={setMessage}
        multiline
        maxLength={2000}
        error={kind === "bug" && !area ? null : error}
      />
      <Button label="Send" icon="send" onPress={send} loading={sending} disabled={!message.trim()} testID="feedback-send-button" />
    </Sheet>
  );
}

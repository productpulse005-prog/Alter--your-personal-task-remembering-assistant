import Feather from "@react-native-vector-icons/feather";
import React, { useState } from "react";
import { Pressable, Text, View } from "react-native";

import type { Priority } from "@/src/api";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

const OPTIONS: { key: Priority; label: string }[] = [
  { key: "high", label: "High" },
  { key: "medium", label: "Medium" },
  { key: "low", label: "Low" },
];

export function usePriorityColor() {
  const { colors } = useTheme();
  return (p: Priority) => (p === "urgent" ? colors.error : p === "high" ? colors.warning : p === "medium" ? colors.brandSecondary : colors.borderStrong);
}

/** Dropdown for High / Medium / Low (Urgent only shows when a task already has it). */
export function PriorityPicker({ value, onChange, testID }: { value: Priority; onChange: (p: Priority) => void; testID: string }) {
  const [open, setOpen] = useState(false);
  const s = useStyles();
  const { colors } = useTheme();
  const color = usePriorityColor();
  const options = value === "urgent" ? [{ key: "urgent" as Priority, label: "Urgent" }, ...OPTIONS] : OPTIONS;
  const current = options.find((o) => o.key === value) ?? OPTIONS[1];
  return (
    <View>
      <Pressable testID={testID} onPress={() => setOpen(!open)} style={s.field} accessibilityRole="button" accessibilityLabel={`Priority: ${current.label}`}>
        <View style={[s.dot, { backgroundColor: color(current.key) }]} />
        <Text style={s.value}>{current.label}</Text>
        <Feather name={open ? "chevron-up" : "chevron-down"} size={18} color={colors.muted} />
      </Pressable>
      {open ? (
        <View style={s.menu} testID={`${testID}-menu`}>
          {options.map((o) => (
            <Pressable
              key={o.key}
              testID={`${testID}-${o.key}`}
              onPress={() => { onChange(o.key); setOpen(false); }}
              style={({ pressed }) => [s.item, (pressed || o.key === value) && { backgroundColor: colors.surfaceTertiary }]}
            >
              <View style={[s.dot, { backgroundColor: color(o.key) }]} />
              <Text style={s.value}>{o.label}</Text>
              {o.key === value ? <Feather name="check" size={16} color={colors.brandPrimary} /> : null}
            </Pressable>
          ))}
        </View>
      ) : null}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  field: { minHeight: 48, flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.lg, borderRadius: radius.md, borderWidth: 1, borderColor: c.border, backgroundColor: c.surface },
  value: { flex: 1, fontFamily: fonts.textMedium, fontSize: 15, color: c.onSurface },
  dot: { width: 10, height: 10, borderRadius: 5 },
  menu: { marginTop: spacing.xs, borderRadius: radius.md, borderWidth: 1, borderColor: c.border, backgroundColor: c.surface, overflow: "hidden" },
  item: { minHeight: 48, flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.lg },
}));

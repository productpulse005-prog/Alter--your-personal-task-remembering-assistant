import { useQuery, useQueryClient } from "@tanstack/react-query";
import dayjs from "dayjs";
import React, { useEffect, useState } from "react";
import { Text, View } from "react-native";

import { api, FamilyInfo, Priority, Task, TaskStatus } from "@/src/api";
import { useAuth } from "@/src/auth";
import { useToast } from "@/src/components/toast";
import { PriorityPicker } from "@/src/components/PriorityPicker";
import { Button, Chip, ConfirmSheet, Field, Segmented, Sheet } from "@/src/components/ui";
import { PRIORITIES, STATUSES } from "@/src/labels";
import { celebrate } from "@/src/mascot";
import { fonts, spacing, useTheme } from "@/src/theme";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
type Repeat = "once" | "daily" | "weekdays" | "weekly" | "monthly";
const REPEATS: { key: Repeat; label: string }[] = [
  { key: "once", label: "Once" },
  { key: "daily", label: "Every day" },
  { key: "weekdays", label: "Weekdays" },
  { key: "weekly", label: "Every week" },
  { key: "monthly", label: "Every month" },
];

export function TaskSheet({ visible, task, onClose, initialTitle = "" }: { visible: boolean; task: Task | null; onClose: () => void; initialTitle?: string }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [dueTime, setDueTime] = useState("");
  const [priority, setPriority] = useState<Priority>("medium");
  const [status, setStatus] = useState<TaskStatus>("todo");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [assignedTo, setAssignedTo] = useState<string | null>(null);
  const [confidential, setConfidential] = useState(false);
  const [alarm, setAlarm] = useState(false);
  const [repeat, setRepeat] = useState<Repeat>("once");
  const qc = useQueryClient();
  const toast = useToast();
  const { colors } = useTheme();
  const { user } = useAuth();
  const family = useQuery({ queryKey: ["family"], queryFn: () => api<FamilyInfo>("/family"), enabled: visible });
  const readOnly = !!task && !!user && task.user_id !== user.id;
  // another family member's plan (not assigned to me): view only
  const familyView = readOnly && task?.assigned_to !== user?.id;
  const others = (family.data?.members ?? []).filter((m) => m.user_id !== user?.id);

  useEffect(() => {
    if (visible) {
      setTitle(task?.title ?? initialTitle);
      setDescription(task?.description ?? "");
      setDueDate(task ? task.due_date ?? "" : dayjs().format("YYYY-MM-DD"));
      setDueTime(task?.due_time ?? "");
      setPriority(task?.priority ?? "medium");
      setStatus(task?.status ?? "todo");
      setAssignedTo(task?.assigned_to ?? null);
      setConfidential(!!task?.confidential);
      setAlarm(!!task?.alarm);
      setRepeat((task?.recurrence as Repeat | null | undefined) ?? "once");
      setErrors({});
    }
  }, [visible, task]); // eslint-disable-line react-hooks/exhaustive-deps

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["tasks"] });
    qc.invalidateQueries({ queryKey: ["dashboard"] });
    qc.invalidateQueries({ queryKey: ["summary"] });
  };

  const save = async () => {
    const e: Record<string, string> = {};
    if (!title.trim()) e.title = "Give the task a title";
    if (dueDate && (!DATE_RE.test(dueDate) || !dayjs(dueDate).isValid())) e.dueDate = "Use YYYY-MM-DD";
    if (dueTime && !TIME_RE.test(dueTime)) e.dueTime = "Use HH:MM (24h)";
    if (dueTime && !dueDate) e.dueTime = "Add a date for this time";
    if (alarm && !dueTime) e.dueTime = "Add a time for the alarm";
    setErrors(e);
    if (Object.keys(e).length) return;
    setSaving(true);
    const body = readOnly
      ? { status }
      : { title: title.trim(), description: description.trim(), due_date: dueDate || null, due_time: dueTime || null, priority, status, assigned_to: assignedTo, confidential, alarm,
          ...(alarm || task?.alarm ? { recurrence: alarm && repeat !== "once" ? repeat : null } : {}) };
    try {
      if (task) {
        await api(`/tasks/${task.id}`, { method: "PUT", body });
        toast(status === "completed" && task.status !== "completed" ? "Task completed" : "Task updated");
      } else {
        await api("/tasks", { method: "POST", body });
        toast("Task created");
      }
      if (status === "completed" && task?.status !== "completed") celebrate(dueDate || null);
      refresh();
      onClose();
    } catch (err: any) {
      setErrors({ form: err.message });
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!task) return;
    setDeleting(true);
    try {
      await api(`/tasks/${task.id}`, { method: "DELETE" });
      toast("Task deleted");
      refresh();
      setConfirm(false);
      onClose();
    } catch (err: any) {
      toast(err.message, "error");
    } finally {
      setDeleting(false);
    }
  };

  const quick = [
    { key: "today", label: "Today", value: dayjs().format("YYYY-MM-DD") },
    { key: "tomorrow", label: "Tomorrow", value: dayjs().add(1, "day").format("YYYY-MM-DD") },
    { key: "week", label: "Next week", value: dayjs().add(7, "day").format("YYYY-MM-DD") },
  ];
  const lbl = { fontFamily: fonts.textMedium, fontSize: 12, color: colors.muted, textTransform: "uppercase" as const, letterSpacing: 0.8 };

  return (
    <>
      <Sheet visible={visible && !confirm} onClose={onClose} title={task ? (familyView ? "Family plan" : readOnly ? "Assigned to you" : "Edit task") : "New task"} testID="task-sheet">
        {readOnly ? (
          <View style={{ gap: spacing.sm }}>
            <Text style={{ fontFamily: fonts.display, fontSize: 20, color: colors.onSurface }}>{task?.title}</Text>
            {task?.description ? <Text style={{ fontFamily: fonts.text, fontSize: 14, color: colors.onSurfaceSecondary }}>{task.description}</Text> : null}
            <Text style={{ fontFamily: fonts.text, fontSize: 13, color: colors.muted }} testID="task-from-label">
              {`From ${task?.owner_name || "a family member"} · ${PRIORITIES.find((p) => p.key === task?.priority)?.label} priority${task?.due_date ? ` · ${task.due_date}${task.due_time ? ` ${task.due_time}` : ""}` : ""}`}
            </Text>
          </View>
        ) : (
          <>
        <Field testID="task-title-input" label="Title" placeholder="What needs doing?" value={title} onChangeText={setTitle} maxLength={200} error={errors.title} />
        <Field testID="task-description-input" label="Description" placeholder="Optional details" value={description} onChangeText={setDescription} multiline maxLength={2000} />
        <Text style={lbl}>Due (defaults to today)</Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm }}>
          {quick.map((q) => (
            <Chip key={q.key} label={q.label} selected={dueDate === q.value} onPress={() => setDueDate(q.value)} testID={`task-due-${q.key}`} />
          ))}
        </View>
        <View style={{ flexDirection: "row", gap: spacing.md }}>
          <View style={{ flex: 3 }}>
            <Field testID="task-due-date-input" placeholder="YYYY-MM-DD" value={dueDate} onChangeText={setDueDate} maxLength={10} error={errors.dueDate} autoCapitalize="none" />
          </View>
          <View style={{ flex: 2 }}>
            <Field testID="task-due-time-input" placeholder="HH:MM" value={dueTime} onChangeText={setDueTime} maxLength={5} error={errors.dueTime} autoCapitalize="none" />
          </View>
        </View>
        <Text style={lbl}>Priority</Text>
        <PriorityPicker value={priority} onChange={setPriority} testID="task-priority" />
        <Chip
          label={alarm ? "Alarm on · rings at the set time" : "Ring an alarm at this time"}
          icon="bell"
          selected={alarm}
          onPress={() => setAlarm(!alarm)}
          testID="task-alarm-toggle"
        />
        {alarm ? (
          <>
            <Text style={lbl}>Repeat</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm }} testID="task-repeat">
              {REPEATS.map((r) => (
                <Chip key={r.key} label={r.label} selected={repeat === r.key} onPress={() => setRepeat(r.key)} testID={`task-repeat-${r.key}`} />
              ))}
            </View>
          </>
        ) : null}
        <Chip
          label={confidential ? "Confidential · only you can see it" : "Mark as confidential"}
          icon="lock"
          selected={confidential}
          onPress={() => setConfidential(!confidential)}
          testID="task-confidential-toggle"
        />
        {others.length ? (
          <>
            <Text style={lbl}>Assign to</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm }}>
              <Chip label="Me" icon="user" selected={!assignedTo} onPress={() => setAssignedTo(null)} testID="task-assign-me" />
              {others.map((m) => (
                <Chip key={m.user_id} label={m.display_name} selected={assignedTo === m.user_id} onPress={() => setAssignedTo(m.user_id)} testID={`task-assign-${m.user_id}`} />
              ))}
            </View>
          </>
        ) : null}
          </>
        )}
        {familyView ? (
          <Button label="Close" variant="secondary" onPress={onClose} testID="task-close-button" />
        ) : (
          <>
            <Text style={lbl}>Status</Text>
            <Segmented options={STATUSES} value={status} onChange={setStatus} testID="task-status" />
            {errors.form ? <Text style={{ color: colors.error, fontFamily: fonts.text }} testID="task-form-error">{errors.form}</Text> : null}
            <Button label={task ? "Save changes" : "Create task"} onPress={save} loading={saving} testID="task-save-button" />
          </>
        )}
        {task && !readOnly ? <Button label="Delete task" variant="ghost" icon="trash-2" onPress={() => setConfirm(true)} testID="task-delete-button" /> : null}
      </Sheet>
      <ConfirmSheet
        visible={confirm}
        title="Delete this task?"
        message="This can't be undone."
        confirmLabel="Delete"
        loading={deleting}
        onConfirm={remove}
        onClose={() => setConfirm(false)}
        testID="task-delete-confirm"
      />
    </>
  );
}

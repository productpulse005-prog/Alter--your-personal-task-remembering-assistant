import Feather from "@react-native-vector-icons/feather";
import { useQuery } from "@tanstack/react-query";
import { useFocusEffect } from "expo-router";
import React, { useCallback } from "react";
import { Text, View } from "react-native";

import { api, ChoreBoard } from "@/src/api";
import { useAuth } from "@/src/auth";
import { ErrorState, Skeleton } from "@/src/components/ui";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

// Weekly fairness view: who finished the most and who has the most open.
export function ChoreBoardCard() {
  const s = useStyles();
  const { colors } = useTheme();
  const { user } = useAuth();
  const q = useQuery({ queryKey: ["family-board"], queryFn: () => api<ChoreBoard>("/family/board") });
  useFocusEffect(useCallback(() => { q.refetch(); }, [q.refetch])); // eslint-disable-line react-hooks/exhaustive-deps

  const rows = q.data?.members ?? [];
  const maxDone = Math.max(1, ...rows.map((r) => r.completed_week));
  const maxOpen = Math.max(0, ...rows.map((r) => r.open));
  const minOpen = Math.min(...rows.map((r) => r.open));
  const topDone = rows.length && rows[0].completed_week > 0 ? rows[0].user_id : null;
  const busiest = maxOpen > 0 ? rows.find((r) => r.open === maxOpen)?.user_id : null;
  const lightest = rows.find((r) => r.open === minOpen);
  const showTip = rows.length > 1 && maxOpen - minOpen >= 3 && lightest;

  return (
    <View style={s.card} testID="chore-board">
      <View style={s.head}>
        <Text style={s.title}>Chore board</Text>
        <Text style={s.sub}>This week</Text>
      </View>
      {q.isLoading ? (
        <Skeleton rows={2} height={48} />
      ) : q.isError ? (
        <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} testID="chore-board-error" />
      ) : (
        <>
          {rows.map((r) => (
            <View key={r.user_id} style={s.row} testID={`chore-row-${r.user_id}`}>
              <View style={s.nameRow}>
                <Text style={s.name} numberOfLines={1}>{r.display_name}{r.user_id === user?.id ? " (you)" : ""}</Text>
                {r.user_id === topDone ? (
                  <View style={[s.badge, { backgroundColor: colors.brandTertiary }]} testID={`chore-top-${r.user_id}`}>
                    <Feather name="award" size={11} color={colors.onBrandTertiary} />
                    <Text style={[s.badgeText, { color: colors.onBrandTertiary }]}>Most done</Text>
                  </View>
                ) : null}
                {r.user_id === busiest && rows.length > 1 ? (
                  <View style={[s.badge, { borderWidth: 1, borderColor: colors.warning }]} testID={`chore-busiest-${r.user_id}`}>
                    <Text style={[s.badgeText, { color: colors.warning }]}>Most open</Text>
                  </View>
                ) : null}
              </View>
              <View style={s.track}>
                <View style={[s.bar, { width: `${(r.completed_week / maxDone) * 100}%` }]} />
              </View>
              <Text style={s.stats} testID={`chore-stats-${r.user_id}`}>
                {`${r.completed_week} done · ${r.open} open`}
                {r.overdue ? <Text style={{ color: colors.error }}>{` · ${r.overdue} overdue`}</Text> : null}
              </Text>
            </View>
          ))}
          {showTip ? (
            <Text style={s.tip} testID="chore-board-tip">{`To keep things fair, consider giving the next chore to ${lightest!.display_name}.`}</Text>
          ) : null}
        </>
      )}
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  card: { borderWidth: 1, borderColor: c.border, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.lg, backgroundColor: c.surface },
  head: { flexDirection: "row", justifyContent: "space-between", alignItems: "baseline" },
  title: { fontFamily: fonts.display, fontSize: 20, color: c.onSurface },
  sub: { fontFamily: fonts.textMedium, fontSize: 12, color: c.muted },
  row: { gap: 6 },
  nameRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  name: { flexShrink: 1, fontFamily: fonts.textMedium, fontSize: 15, color: c.onSurface },
  badge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: spacing.sm, height: 22, borderRadius: radius.pill },
  badgeText: { fontFamily: fonts.textMedium, fontSize: 11 },
  track: { height: 8, borderRadius: 4, backgroundColor: c.surfaceTertiary, overflow: "hidden" },
  bar: { height: 8, borderRadius: 4, backgroundColor: c.brandPrimary },
  stats: { fontFamily: fonts.text, fontSize: 12, color: c.muted },
  tip: { fontFamily: fonts.text, fontSize: 13, color: c.onSurfaceSecondary, lineHeight: 19 },
}));

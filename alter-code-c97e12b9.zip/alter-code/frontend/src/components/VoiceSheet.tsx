import Feather from "@react-native-vector-icons/feather";
import { useQueryClient } from "@tanstack/react-query";
import {
  getRecordingPermissionsAsync,
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from "expo-audio";
import React, { useEffect, useRef, useState } from "react";
import { ActivityIndicator, Linking, Pressable, Text, View } from "react-native";

import { ChatAction, voiceCapture } from "@/src/api";
import { Button, Sheet } from "@/src/components/ui";
import { fonts, makeStyles, radius, spacing, useTheme } from "@/src/theme";

type Phase = "idle" | "listening" | "processing" | "result";
type Perm = "granted" | "undetermined" | "denied" | "blocked";

const MAX_MS = 90_000;

export function VoiceSheet({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const s = useStyles();
  const { colors } = useTheme();
  const qc = useQueryClient();
  const recorder = useAudioRecorder({ ...RecordingPresets.HIGH_QUALITY, isMeteringEnabled: true });
  const rec = useAudioRecorderState(recorder, 150);
  const [phase, setPhase] = useState<Phase>("idle");
  const [perm, setPerm] = useState<Perm>("undetermined");
  const [error, setError] = useState<string | null>(null);
  const [transcript, setTranscript] = useState("");
  const [results, setResults] = useState<ChatAction[]>([]);
  const busy = useRef(false);
  const watchdog = useRef<ReturnType<typeof setTimeout> | null>(null);
  const turn = useRef(0);

  useEffect(() => {
    if (!visible) return;
    setPhase("idle");
    setError(null);
    setTranscript("");
    setResults([]);
    getRecordingPermissionsAsync()
      .then((p) => setPerm(p.granted ? "granted" : p.status === "undetermined" ? "undetermined" : p.canAskAgain ? "denied" : "blocked"))
      .catch(() => {});
  }, [visible]);

  useEffect(
    () => () => {
      if (watchdog.current) clearTimeout(watchdog.current);
      try {
        if (recorder.isRecording) recorder.stop().catch(() => {});
      } catch {
        // recorder already released on unmount
      }
    },
    [recorder],
  );

  const start = async () => {
    if (busy.current) return;
    busy.current = true;
    setError(null);
    try {
      const current = await getRecordingPermissionsAsync();
      if (!current.granted) {
        const req = await requestRecordingPermissionsAsync();
        if (!req.granted) {
          setPerm(req.canAskAgain ? "denied" : "blocked");
          return;
        }
      }
      setPerm("granted");
      await setAudioModeAsync({ allowsRecording: true, playsInSilentMode: true });
      await recorder.prepareToRecordAsync();
      recorder.record();
      setPhase("listening");
      watchdog.current = setTimeout(() => stop(), MAX_MS);
    } catch (e: any) {
      setError(`Couldn't start the microphone. ${e?.message ?? ""}`.trim());
      setPhase("idle");
    } finally {
      busy.current = false;
    }
  };

  const stop = async () => {
    if (watchdog.current) clearTimeout(watchdog.current);
    const myTurn = ++turn.current;
    const durationMs = rec.durationMillis;
    try {
      await recorder.stop();
    } catch {
      // already stopped
    }
    await setAudioModeAsync({ allowsRecording: false, playsInSilentMode: true }).catch(() => {});
    const uri = recorder.uri;
    if (!uri || durationMs < 600) {
      setError("That was too short. Tap the mic and speak your tasks or groceries.");
      setPhase("idle");
      return;
    }
    setPhase("processing");
    try {
      const r = await voiceCapture(uri);
      if (myTurn !== turn.current) return;
      setTranscript(r.transcript);
      setResults(r.results);
      if (r.error) setError(r.error);
      if (r.clarify) setError(`Alter needs a detail: ${r.clarify} Please record again with it.`);
      setPhase("result");
      ["tasks", "groceries", "dashboard"].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
    } catch (e: any) {
      if (myTurn !== turn.current) return;
      setError(e.message);
      setPhase("idle");
    }
  };

  const close = () => {
    if (phase === "listening") {
      try {
        recorder.stop().catch(() => {});
      } catch {
        // ignore
      }
      if (watchdog.current) clearTimeout(watchdog.current);
    }
    turn.current++;
    onClose();
  };

  const level = rec.metering != null ? Math.max(0, Math.min(1, (rec.metering + 60) / 60)) : 0.2;
  const secs = Math.floor((rec.durationMillis ?? 0) / 1000);

  return (
    <Sheet visible={visible} onClose={close} title="Speak to Alter" testID="voice-sheet">
      {phase === "result" ? (
        <View style={{ gap: spacing.lg }} testID="voice-result">
          <View style={s.quote}>
            <Text style={s.quoteLabel}>YOU SAID</Text>
            <Text style={s.quoteText} testID="voice-transcript">{`“${transcript}”`}</Text>
          </View>
          {results.length ? (
            results.map((a, i) => {
              const ok = a.status === "success";
              const isGrocery = a.type === "add_grocery";
              return (
                <View key={i} style={[s.result, { borderLeftColor: ok ? colors.success : colors.error }]} testID={`voice-result-${a.type}-${i}`}>
                  <View style={{ flexDirection: "row", gap: spacing.sm, alignItems: "center" }}>
                    <Feather name={isGrocery ? "shopping-cart" : "check-square"} size={14} color={ok ? colors.success : colors.error} />
                    <Text style={[s.resultDetail, { color: ok ? colors.success : colors.error }]}>{a.detail}</Text>
                  </View>
                  <Text style={s.resultText}>{a.data?.content || a.data?.title || ""}</Text>
                  {!isGrocery && ok ? (
                    <Text style={s.resultMeta}>{[a.data?.priority?.toUpperCase(), a.data?.due_date, a.data?.due_time].filter(Boolean).join(" · ")}</Text>
                  ) : null}
                </View>
              );
            })
          ) : (
            <Text style={s.hint} testID="voice-nothing">Nothing to add from that. Try naming a task or grocery items.</Text>
          )}
          {error ? <Text style={s.error}>{error}</Text> : null}
          <Text style={s.hint}>You can change any priority or date from the Tasks tab.</Text>
          <View style={{ flexDirection: "row", gap: spacing.md }}>
            <Button label="Speak again" variant="secondary" icon="mic" onPress={() => { setPhase("idle"); start(); }} style={{ flex: 1 }} testID="voice-again-button" />
            <Button label="Done" onPress={close} style={{ flex: 1 }} testID="voice-done-button" />
          </View>
        </View>
      ) : (
        <View style={{ alignItems: "center", gap: spacing.lg }}>
          <Text style={s.lead}>
            {phase === "listening"
              ? "Listening… tap stop when you're done."
              : phase === "processing"
                ? "Organising your tasks and groceries…"
                : "Speak in any language. Say tasks or groceries, e.g. “Pay the electricity bill tomorrow at 5pm, and we need milk and eggs.”"}
          </Text>
          <View style={[s.ring, phase === "listening" && { transform: [{ scale: 1 + level * 0.25 }], borderColor: colors.brandSecondary }]}>
            {phase === "processing" ? (
              <ActivityIndicator color={colors.brandPrimary} size="large" testID="voice-processing" />
            ) : (
              <Pressable
                testID={phase === "listening" ? "voice-stop-button" : "voice-record-button"}
                onPress={phase === "listening" ? stop : start}
                disabled={perm === "blocked"}
                style={[s.mic, phase === "listening" && { backgroundColor: colors.error }, perm === "blocked" && { opacity: 0.4 }]}
                accessibilityLabel={phase === "listening" ? "Stop recording" : "Start recording"}
              >
                <Feather name={phase === "listening" ? "square" : "mic"} size={30} color={colors.onBrandPrimary} />
              </Pressable>
            )}
          </View>
          {phase === "listening" ? <Text style={s.timer} testID="voice-timer">{`0:${String(secs).padStart(2, "0")}`}</Text> : null}
          {phase === "idle" && perm !== "granted" ? (
            <Text style={s.hint}>Alter needs the microphone to hear you. Audio is only used to transcribe this note.</Text>
          ) : null}
          {perm === "blocked" ? (
            <Button label="Open Settings" variant="secondary" icon="settings" onPress={() => Linking.openSettings()} testID="voice-open-settings" />
          ) : null}
          {perm === "denied" && phase === "idle" ? <Text style={s.error}>Microphone access was denied. Tap the mic to allow it.</Text> : null}
          {error ? <Text style={s.error} testID="voice-error">{error}</Text> : null}
        </View>
      )}
    </Sheet>
  );
}

const useStyles = makeStyles((c) => ({
  lead: { fontFamily: fonts.display, fontSize: 18, lineHeight: 26, color: c.onSurface, textAlign: "center" },
  ring: { width: 132, height: 132, borderRadius: 66, borderWidth: 2, borderColor: c.border, alignItems: "center", justifyContent: "center", marginVertical: spacing.md },
  mic: { width: 96, height: 96, borderRadius: 48, backgroundColor: c.brandPrimary, alignItems: "center", justifyContent: "center" },
  timer: { fontFamily: fonts.textMedium, fontSize: 16, color: c.onSurfaceSecondary },
  hint: { fontFamily: fonts.text, fontSize: 13, color: c.muted, textAlign: "center", lineHeight: 19 },
  error: { fontFamily: fonts.text, fontSize: 13, color: c.error, textAlign: "center" },
  quote: { backgroundColor: c.surfaceSecondary, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.xs, borderWidth: 1, borderColor: c.border },
  quoteLabel: { fontFamily: fonts.textMedium, fontSize: 11, letterSpacing: 1.2, color: c.muted },
  quoteText: { fontFamily: fonts.display, fontSize: 16, lineHeight: 23, color: c.onSurface },
  result: { borderLeftWidth: 3, borderWidth: 1, borderColor: c.border, borderRadius: radius.md, padding: spacing.md, gap: 4 },
  resultDetail: { fontFamily: fonts.textMedium, fontSize: 12 },
  resultText: { fontFamily: fonts.display, fontSize: 16, color: c.onSurface },
  resultMeta: { fontFamily: fonts.text, fontSize: 12, color: c.muted },
}));

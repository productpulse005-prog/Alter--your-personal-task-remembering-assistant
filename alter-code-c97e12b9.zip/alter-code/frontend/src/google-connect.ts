import * as Linking from "expo-linking";
import * as WebBrowser from "expo-web-browser";
import { Platform } from "react-native";

import { api } from "@/src/api";

/** Opens Google's one-time approval for the signed-in user's OWN account. Returns the result code (connected/cancelled/...). */
export async function startGoogleConnect(): Promise<string | undefined> {
  const returnUrl = Platform.OS === "web" ? `${window.location.origin}/profile` : Linking.createURL("profile");
  const r = await api<{ url: string }>("/gmail/connect", { method: "POST", body: { return_url: returnUrl } });
  if (Platform.OS === "web") {
    window.location.href = r.url;
    return undefined;
  }
  const res = await WebBrowser.openAuthSessionAsync(r.url, returnUrl);
  return res.type === "success" ? res.url.match(/[?&]gmail=([a-z]+)/)?.[1] : "cancelled";
}

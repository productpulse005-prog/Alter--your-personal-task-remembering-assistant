// On-time task alarm that behaves like the phone's alarm clock: full-screen over other apps and the
// lock screen, looping alarm sound, fired by AlarmManager even when Alter is closed or swiped away.
// Needs the native module, so it's only active in real builds (APK), not in Expo Go.
import Constants, { ExecutionEnvironment } from "expo-constants";

import type { Task } from "@/src/api";

type Kit = typeof import("react-native-notify-kit");
let kit: Kit | null = null;
if (Constants.executionEnvironment !== ExecutionEnvironment.StoreClient) {
  try {
    kit = require("react-native-notify-kit") as Kit;
  } catch (e) {
    console.warn("full-screen alarms unavailable", e);
  }
}

export const fullScreenSupported = !!kit;
const CHANNEL = "alter-fullscreen-alarm-v1";
const PREFIX = "alter-alarm-";
export const SNOOZE_PREFIX = "alter-snooze-"; // not cleared when task alarms are re-synced
let channelReady = false;

async function ensureChannel() {
  if (!kit || channelReady) return;
  await kit.default.createChannel({
    id: CHANNEL,
    name: "Full-screen task alarms",
    importance: kit.AndroidImportance.HIGH,
    sound: "alarm", // res/raw/alarm.wav (bundled by the expo-notifications plugin)
    vibration: true,
    vibrationPattern: [300, 800, 400, 800],
    bypassDnd: true,
    visibility: kit.AndroidVisibility.PUBLIC,
  });
  channelReady = true;
}

export async function scheduleFullScreenAlarm(t: Task, at: Date, body: string, id = `${PREFIX}${t.id}`) {
  if (!kit) return;
  await ensureChannel();
  const action = { id: "default", launchActivity: "default" };
  await kit.default.createTriggerNotification(
    {
      id,
      title: `⏰ It's time: ${t.title}`,
      body,
      data: { kind: "alarm", taskId: t.id, title: t.title },
      android: {
        channelId: CHANNEL,
        category: kit.AndroidCategory.ALARM,
        importance: kit.AndroidImportance.HIGH,
        visibility: kit.AndroidVisibility.PUBLIC,
        fullScreenAction: action,
        pressAction: action,
        sound: "alarm",
        loopSound: true,
        autoCancel: false,
        timeoutAfter: 2 * 60 * 1000, // stop ringing after 2 minutes if nobody answers
      },
    },
    // setAlarmClock: the same API as the phone's clock app; exempt from battery saving / Doze, so it rings on time
    { type: kit.TriggerType.TIMESTAMP, timestamp: at.getTime(), alarmManager: { type: kit.AlarmType.SET_ALARM_CLOCK } },
  );
}

/** Android 12+: exact alarms can be switched off for the app. Returns false when the user must allow them. */
export async function exactAlarmsAllowed(): Promise<boolean> {
  if (!kit) return true;
  const st = await kit.default.getNotificationSettings();
  return st.android.alarm !== kit.AndroidNotificationSetting.DISABLED;
}

export async function openAlarmSettings() {
  await kit?.default.openAlarmPermissionSettings();
}

export async function cancelFullScreenAlarms(onlyId?: string) {
  if (!kit) return;
  const ids = (await kit.default.getTriggerNotificationIds()).filter((id) => (onlyId ? id === onlyId : id.startsWith(PREFIX) && id !== `${PREFIX}test`));
  if (ids.length) await kit.default.cancelTriggerNotifications(ids);
}

/** Silences a ringing alarm (all of them when no task id is given). */
export async function dismissFullScreenAlarm(taskId?: string) {
  if (!kit) return;
  const shown = await kit.default.getDisplayedNotifications();
  const ids = shown.map((n) => n.id ?? "").filter((id) => id.startsWith(taskId ? `${PREFIX}${taskId}` : PREFIX) || id.startsWith(SNOOZE_PREFIX));
  if (ids.length) await kit.default.cancelDisplayedNotifications(ids);
}

/** Opens Alter's ringing screen when the alarm launched/was tapped, or fired while Alter was open. */
export function listenFullScreenAlarms(onRing: (a: { taskId: string; title: string; heading: string }) => void) {
  if (!kit) return () => {};
  const k = kit;
  const ring = (n?: { title?: string; data?: Record<string, unknown> }) => {
    const d = n?.data as { kind?: string; taskId?: string; title?: string } | undefined;
    if (d?.kind === "alarm") onRing({ taskId: d.taskId ?? "", title: d.title ?? "task", heading: n?.title ?? "It's time" });
  };
  k.default.getInitialNotification().then((i) => ring(i?.notification)).catch(() => {});
  return k.default.onForegroundEvent(({ type, detail }) => {
    if (type === k.EventType.DELIVERED || type === k.EventType.PRESS) {
      ring(detail.notification);
      // the in-app alarm takes over, so quiet the system one
      if (detail.notification?.id) k.default.cancelDisplayedNotification(detail.notification.id).catch(() => {});
    }
  });
}

kit?.default.onBackgroundEvent(async () => {});

import * as Linking from "expo-linking";
import * as WebBrowser from "expo-web-browser";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { AppState, Platform } from "react-native";

import { api, Profile, setOnUnauthorized, TOKEN_KEY } from "@/src/api";
import { queryClient } from "@/src/query-client";
import { storage } from "@/src/utils/storage";

type User = { id: string; email: string; role?: "user" | "admin"; beta_access?: boolean };
type AuthState = {
  status: "loading" | "signedOut" | "signedIn";
  user: User | null;
  profile: Profile | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (name: string, email: string, password: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  onboardGoogle: boolean;
  finishOnboarding: () => void;
  signOut: () => Promise<void>;
  setProfile: (p: Profile) => void;
};

const AuthContext = createContext<AuthState | null>(null);

WebBrowser.maybeCompleteAuthSession();
const GOOGLE_AUTH_URL = "https://auth.emergentagent.com/?redirect=";
const usedSessionIds = new Set<string>();
const sessionIdFrom = (url?: string | null) => url?.match(/[?#&]session_id=([^&#]+)/)?.[1] ?? null;

function cleanWebUrl() {
  const { pathname, search, hash } = window.location;
  const strip = (s: string, lead: string) => {
    const p = new URLSearchParams(s.slice(1));
    p.delete("session_id");
    const out = p.toString();
    return out ? lead + out : "";
  };
  window.history.replaceState(window.history.state, "", pathname + strip(search, "?") + strip(hash, "#"));
}

function deviceTimeZone() {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  } catch {
    return "UTC";
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<AuthState["status"]>("loading");
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [onboardGoogle, setOnboardGoogle] = useState(false);
  const finishOnboarding = useCallback(() => setOnboardGoogle(false), []);

  const signOut = useCallback(async () => {
    await storage.secureRemove(TOKEN_KEY);
    queryClient.clear();
    setUser(null);
    setProfile(null);
    setStatus("signedOut");
  }, []);

  const loadMe = useCallback(async () => {
    const me = await api<{ user: User; profile: Profile }>("/auth/me");
    setUser(me.user);
    setProfile(me.profile);
    setStatus("signedIn");
    // keep Alter's clock in the user's real local time zone (device is the source of truth)
    const tz = deviceTimeZone();
    if (tz && tz !== "UTC" && me.profile.timezone !== tz) {
      api<Profile>("/profile", { method: "PUT", body: { timezone: tz } }).then(setProfile).catch(() => {});
    }
  }, []);

  // follow the phone when its time zone changes (travel, manual change) while Alter is in the background
  useEffect(() => {
    if (status !== "signedIn") return;
    const sub = AppState.addEventListener("change", (st) => {
      const tz = deviceTimeZone();
      if (st === "active" && tz && tz !== "UTC" && profile && profile.timezone !== tz) {
        api<Profile>("/profile", { method: "PUT", body: { timezone: tz } }).then(setProfile).catch(() => {});
      }
    });
    return () => sub.remove();
  }, [status, profile]);

  // Exchange a one-time Google session_id for our own app token (guarded against double-sends).
  const exchangeGoogle = useCallback(
    async (sessionId: string) => {
      if (usedSessionIds.has(sessionId)) return false;
      usedSessionIds.add(sessionId);
      const r = await api<{ token: string; is_new?: boolean }>("/auth/google", { method: "POST", body: { session_id: sessionId } });
      await storage.secureSet(TOKEN_KEY, r.token);
      if (r.is_new) setOnboardGoogle(true);
      await loadMe();
      return true;
    },
    [loadMe],
  );

  useEffect(() => {
    setOnUnauthorized(() => void signOut());
    (async () => {
      const incoming = Platform.OS === "web" ? sessionIdFrom(window.location.href) : sessionIdFrom(await Linking.getInitialURL());
      if (incoming) {
        try {
          if (await exchangeGoogle(incoming)) {
            if (Platform.OS === "web") cleanWebUrl();
            return;
          }
        } catch {
          if (Platform.OS === "web") cleanWebUrl();
        }
      }
      const token = await storage.secureGet(TOKEN_KEY, "");
      if (!token) return setStatus("signedOut");
      try {
        await loadMe();
      } catch (e: any) {
        if (e?.status === 401) await signOut();
        else setStatus("signedOut");
      }
    })();
    // hot deep links (native) carrying a Google session
    const sub = Platform.OS === "web" ? null : Linking.addEventListener("url", ({ url }) => {
      const sid = sessionIdFrom(url);
      if (sid) exchangeGoogle(sid).catch(() => {});
    });
    return () => {
      setOnUnauthorized(null);
      sub?.remove();
    };
  }, [loadMe, signOut, exchangeGoogle]);

  const signInWithGoogle = useCallback(async () => {
    if (Platform.OS === "web") {
      window.location.href = GOOGLE_AUTH_URL + encodeURIComponent(window.location.origin + "/");
      return;
    }
    const redirect = Linking.createURL("");
    let captured: string | null = null;
    const sub = Linking.addEventListener("url", ({ url }) => { captured = url; });
    try {
      const result = await WebBrowser.openAuthSessionAsync(GOOGLE_AUTH_URL + encodeURIComponent(redirect), redirect);
      const url = (result.type === "success" ? result.url : null) ?? captured ?? (await Linking.getInitialURL());
      const sid = sessionIdFrom(url);
      if (!sid) {
        if (result.type === "success") throw new Error("Google sign-in didn't complete. Please try again.");
        return; // user cancelled
      }
      await exchangeGoogle(sid);
    } finally {
      sub.remove();
    }
  }, [exchangeGoogle]);

  const signIn = useCallback(
    async (email: string, password: string) => {
      const r = await api<{ token: string }>("/auth/login", { method: "POST", body: { email, password } });
      await storage.secureSet(TOKEN_KEY, r.token);
      await loadMe();
    },
    [loadMe],
  );

  const signUp = useCallback(
    async (display_name: string, email: string, password: string) => {
      const r = await api<{ token: string }>("/auth/register", {
        method: "POST",
        body: { display_name, email, password, timezone: deviceTimeZone() },
      });
      await storage.secureSet(TOKEN_KEY, r.token);
      setOnboardGoogle(true);
      await loadMe();
    },
    [loadMe],
  );

  const value = useMemo(
    () => ({ status, user, profile, signIn, signUp, signInWithGoogle, onboardGoogle, finishOnboarding, signOut, setProfile }),
    [status, user, profile, signIn, signUp, signInWithGoogle, onboardGoogle, finishOnboarding, signOut],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth outside AuthProvider");
  return ctx;
}

export { deviceTimeZone };

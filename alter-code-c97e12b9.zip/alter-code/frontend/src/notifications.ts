import dayjs from "dayjs";
import * as Notifications from "expo-notifications";
import Constants, { ExecutionEnvironment } from "expo-constants";
import { Platform } from "react-native";

import type { Task } from "@/src/api";
import { cancelFullScreenAlarms, fullScreenSupported, scheduleFullScreenAlarm, SNOOZE_PREFIX } from "@/src/alarm";

export const notificationsSupported = Platform.OS !== "web";
// Web: system notifications via the browser (Windows/macOS toast) + in-page timers while Alter is open in a tab.
const webNotif = Platform.OS === "web" && typeof window !== "undefined" && "Notification" in window;
export const alertsSupported = notificationsSupported || webNotif;
export const isWeb = Platform.OS === "web";

export type FiredAlert = { kind: "alarm" | "pre"; taskId: string; title: string; mins: number; heading: string };
let onFire: ((a: FiredAlert) => void) | null = null;
export const setAlertHandler = (h: ((a: FiredAlert) => void) | null) => { onFire = h; };
export const fireAlert = (a: FiredAlert) => onFire?.(a);
let webTimers: ReturnType<typeof setTimeout>[] = [];
const snoozeTimers: ReturnType<typeof setTimeout>[] = []; // kept apart: alarm re-syncs must not clear a snooze

if (notificationsSupported) {
  Notifications.setNotificationHandler({
    // In the foreground the app rings the ting-ting sound itself (AlertsSync), so the OS stays quiet.
    handleNotification: async (n) => ({
      shouldPlaySound: !(n.request.content.data as { kind?: string })?.kind,
      shouldSetBadge: false,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
}

export type PermState = "granted" | "undetermined" | "denied" | "blocked" | "unsupported";

function toState(p: Notifications.NotificationPermissionsStatus): PermState {
  if (p.granted) return "granted";
  if (p.status === "undetermined") return "undetermined";
  return p.canAskAgain ? "denied" : "blocked";
}

export async function getNotifPermission(): Promise<PermState> {
  if (webNotif) {
    const p = window.Notification.permission;
    return p === "granted" ? "granted" : p === "default" ? "undetermined" : "blocked";
  }
  if (!notificationsSupported) return "unsupported";
  return toState(await Notifications.getPermissionsAsync());
}

export async function requestNotifPermission(): Promise<PermState> {
  if (webNotif) {
    await window.Notification.requestPermission();
    return getNotifPermission();
  }
  if (!notificationsSupported) return "unsupported";
  // Android 13+ only shows the permission prompt once a notification channel exists.
  await ensureChannel();
  return toState(await Notifications.requestPermissionsAsync({
    ios: { allowAlert: true, allowSound: true, allowBadge: false, allowCriticalAlerts: false },
  }));
}

// Custom sounds are only bundled in real builds; Expo Go falls back to the default sound.
const inExpoGo = Constants.executionEnvironment === ExecutionEnvironment.StoreClient;
const SOUND = inExpoGo ? "default" : "tingting.wav"; // short ting for 2h / 1h / 5 min reminders
const ALARM_SOUND = inExpoGo ? "default" : "alarm.wav"; // ~25 s ringing alarm right on time
const CHANNEL = "task-alerts-v2";
const ALARM_CHANNEL = "task-alarm-v3";

async function ensureChannel() {
  if (Platform.OS !== "android") return;
  await Notifications.setNotificationChannelAsync(CHANNEL, {
    name: "Task reminders",
    importance: Notifications.AndroidImportance.MAX,
    sound: SOUND,
    vibrationPattern: [0, 300, 200, 300],
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
  });
  await Notifications.setNotificationChannelAsync(ALARM_CHANNEL, {
    name: "Task alarms (on time)",
    importance: Notifications.AndroidImportance.MAX,
    sound: ALARM_SOUND,
    vibrationPattern: [0, 800, 400, 800, 400, 800],
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
    bypassDnd: true,
    audioAttributes: { usage: Notifications.AndroidAudioUsage.ALARM, contentType: Notifications.AndroidAudioContentType.SONIFICATION },
  });
}

const NUDGE_PREFIX = "comeback-nudge";
export const NUDGE_DAYS = [3, 7];

// Push the "we miss you" reminders forward every time the app is opened, so they
// only ever fire after 3 (and 7) days without opening Alter.
export async function scheduleComebackNudge(name?: string): Promise<boolean> {
  if (!notificationsSupported) return false;
  const perm = await Notifications.getPermissionsAsync();
  if (!perm.granted) return false;
  await ensureChannel();
  for (const days of NUDGE_DAYS) {
    let when = dayjs().add(days, "day");
    if (when.hour() < 10) when = when.hour(10).minute(0);
    if (when.hour() >= 20) when = when.add(1, "day").hour(10).minute(0);
    const id = `${NUDGE_PREFIX}-${days}`;
    await Notifications.cancelScheduledNotificationAsync(id).catch(() => {});
    await Notifications.scheduleNotificationAsync({
      identifier: id,
      content: {
        title: days === 3 ? `Your Alter buddy misses you${name ? `, ${name}` : ""}!` : "Psst… your little robot is waiting for a hug",
        body: days === 3
          ? "It's been 3 days. Pop in to check today's tasks and your grocery list — everything's saved."
          : "A week already! Say one thing you need to do and we'll sort it together.",
        sound: "default",
        data: { kind: "nudge", days },
      },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when.toDate(), channelId: CHANNEL },
    });
  }
  return true;
}

// Lead times before a timed task (minutes). 0 = exactly on time.
export const ALERT_OFFSETS = [120, 60, 5, 0];
let lastKey = "";

function label(mins: number) {
  if (mins === 0) return "Now";
  if (mins >= 60) return `In ${mins / 60} hour${mins === 60 ? "" : "s"}`;
  return `In ${mins} minutes`;
}

export const hasUpcomingTimedTask = (tasks: Task[] | undefined) =>
  !!tasks?.some((t) => t.status !== "completed" && t.due_date && t.due_time && dayjs(`${t.due_date}T${t.due_time}`).isAfter(dayjs()));

// Cancels and re-schedules this device's alerts (2h, 1h, 5 min before and on time) for every timed task.
export async function syncTaskAlerts(tasks: Task[] | undefined, force = false): Promise<number> {
  if (!alertsSupported || !tasks) return 0;
  if (notificationsSupported && !(await Notifications.getPermissionsAsync()).granted) return 0;
  const now = dayjs();
  const step = (d: dayjs.Dayjs, rule: string) =>
    rule === "daily" ? d.add(1, "day") : rule === "weekdays" ? d.add(d.day() === 5 ? 3 : d.day() === 6 ? 2 : 1, "day") : rule === "weekly" ? d.add(7, "day") : d.add(1, "month");
  const occurrences = tasks
    .filter((t) => t.status !== "completed" && t.due_date && t.due_time)
    .flatMap((t) => {
      const first = dayjs(`${t.due_date}T${t.due_time}`);
      if (!t.alarm || !t.recurrence) return [{ t, at: first }];
      // repeating alarm: schedule the next week's rings so it keeps ringing even if Alter isn't opened
      const out = [];
      let at = first;
      while (at.isBefore(now)) at = step(at, t.recurrence); // skip rings already in the past
      for (; out.length < 8 && at.isBefore(now.add(8, "day")); at = step(at, t.recurrence)) out.push({ t, at });
      return out;
    });
  let budget = 60; // iOS keeps at most 64 pending notifications: a task costs 4 (reminders + alarm), an alarm ring 1
  const active = occurrences
    .filter(({ at }) => at.isValid() && at.isAfter(now))
    .sort((a, b) => a.at.valueOf() - b.at.valueOf())
    .filter(({ t }) => (budget -= t.alarm ? 1 : ALERT_OFFSETS.length) >= 0);
  const key = active.map(({ t, at }) => `${t.id}|${at.format("YYYY-MM-DDTHH:mm")}|${t.title}|${t.alarm ? 1 : 0}`).join(";");
  if (!force && key === lastKey) return active.length;

  if (webNotif) {
    webTimers.forEach(clearTimeout);
    webTimers = [];
    for (const { t, at } of active) {
      for (const mins of ALERT_OFFSETS) {
        if (t.alarm && mins > 0) continue;
        const delay = at.subtract(mins, "minute").diff(dayjs());
        if (delay <= 0 || delay > 2 ** 31 - 1) continue;
        const heading = mins === 0 ? `It's time: ${t.title}` : `${label(mins)}: ${t.title}`;
        webTimers.push(setTimeout(() => {
          if (window.Notification.permission === "granted") {
            try {
              const n = new window.Notification(heading, {
                body: `Due at ${at.format("HH:mm")} · Alter`, tag: `${t.id}-${mins}`, requireInteraction: mins === 0, icon: "/favicon.ico",
              });
              n.onclick = () => { window.focus(); n.close(); };
            } catch (e) {
              console.warn("web notification failed", e);
            }
          }
          fireAlert({ kind: mins === 0 ? "alarm" : "pre", taskId: t.id, title: t.title, mins, heading });
        }, delay));
      }
    }
    lastKey = key;
    return webTimers.length;
  }

  await ensureChannel();
  // Cancel only task alerts; the comeback nudge stays scheduled.
  for (const n of await Notifications.getAllScheduledNotificationsAsync()) {
    const kind = (n.content.data as { kind?: string } | undefined)?.kind;
    if (n.identifier === TEST_ID || n.identifier.startsWith(SNOOZE_PREFIX)) continue; // a pending test alarm / snooze stays
    if (kind === "alarm" || kind === "pre" || !n.identifier.startsWith(NUDGE_PREFIX)) {
      await Notifications.cancelScheduledNotificationAsync(n.identifier).catch(() => {});
    }
  }
  await cancelFullScreenAlarms().catch((e) => console.warn("cancel full-screen alarms failed", e));
  let count = 0;
  for (const { t, at } of active) {
    for (const mins of ALERT_OFFSETS) {
      if (t.alarm && mins > 0) continue; // an alarm rings once, on time; no early reminders
      const when = at.subtract(mins, "minute");
      if (!when.isAfter(now)) continue;
      const body = `Due at ${at.format("HH:mm")}${t.assigned_to_name ? ` · ${t.assigned_to_name}` : ""}`;
      if (mins === 0 && fullScreenSupported) {
        // Android build: alarm-clock style, full screen over other apps / lock screen, even if Alter is closed
        try {
          await scheduleFullScreenAlarm(t, when.toDate(), body, `alter-alarm-${t.id}-${at.format("YYYYMMDDHHmm")}`);
          count++;
          continue;
        } catch (e) {
          console.warn("full-screen alarm failed, using a normal notification", t.id, e);
        }
      }
      try {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: mins === 0 ? `It's time: ${t.title}` : `${label(mins)}: ${t.title}`,
            body,
            sound: mins === 0 ? ALARM_SOUND : SOUND,
            data: { kind: mins === 0 ? "alarm" : "pre", taskId: t.id, title: t.title, mins },
            priority: Notifications.AndroidNotificationPriority.MAX,
            interruptionLevel: "timeSensitive",
          },
          trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when.toDate(), channelId: mins === 0 ? ALARM_CHANNEL : CHANNEL },
        });
        count++;
      } catch (e) {
        console.warn("schedule failed", t.id, mins, e);
      }
    }
  }
  lastKey = key; // only after scheduling, so a failed run retries next time
  return count;
}

const TEST_ID = "alter-test-alarm";
export const TEST_TASK_ID = "test";
export const TEST_DELAY_S = 10;

/** "Test my alarm": rings the same way a real on-time task alarm would, 10 seconds from now. */
export async function scheduleTestAlarm() {
  const at = dayjs().add(TEST_DELAY_S, "second");
  const title = "Test alarm";
  const body = "This is how your task alarms will ring. Tap to open Alter.";
  if (webNotif) {
    setTimeout(() => {
      if (window.Notification.permission === "granted") {
        try {
          new window.Notification(`It's time: ${title}`, { body, tag: TEST_ID, requireInteraction: true, icon: "/favicon.ico" });
        } catch (e) {
          console.warn("web notification failed", e);
        }
      }
      fireAlert({ kind: "alarm", taskId: TEST_TASK_ID, title, mins: 0, heading: `It's time: ${title}` });
    }, TEST_DELAY_S * 1000);
    return;
  }
  if (!notificationsSupported) return;
  await ensureChannel();
  const fake = { id: TEST_TASK_ID, title } as Task;
  if (fullScreenSupported) {
    try {
      await scheduleFullScreenAlarm(fake, at.toDate(), body);
      return;
    } catch (e) {
      console.warn("full-screen test alarm failed, using a normal notification", e);
    }
  }
  await Notifications.cancelScheduledNotificationAsync(TEST_ID).catch(() => {});
  await Notifications.scheduleNotificationAsync({
    identifier: TEST_ID,
    content: {
      title: `It's time: ${title}`,
      body,
      sound: ALARM_SOUND,
      data: { kind: "alarm", taskId: TEST_TASK_ID, title, mins: 0 },
      priority: Notifications.AndroidNotificationPriority.MAX,
      interruptionLevel: "timeSensitive",
    },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: at.toDate(), channelId: ALARM_CHANNEL },
  });
}


export const SNOOZE_OPTIONS = [5, 10, 30];

/** Task marked done: drop any snooze still waiting for it. */
export async function cancelSnooze(taskId: string) {
  if (!notificationsSupported) return;
  await Notifications.cancelScheduledNotificationAsync(`${SNOOZE_PREFIX}${taskId}`).catch(() => {});
  await cancelFullScreenAlarms(`${SNOOZE_PREFIX}${taskId}`);
}

/** Snooze: ring the same alarm again in `mins` minutes (survives the next task-alarm re-sync). */
export async function scheduleSnooze(taskId: string, title: string, mins = 10) {
  const at = dayjs().add(mins, "minute");
  const id = `${SNOOZE_PREFIX}${taskId}`;
  const body = `Snoozed ${mins} minutes · Alter`;
  if (webNotif || !notificationsSupported) {
    snoozeTimers.push(setTimeout(() => fireAlert({ kind: "alarm", taskId, title, mins: 0, heading: `It's time: ${title}` }), mins * 60_000));
    return;
  }
  await ensureChannel();
  if (fullScreenSupported) {
    try {
      await scheduleFullScreenAlarm({ id: taskId, title } as Task, at.toDate(), body, id);
      return;
    } catch (e) {
      console.warn("full-screen snooze failed, using a normal notification", e);
    }
  }
  await Notifications.cancelScheduledNotificationAsync(id).catch(() => {});
  await Notifications.scheduleNotificationAsync({
    identifier: id,
    content: {
      title: `It's time: ${title}`,
      body,
      sound: ALARM_SOUND,
      data: { kind: "alarm", taskId, title, mins: 0 },
      priority: Notifications.AndroidNotificationPriority.MAX,
      interruptionLevel: "timeSensitive",
    },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: at.toDate(), channelId: ALARM_CHANNEL },
  });
}

import { AudioPlayer, createAudioPlayer, setAudioModeAsync } from "expo-audio";

let chime: AudioPlayer | null = null;
let alarm: AudioPlayer | null = null;

async function playbackMode() {
  try {
    await setAudioModeAsync({ playsInSilentMode: true, allowsRecording: false });
  } catch {
    // audio mode is best effort
  }
}

export async function playChime() {
  try {
    await playbackMode();
    if (!chime) {
      chime = createAudioPlayer(require("../assets/sounds/chime.wav"));
      chime.volume = 0.45;
    }
    await chime.seekTo(0);
    chime.play();
  } catch (e) {
    console.warn("chime failed", e);
  }
}

let ting: AudioPlayer | null = null;

/** Short "ting-ting" for 2 h / 1 h / 5 min reminders. */
export async function playReminder() {
  try {
    await playbackMode();
    if (!ting) ting = createAudioPlayer(require("../assets/sounds/tingting.wav"));
    await ting.seekTo(0);
    ting.play();
  } catch (e) {
    console.warn("reminder sound failed", e);
  }
}

/** Ringing alarm that repeats until stopAlarm() (used when a task is due right now). */
export async function playAlarm() {
  try {
    await playbackMode();
    if (!alarm) alarm = createAudioPlayer(require("../assets/sounds/alarm.wav"));
    alarm.loop = true;
    alarm.volume = 1;
    await alarm.seekTo(0);
    alarm.play();
  } catch (e) {
    console.warn("alarm failed", e);
  }
}

export function stopAlarm() {
  try {
    alarm?.pause();
  } catch {
    // already stopped
  }
}

// Full-screen alarms are Android-only (see alarm.android.ts). Everywhere else these are no-ops.
import type { Task } from "@/src/api";

export const fullScreenSupported = false;
export const SNOOZE_PREFIX = "alter-snooze-";
export async function scheduleFullScreenAlarm(_t: Task, _at: Date, _body: string, _id?: string) {}
export async function cancelFullScreenAlarms(_onlyId?: string) {}
export async function dismissFullScreenAlarm(_taskId?: string) {}
export async function exactAlarmsAllowed() {
  return true;
}
export async function openAlarmSettings() {}
export function listenFullScreenAlarms(_onRing: (a: { taskId: string; title: string; heading: string }) => void) {
  return () => {};
}

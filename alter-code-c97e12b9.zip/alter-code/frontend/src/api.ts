import { fetch as expoFetch } from "expo/fetch";
import { Platform } from "react-native";

import { storage } from "@/src/utils/storage";
import { uploadForm } from "@/src/utils/upload";

export const TOKEN_KEY = "auth_token";
const BASE = `${process.env.EXPO_PUBLIC_BACKEND_URL}/api`;

export type MemoryCategory = "preferences" | "people" | "goals" | "work" | "habits" | "facts" | "other";
export type Priority = "low" | "medium" | "high" | "urgent";
export type TaskStatus = "todo" | "completed";

export type Profile = {
  id: string;
  user_id: string;
  display_name: string;
  description: string;
  preferences: string;
  response_style: "balanced" | "concise" | "detailed";
  read_aloud: boolean;
  timezone: string;
  voice_language?: string;
  updated_at: string;
};
export type Memory = {
  id: string;
  content: string;
  category: MemoryCategory;
  certainty: "confirmed" | "inferred";
  source: "manual" | "chat";
  created_at: string;
  updated_at: string;
};
export type Task = {
  id: string;
  title: string;
  description: string;
  due_date: string | null;
  due_time: string | null;
  priority: Priority;
  status: TaskStatus;
  source: "manual" | "chat" | "voice" | "gmail" | "calendar";
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  user_id: string;
  owner_name: string;
  assigned_to: string | null;
  assigned_to_name: string | null;
  confidential?: boolean;
  alarm?: boolean;
  recurrence?: "daily" | "weekdays" | "weekly" | "monthly" | null;
};
export type DaySummary = { date: string; text: string; stale: boolean; ai: boolean; counts: { done: number; pending: number; overdue: number } };
export type Grocery = {
  id: string;
  user_id: string;
  family_id: string | null;
  name: string;
  quantity: string;
  checked: boolean;
  added_by_name: string;
  source: "manual" | "voice" | "chat";
  created_at: string;
};
export type FamilyMember = { user_id: string; display_name: string };
export type FamilyInfo = {
  family: { id: string; name: string; code: string; owner_id: string } | null;
  members: FamilyMember[];
};
export type Conversation = { id: string; title: string; last_message: string; created_at: string; updated_at: string };
export type ChatAction = {
  type: string;
  status: "success" | "failed" | "pending" | "blocked" | "approved" | "dismissed";
  detail: string;
  data: Record<string, any>;
};
export type Message = {
  id: string;
  conversation_id: string;
  role: "user" | "assistant";
  content: string;
  actions: ChatAction[];
  sources?: { id: string; type: string; label: string; record_id: string; text: string; timestamp: string | null }[];
  created_at: string;
};
export type Dashboard = {
  profile: Profile;
  today: string;
  counts: { todo: number; overdue: number; urgent: number; memories: number; groceries: number };
  family: { id: string; name: string } | null;
  upcoming: Task[];
  family_upcoming?: Task[];
  recent_memories: Memory[];
  last_conversation: Conversation | null;
};

export type QuotaInfo = { code: string; feature: string; limit: number | null; used: number | null; reset_at: string | null; retry: string };

export class ApiError extends Error {
  status: number;
  quota?: QuotaInfo; // set for usage-limit / beta / AI-paused responses (not network or server errors)
  code?: string; // AI routing errors: byok_required | byok_invalid | byok_quota | byok_model | byok_unavailable
  constructor(message: string, status: number, quota?: QuotaInfo, code?: string) {
    super(message);
    this.status = status;
    this.quota = quota;
    this.code = code;
  }
}

let onUnauthorized: (() => void) | null = null;
export function setOnUnauthorized(fn: (() => void) | null) {
  onUnauthorized = fn;
}

function detailMessage(body: any, status: number): string {
  const d = body?.detail;
  if (typeof d === "string") return d;
  if (Array.isArray(d) && d[0]?.msg) {
    const field = Array.isArray(d[0].loc) ? d[0].loc[d[0].loc.length - 1] : "";
    const msg = String(d[0].msg).replace(/^Value error, /, "");
    return field && field !== "body" ? `${String(field).replace(/_/g, " ")}: ${msg}` : msg;
  }
  if (status === 429) return "Too many requests. Please wait a moment.";
  return status >= 500 ? "Something went wrong on our side. Please try again." : `Request failed (${status})`;
}

async function headers(): Promise<Record<string, string>> {
  const token = await storage.secureGet(TOKEN_KEY, "");
  const h: Record<string, string> = { "Content-Type": "application/json" };
  if (token) h.Authorization = `Bearer ${token}`;
  return h;
}

export async function api<T>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  const h = await headers();
  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, {
      method: init.method ?? "GET",
      headers: h,
      body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
    });
  } catch {
    throw new ApiError("You appear to be offline. Check your connection and try again.", 0);
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && h.Authorization) onUnauthorized?.();
    throw new ApiError(detailMessage(body, res.status), res.status, body?.error, body?.code);
  }
  return body as T;
}

export type VoiceResult = { transcript: string; results: ChatAction[]; error?: string; clarify?: string };
export type AIKeyStatus = {
  configured: boolean; masked: string | null; status: "valid" | "invalid" | null; last_error: string | null;
  checked_at: string | null; model: string; route: "byok" | "universal" | "none"; universal_access: string; disclosure: string;
};
export const isKeyError = (code?: string) => !!code && code.startsWith("byok");

async function uploadAudio<T>(path: string, uri: string): Promise<T> {
  const token = await storage.secureGet(TOKEN_KEY, "");
  const web = Platform.OS === "web";
  let res: Response;
  try {
    res = await uploadForm(`${BASE}${path}`, {
      files: { audio: { uri, name: web ? "voice.webm" : "voice.m4a", mimeType: web ? "audio/webm" : "audio/m4a" } },
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
    });
  } catch {
    throw new ApiError("Couldn't upload the recording. Check your connection and try again.", 0);
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401) onUnauthorized?.();
    throw new ApiError(detailMessage(body, res.status), res.status, body?.error, body?.code);
  }
  return body as T;
}

export const voiceCapture = (uri: string) => uploadAudio<VoiceResult>("/voice", uri);
export const transcribeAudio = (uri: string) => uploadAudio<{ transcript: string }>("/transcribe", uri);

export type BoardRow = FamilyMember & { open: number; completed_week: number; overdue: number; assigned_by_others: number };
export type ChoreBoard = { week_start: string; members: BoardRow[] };

export type ChatEvent =
  | { type: "meta"; conversation: Conversation; user_message: Message }
  | { type: "actions"; actions: ChatAction[] }
  | { type: "delta"; content: string }
  | { type: "done"; message: Message }
  | { type: "error"; detail: string; code?: string };

export async function streamChat(
  payload: { conversation_id: string | null; message: string; client_id?: string },
  onEvent: (e: ChatEvent) => void,
) {
  const h = await headers();
  const f: any = Platform.OS === "web" ? globalThis.fetch : expoFetch;
  let res: any;
  try {
    res = await f(`${BASE}/chat`, {
      method: "POST",
      headers: { ...h, Accept: "text/event-stream" },
      body: JSON.stringify(payload),
    });
  } catch {
    throw new ApiError("You appear to be offline. Check your connection and try again.", 0);
  }
  if (!res.ok) {
    const b = await res.json().catch(() => ({}));
    if (res.status === 401) onUnauthorized?.();
    throw new ApiError(detailMessage(b, res.status), res.status, b?.error, b?.code);
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let i = buf.indexOf("\n\n");
    while (i >= 0) {
      const chunk = buf.slice(0, i);
      buf = buf.slice(i + 2);
      const line = chunk.split("\n").find((l) => l.startsWith("data: "));
      if (line) onEvent(JSON.parse(line.slice(6)));
      i = buf.indexOf("\n\n");
    }
  }
}

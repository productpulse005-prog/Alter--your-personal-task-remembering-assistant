import dayjs from "dayjs";

import type { MemoryCategory, Priority, Task, TaskStatus } from "@/src/api";

export const CATEGORIES: { key: MemoryCategory; label: string; icon: string }[] = [
  { key: "preferences", label: "Preferences", icon: "heart" },
  { key: "people", label: "People", icon: "users" },
  { key: "goals", label: "Goals", icon: "target" },
  { key: "work", label: "Work", icon: "briefcase" },
  { key: "habits", label: "Habits", icon: "repeat" },
  { key: "facts", label: "Facts", icon: "bookmark" },
  { key: "other", label: "Other", icon: "feather" },
];
export const categoryLabel = (k: string) => CATEGORIES.find((c) => c.key === k)?.label ?? "Other";

export const PRIORITIES: { key: Priority; label: string }[] = [
  { key: "urgent", label: "Urgent" },
  { key: "high", label: "High" },
  { key: "medium", label: "Medium" },
  { key: "low", label: "Low" },
];
export const STATUSES: { key: TaskStatus; label: string }[] = [
  { key: "todo", label: "To Do" },
  { key: "completed", label: "Completed" },
];
export const statusLabel = (k: string) => STATUSES.find((s) => s.key === k)?.label ?? k;

export function formatDue(t: Pick<Task, "due_date" | "due_time">, today = dayjs().format("YYYY-MM-DD")) {
  if (!t.due_date) return null;
  const d = dayjs(t.due_date);
  const diff = d.diff(dayjs(today), "day");
  let label = diff === 0 ? "Today" : diff === 1 ? "Tomorrow" : diff === -1 ? "Yesterday" : d.format("ddd, D MMM");
  if (t.due_time) label += ` · ${t.due_time}`;
  return { label, overdue: diff < 0 };
}

export function relTime(iso: string) {
  const mins = dayjs().diff(dayjs(iso), "minute");
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const h = Math.floor(mins / 60);
  if (h < 24) return `${h}h ago`;
  const days = Math.floor(h / 24);
  if (days < 7) return `${days}d ago`;
  return dayjs(iso).format("D MMM");
}

export function greeting(name: string) {
  const h = new Date().getHours();
  const part = h < 5 ? "Good evening" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
  return `${part}, ${name}.`;
}

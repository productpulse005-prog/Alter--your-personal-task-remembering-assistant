import { Image } from "expo-image";
import React, { useEffect, useState } from "react";
import { Text, View } from "react-native";
import Animated, { useAnimatedStyle, useSharedValue, withSequence, withSpring, withTiming } from "react-native-reanimated";

import dayjs from "dayjs";

import { api, Task } from "@/src/api";
import { playChime } from "@/src/sounds";
import { fonts, makeStyles, radius, spacing } from "@/src/theme";

export const MASCOT_CHEER = require("../assets/images/mascot-cheer.png");
export const MASCOT_WAVE = require("../assets/images/mascot-wave.png");

const CHEERS = ["Yay, done!", "Nice work!", "You did it!", "One less thing!", "Woohoo!"];
type Mood = { kind: "cheer" | "welldone" | "welcome"; text: string; ms: number };
let listener: ((m: Mood) => void) | null = null;
const CHEER_MS = 1200;
const WELLDONE_MS = 1500;

// Friendly wave when someone comes back after a few days away.
export function welcomeBack(name?: string) {
  listener?.({ kind: "welcome", text: `Welcome back${name ? `, ${name}` : ""}! We missed you`, ms: 2500 });
}

// True when every task due on `day` (that this user can see) is completed.
async function allDoneFor(day: string) {
  try {
    const tasks = await api<Task[]>("/tasks");
    const forDay = tasks.filter((t) => t.due_date === day);
    return forDay.length > 0 && forDay.every((t) => t.status === "completed");
  } catch {
    return false;
  }
}

// Call after a task is completed: short chime + quick cheer. If that finished the day's
// list, a "Well done!" follows at the very end for 1.5 s.
export async function celebrate(dueDate?: string | null) {
  playChime();
  listener?.({ kind: "cheer", text: CHEERS[Math.floor(Math.random() * CHEERS.length)], ms: CHEER_MS });
  const day = dueDate || dayjs().format("YYYY-MM-DD");
  if (await allDoneFor(day)) {
    const isToday = day === dayjs().format("YYYY-MM-DD");
    setTimeout(() => listener?.({ kind: "welldone", text: isToday ? "Well done! All of today's tasks are complete" : "Well done! That day's tasks are all complete", ms: WELLDONE_MS }), CHEER_MS + 150);
  }
}

export function MascotOverlay() {
  const s = useStyles();
  const [mood, setMood] = useState<Mood | null>(null);
  const scale = useSharedValue(0);
  const style = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }], opacity: scale.value }));

  useEffect(() => {
    let t: ReturnType<typeof setTimeout> | null = null;
    listener = (m) => {
      if (t) clearTimeout(t);
      setMood(m);
      scale.value = withSequence(withSpring(1.08, { damping: 9 }), withSpring(1));
      t = setTimeout(() => {
        scale.value = withTiming(0, { duration: 150 });
        setTimeout(() => setMood((cur) => (cur === m ? null : cur)), 160);
      }, m.ms - 150);
    };
    return () => {
      listener = null;
      if (t) clearTimeout(t);
    };
  }, [scale]);

  if (!mood) return null;
  const well = mood.kind !== "cheer";
  return (
    <View pointerEvents="none" style={s.wrap}>
      <Animated.View style={[s.card, well && s.wellCard, style]} testID={mood.kind === "welcome" ? "mascot-welcome" : well ? "mascot-welldone" : "mascot-cheer"}>
        <Image source={well ? MASCOT_WAVE : MASCOT_CHEER} style={well ? s.wellImg : s.img} contentFit="cover" />
        <Text style={[s.text, well && s.wellText]}>{mood.text}</Text>
      </Animated.View>
    </View>
  );
}

const useStyles = makeStyles((c) => ({
  wrap: { position: "absolute", top: 0, left: 0, right: 0, bottom: 0, alignItems: "center", justifyContent: "center" },
  card: { alignItems: "center", gap: spacing.sm, backgroundColor: c.surface, borderRadius: radius.lg, padding: spacing.lg, borderWidth: 2, borderColor: c.peach },
  img: { width: 140, height: 140, borderRadius: 28 },
  wellCard: { borderColor: c.brandSecondary, maxWidth: 300 },
  wellImg: { width: 180, height: 180, borderRadius: 32 },
  wellText: { color: c.success, textAlign: "center", fontSize: 22 },
  text: { fontFamily: fonts.displayMedium, fontSize: 22, color: c.brandPrimary },
}));

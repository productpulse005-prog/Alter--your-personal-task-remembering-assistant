// Design tokens for Alter ("3 Editorial Mobile LIGHT"). Keys match the
// "color" block of /app/design_guidelines.json. Light theme only.
import { useMemo } from "react";
import { Appearance, StyleSheet, useColorScheme } from "react-native";

export type ColorScheme = "light" | "dark";

const light = {
  surface: "#FFF8EE",
  onSurface: "#4A3B36",
  surfaceSecondary: "#FFF0E6",
  onSurfaceSecondary: "#5B4B45",
  surfaceTertiary: "#FCE6DA",
  onSurfaceTertiary: "#6B5852",
  surfaceInverse: "#5B4B45",
  onSurfaceInverse: "#FFF8EE",
  muted: "#9A8780",

  brand: "#DD6B55",
  onBrand: "#FFFFFF",
  brandPrimary: "#DD6B55",
  onBrandPrimary: "#FFFFFF",
  brandSecondary: "#5FB89B",
  onBrandSecondary: "#FFFFFF",
  brandTertiary: "#DDF3EA",
  onBrandTertiary: "#2C5A4B",

  success: "#3F9C7E",
  onSuccess: "#FFFFFF",
  warning: "#D98A2B",
  onWarning: "#FFFFFF",
  error: "#D4554C",
  onError: "#FFFFFF",
  info: "#5FB89B",
  onInfo: "#FFFFFF",

  border: "#F3DDD0",
  borderStrong: "#E8C6B5",
  divider: "#F6E6DC",
  backdrop: "rgba(74,59,54,0.35)",
  peach: "#FFD9CC",
};

export type ThemeColors = typeof light;

export const defaultScheme = "light" satisfies ColorScheme;

export const themes: { light: ThemeColors; dark?: ThemeColors } = { light };

export function setColorScheme(scheme: ColorScheme | null) {
  Appearance.setColorScheme?.(scheme ?? "unspecified");
}

setColorScheme?.(themes.dark ? null : defaultScheme);

export const colors = light;

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, "2xl": 32, "3xl": 48 };
export const radius = { sm: 8, md: 14, lg: 22, pill: 999 };
export const fonts = {
  display: "Fredoka-Medium",
  displayMedium: "Fredoka-SemiBold",
  text: "Nunito-Regular",
  textMedium: "Nunito-Bold",
};

export function useTheme(): { scheme: ColorScheme; colors: ThemeColors } {
  const system = useColorScheme();
  const scheme: ColorScheme = (system === "light" || system === "dark") && themes[system] ? system : defaultScheme;
  return { scheme, colors: themes[scheme] ?? themes.light };
}

export function makeStyles<T extends StyleSheet.NamedStyles<T> | StyleSheet.NamedStyles<any>>(
  factory: (colors: ThemeColors) => T & StyleSheet.NamedStyles<any>,
): () => T {
  return function useStyles(): T {
    const { colors } = useTheme();
    return useMemo(() => StyleSheet.create(factory(colors)), [colors]);
  };
}

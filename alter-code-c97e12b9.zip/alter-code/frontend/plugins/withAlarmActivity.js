// Lets the full-screen alarm light up the screen and show over the lock screen (Android).
const { withAndroidManifest } = require("expo/config-plugins");

module.exports = function withAlarmActivity(config) {
  return withAndroidManifest(config, (cfg) => {
    const app = cfg.modResults.manifest.application?.[0];
    const main = app?.activity?.find((a) => a.$["android:name"] === ".MainActivity");
    if (main) {
      main.$["android:showWhenLocked"] = "true";
      main.$["android:turnScreenOn"] = "true";
    }
    return cfg;
  });
};
